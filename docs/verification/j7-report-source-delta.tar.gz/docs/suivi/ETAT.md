# État de reprise — Sinesi

## Situation courante — 8 novembre 2026

**J1 à J6 sont qualifiés localement. J7 reste ouvert.** La tranche PDF est qualifiée après le refactor SolidCraft/WordCraft; les commandes
communes et les frontières contrôlées restent le socle de travail.
FR EN ES IT PT DE et les vues Icônes/Schéma sont conservés.

| Registre de référence | État |
| --- | --- |
| [178 exigences](features.json) | **155 verified**, 1 implemented, 2 in_progress, 20 not_started |
| [50 lots Rust](../rust/taches.json) | **43 verified**, 2 in_progress, 3 not_started, 2 deferred |
| J7 | **13 exigences vérifiées sur 22**, 1 implémentée partiellement, 8 non démarrées |
| Lots en cours | RS-QUALITY-J0, RS-PROJECTS-J7 |

Les registres et leurs preuves sont l’autorité. Les résumés historiques ne ferment
pas une exigence; [leur chronologie antérieure](ETAT-HISTORIQUE-2026-11-08.md) est conservée.

## Dernière tranche : rapport PDF

**F-DOC-004 et RS-REPORTING-J7 sont vérifiés localement.** Voir le
[profil portable](../agnostique/RAPPORTS_J7.md),
[D-012](../rust/decisions/D-012-rapport-pdf-j7.md) et le
[rapport de qualification](../verification/J7-RAPPORT.md).

La GUI et le CLI partagent le rapport depuis un instantané : schéma, configuration,
interfaces, logiciels, DNS, routes et paquets par MAC. Configuration durable et
réseau effectif restent distincts, notamment DHCP. Les textes sont sélectionnables,
les quatre fontes embarquées et les tables paginées sans perte de lignes. PNG/PDF
partagent une tâche bornée, les protections de fichiers et l’attente à la fermeture.

Qualification : **233 tests du workspace plus un enfant**, cinq ignorés, Clippy
sans avertissement, formatage et contrôles; **6 tests GPU et 24 captures nouvelles
comparées sans mise à jour**, **321 anciennes images conservées**; **13 PDF contrôlés
indépendamment**, dont 1 200 paquets sur 72 pages. Le scénario routé/DNS/DHCP produit
34 paquets dans les six langues et les deux vues. Un panic du canevas sur glyphe
manquant est corrigé et testé; l’export refuse ce texte avant d’écrire.
Manifeste : **618 fichiers**, `sha256:d7a7595b59ad42103a434735ed6ba68f88032f75570c97c6b2633fe2216cb66e`.

Le [refactor précédent](../verification/STRUCTURE-2026-11.md), le
[guide de développement](../rust/DEVELOPPEMENT.md) et la
[carte actuelle](../rust/ARCHITECTURE.md) restent les points d’entrée techniques.
Le workspace compte désormais **20 membres**; ses frontières restent contrôlées.

## Périmètre J7 déjà qualifié

- [Import](../verification/J7-IMPORT-EN-COURS.md) : données ZIP/XML bornées, original préservé, rapport de pertes; **F-PROJ-005 reste implemented**, pas verified.
- [Scénarios/reprise/rejeu](../verification/J7-REPRISE-EN-COURS.md) et [pannes de liaison](../verification/J7-PANNES.md) : F-SIM-007/008.
- [Duplication/alignement](../verification/J7-TOPOLOGIE.md) et [nuage](../verification/J7-PRESENTATION.md) : F-TOP-009, F-EQU-008.
- [Observation](../verification/J7-OBSERVATION.md) et [diagnostic interne](../verification/J7-TERMINAL.md) : F-OBS-006/008, F-CLI-019.
- [Session/récupération](../verification/J7-SESSION.md) : F-PROJ-003/006.
- [Notes/zones](../verification/J7-ANNOTATIONS.md) et [PNG](../verification/J7-PNG.md) et [PDF](../verification/J7-RAPPORT.md) : F-DOC-001/002/003/004.

## Prochaine action et limites

Poursuivre **RS-PLATFORM-J7**, en commençant par **F-CFG-002**, aide par mode,
versions consultables et informations. Son prérequis RS-PROJECTS-J1 est vérifié.
Préserver les six langues, les deux vues et les nouvelles commandes documentaires.

Restent aussi couverture sémantique de l’import, aide/préférences/fonts/icons/layout,
priorité de configuration, options de lancement, diagnostics, exemples, packaging
et parcours réels sur trois OS. F-NFR-001/006 et RS-QUALITY-J0 restent en cours.
La suite GPU historique complète et la lisibilité globale doivent être réconciliées
avec J7. La commande graphique ciblée couvre actuellement PNG et PDF.

Aucun sélecteur natif nouvellement manipulé, aucun parcours manuel autonome,
résultat Windows/Linux ou run distant n’est revendiqué. Les sockets hôte restent
réservées au pont explicitement activé. Les archives Filius et network-kit restent
en lecture seule; ni audit recalculé, ni commit, push ou publication effectués.
