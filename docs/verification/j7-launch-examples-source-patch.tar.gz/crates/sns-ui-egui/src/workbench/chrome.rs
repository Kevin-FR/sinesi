//! Workbench chrome responsibilities.
use super::*;

impl Workbench {
    pub fn show(&mut self, ui: &mut egui::Ui) {
        annotations::install_fonts(ui.ctx());
        self.apply_display_style(ui.ctx());
        self.poll_preferences(ui.ctx());
        self.poll_document_export(ui.ctx());
        self.poll_session(ui.ctx());
        if ui.input(|i| i.viewport().close_requested())
            && (self.session_enabled() || self.document_export_busy() || self.preferences_busy())
            && !self.close_confirmed
        {
            ui.ctx()
                .send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.session_ui.close_requested = true;
        }
        if self.session_ui.loading {
            ui.spinner();
            ui.label(self.language.text("session_saving"));
            return;
        }
        self.poll_runtime(ui.ctx());
        if self.runtime_busy() {
            ui.spinner();
            ui.label(self.language.text("runtime_working"));
            return;
        }
        self.runtime_window(ui.ctx());
        self.poll_import(ui.ctx());
        let language = self.language;
        if self.import_ui.receiver.is_some() {
            ui.spinner();
            ui.label(language.text("import_working"));
            return;
        }
        self.import_window(ui.ctx());
        self.document_export_window(ui.ctx());
        self.worker.attach_context(ui.ctx());
        self.worker.poll();
        let failed = self.worker.view.error.is_some();
        if failed && !self.simulation_error_visible {
            self.journal.record(TechnicalEvent::SimulationFailed);
        }
        self.simulation_error_visible = failed;
        self.sync_applications();
        if self.close_confirmed {
            if self.session_close_ready(ui.ctx()) {
                ui.ctx().send_viewport_cmd(egui::ViewportCommand::Close);
            } else {
                ui.spinner();
                ui.label(self.language.text("session_saving"));
            }
            return;
        }
        self.link_conditions_window(ui.ctx());
        self.update_activity(ui.ctx());
        if (ui.input(|i| i.viewport().close_requested()) || self.session_ui.close_requested)
            && !self.close_confirmed
        {
            self.session_ui.close_requested = false;
            if self.editor.dirty() || self.desktop.dirty() || self.worker.pending_commands() {
                ui.ctx()
                    .send_viewport_cmd(egui::ViewportCommand::CancelClose);
                self.pending = Some(Replacement::Close);
            } else if self.session_enabled()
                || self.document_export_busy()
                || self.preferences_busy()
            {
                self.close_confirmed = true;
            }
        }
        if self.pending.is_none() {
            self.shortcuts(ui.ctx());
        }
        egui::Frame::central_panel(ui.style()).show(ui, |ui| {
            ui.set_min_size(ui.available_size());
            ui.horizontal_wrapped(|ui| {
                ui.heading("Sinesi");
                ui.label(language.text("workbench"));
                if ui.button(language.text("preferences")).clicked() {
                    self.toggle_preferences();
                }
                egui::ComboBox::new("ui-language", language.text("language"))
                    .selected_text(self.language.label())
                    .show_ui(ui, |ui| {
                        for value in Language::ALL {
                            if ui
                                .selectable_label(self.language == value, value.label())
                                .clicked()
                            {
                                self.choose_language(value);
                            }
                        }
                    });
                if ui.button(language.text("new")).clicked() {
                    self.replace(Replacement::New);
                }
                if ui.button(language.text("import_filius")).clicked() {
                    self.replace(Replacement::ImportFilius);
                }
                if self.import_ui.report.is_some()
                    && ui.button(language.text("import_report")).clicked()
                {
                    self.import_ui.open = true;
                }
                if ui.button(language.text("open")).clicked() {
                    self.replace(Replacement::Open);
                }
                if ui.button(language.text("save")).clicked() {
                    self.save(false);
                }
                if ui.button(language.text("save_as")).clicked() {
                    self.save(true);
                }
                self.session_toolbar(ui);
                if ui.button(language.text("example")).clicked() {
                    self.replace(Replacement::Example(Example::Lan));
                }
                if ui.button(language.text("software_example")).clicked() {
                    self.replace(Replacement::Example(Example::Hosts));
                }
                egui::ComboBox::from_id_salt("routing-examples")
                    .height(320.)
                    .selected_text(language.text("routing_examples"))
                    .show_ui(ui, |ui| {
                        for example in Example::ALL {
                            if !matches!(example, Example::Lan | Example::Hosts)
                                && ui.button(language.text(example.label_key())).clicked()
                            {
                                self.replace(Replacement::Example(example));
                                ui.close();
                            }
                        }
                    })
                    .response
                    .widget_info(|| {
                        egui::WidgetInfo::labeled(
                            egui::Role::ComboBox,
                            true,
                            language.text("routing_examples"),
                        )
                    });
                if ui.button(language.text("runtime_menu")).clicked() {
                    self.runtime_ui.open = true;
                }
                if ui.button(language.text("export_network")).clicked() {
                    self.export_ui.open = true;
                }
                if ui
                    .button(format!("{} · F1", language.text("help")))
                    .clicked()
                {
                    self.toggle_help();
                }
            });
            ui.horizontal_wrapped(|ui| {
                for (mode, label) in [
                    (Mode::Design, format!("{} · F2", language.text("design"))),
                    (
                        Mode::Simulation,
                        format!("{} · F3", language.text("simulation")),
                    ),
                    (
                        Mode::Documentation,
                        format!("{} · F4", language.text("documentation")),
                    ),
                ] {
                    if ui.selectable_label(self.mode == mode, label).clicked() {
                        self.set_mode(mode);
                    }
                }
                ui.separator();
                let dirty = if self.editor.dirty() {
                    format!(" • {}", language.text("modified"))
                } else {
                    String::new()
                };
                ui.label(format!(
                    "{}{} · {}",
                    self.project().name,
                    dirty,
                    language
                        .format(
                            "revision",
                            &[("revision", &self.editor.revision().to_string())]
                        )
                        .unwrap()
                ));
            });
            if self.mode == Mode::Simulation {
                ui.horizontal_wrapped(|ui| {
                    if ui
                        .button(if self.worker.view.running {
                            language.text("pause")
                        } else {
                            language.text("resume")
                        })
                        .clicked()
                    {
                        self.worker.submit(Job::Running(!self.worker.view.running));
                    }
                    if ui
                        .add_enabled(
                            !self.worker.view.running,
                            egui::Button::new(language.text("step")),
                        )
                        .clicked()
                    {
                        self.worker.submit(Job::Step);
                    }
                    if ui.button(language.text("stop")).clicked() {
                        self.set_mode(Mode::Design);
                    }
                    ui.label(language.text("speed"));
                    if ui
                        .add(
                            egui::Slider::new(&mut self.speed, 1..=100)
                                .suffix("×")
                                .text(language.text("speed")),
                        )
                        .changed()
                    {
                        self.worker.submit(Job::Speed(self.speed));
                    }
                    let loss = ui.button(language.text("drop_hold"));
                    if loss.clicked() {
                        self.runtime_ui.preserve_manual_loss = false;
                    }
                    let held = self.runtime_ui.preserve_manual_loss
                        || loss.is_pointer_button_down_on()
                        || (loss.has_focus() && ui.input(|i| i.key_down(egui::Key::Space)));
                    if held != self.manual_loss {
                        self.manual_loss = held;
                        self.worker
                            .submit(Job::Command(Command::ManualLoss { enabled: held }));
                    }
                    ui.label(if self.manual_loss {
                        language.text("loss_on")
                    } else if self
                        .worker
                        .view
                        .link_conditions
                        .values()
                        .any(|c| c.loss_ppm > 0)
                    {
                        language.text("link_conditions_active")
                    } else {
                        language.text("loss_off")
                    });
                });
                ui.label(format!(
                    "{} · {}",
                    self.worker.view.run_id.as_str(),
                    language
                        .format(
                            "runtime",
                            &[
                                ("time", &self.worker.view.now.to_string()),
                                ("pending", &self.worker.view.pending.to_string()),
                                ("facts", &self.trace().len().to_string()),
                                (
                                    "state",
                                    language.text(if self.worker.view.running {
                                        "running"
                                    } else {
                                        "paused"
                                    })
                                )
                            ]
                        )
                        .unwrap()
                ));
            } else {
                ui.horizontal(|ui| {
                    if ui
                        .add_enabled(
                            self.editor.can_undo(),
                            egui::Button::new(language.text("undo")),
                        )
                        .clicked()
                    {
                        self.editor.undo();
                        self.refresh_draft();
                    }
                    if ui
                        .add_enabled(
                            self.editor.can_redo(),
                            egui::Button::new(language.text("redo")),
                        )
                        .clicked()
                    {
                        self.editor.redo();
                        self.refresh_draft();
                    }
                    ui.label(language.text("persistent_hint"));
                });
            }
            ui.horizontal(|ui| {
                for (page, label) in [
                    (Page::Topology, language.text("topology")),
                    (Page::Trace, language.text("exchanges")),
                    (Page::Tables, language.text("tables")),
                    (Page::Desktop, language.text("desktop")),
                ] {
                    ui.selectable_value(&mut self.page, page, label);
                }
            });
            if let Some(error) = self.error.as_ref().or(self.worker.view.error.as_ref()) {
                ui.horizontal_wrapped(|ui| {
                    ui.colored_label(
                        Color32::LIGHT_RED,
                        language
                            .format("error", &[("message", &language.describe_error(error))])
                            .unwrap(),
                    );
                });
            }
            if let Some(error) = &self.settings_error {
                ui.label(
                    language
                        .format(
                            "settings_error",
                            &[("error", &language.describe_error(error))],
                        )
                        .unwrap(),
                );
            }
            ui.separator();
            self.desktop.top = ui.cursor().top();
            if self.page == Page::Trace {
                self.trace_ui(ui);
            } else if self.page == Page::Desktop {
                self.desktop_ui(ui);
            } else if self.page == Page::Tables {
                egui::ScrollArea::both().show(ui, |ui| {
                    ui.monospace(&self.worker.view.tables);
                });
            } else {
                self.topology_layout(ui);
            }
        });
        self.application_windows(ui.ctx());
        self.journey_window(ui.ctx());
        self.session_window(ui.ctx());
        self.help_window(ui.ctx());
        self.preferences_window(ui.ctx());
        self.configuration_window(ui.ctx());
        if self.close_confirmed && self.session_close_ready(ui.ctx()) {
            ui.ctx().send_viewport_cmd(egui::ViewportCommand::Close);
        }
        if let Some(action) = self.pending {
            egui::Modal::new(ui.scope_id().with("unsaved-project")).show(ui.ctx(), |ui| {
                ui.heading(language.text("unsaved_title"));
                ui.label(language.text("unsaved_prompt"));
                if ui
                    .add_enabled(
                        !self.desktop.dirty(),
                        egui::Button::new(language.text("save_continue")),
                    )
                    .clicked()
                    && self.save(false)
                {
                    self.pending = None;
                    self.replace_now(action);
                }
                if ui.button(language.text("discard")).clicked() {
                    if matches!(action, Replacement::Close) {
                        self.session_ui.discard_on_close = true;
                    }
                    self.pending = None;
                    self.replace_now(action);
                }
                if matches!(action, Replacement::Close)
                    && self.session_enabled()
                    && ui.button(language.text("session_keep_and_close")).clicked()
                {
                    self.pending = None;
                    self.session_ui.discard_on_close = false;
                    self.close_confirmed = true;
                }
                if ui.button(language.text("continue_editing")).clicked() {
                    self.pending = None;
                }
            });
        }
        if !self.close_confirmed {
            self.tick_session(ui.ctx());
        }
    }
    pub fn request_close(&mut self) {
        self.replace(Replacement::Close);
    }
}
