# État de reprise — Sinesi

## Situation courante — 9 novembre 2026

**J1 à J6 sont qualifiés localement. J7 reste ouvert.** La configuration de démarrage
est qualifiée après les préférences d’affichage, l’aide et les rapports PDF. FR EN ES IT PT DE et les vues
Icônes/Schéma sont conservés.

| Registre de référence | État |
| --- | --- |
| [178 exigences](features.json) | **158 verified**, 1 implemented, 3 in_progress, 16 not_started |
| [50 lots Rust](../rust/taches.json) | **43 verified**, 3 in_progress, 2 not_started, 2 deferred |
| J7 | **16 exigences vérifiées sur 22**, 1 implémentée partiellement, 1 en cours, 4 non démarrées |
| Lots en cours | RS-QUALITY-J0, RS-PROJECTS-J7, RS-PLATFORM-J7 |

Les registres et leurs preuves sont l’autorité. Les résumés historiques ne ferment
pas une exigence; [leur chronologie antérieure](ETAT-HISTORIQUE-2026-11-08.md) est conservée.

## Dernière tranche : facteur d’attente RTT

**F-CFG-005 / RS-PLATFORM-J7 restent en cours; r est réalisé et qualifié.** Le
[contrat portable](../agnostique/ATTENTES_J7.md), l’[adaptateur](../rust/ATTENTES_J7.md),
[D-014](../rust/decisions/D-014-attentes-j7.md) et les
[preuves](../verification/J7-ATTENTES.md) décrivent `-r/--rtt-factor` 1–5. Les
attentes ARP, ICMP, TCP, DHCP et applicatives sont étendues en temps virtuel. Les
câbles, durées de vie, cadence RIP et intervalle du ping du terminal sont conservés.
Sur le réseau lent de recette, le facteur 1 expire avant la réponse ARP; le facteur 5
obtient un ping. Rejeu et continuation reproduisent exactement la trace.

Le moteur, le workbench, les lanceurs et les schémas sont raccordés. L’exécution
standard garde les formats 1; les versions 2 stockent le facteur étendu dans le
journal et le checkpoint. La reprise privilégie la politique enregistrée; un nouveau
réseau reprend celle du lancement. Les préférences ne reçoivent pas cette option.

Qualification locale : 38 tests ciblés, **274 tests workspace plus un enfant du pont**,
cinq ignorés, Clippy sans avertissement; **22 tests GPU et 108 références** comparées.
Six aides et douze rapports natifs sans fenêtre, **851 clés × six langues**;
**496 PNG antérieurs inchangés**. Registres et inventaire contrôlés avec le référentiel.
Le manifeste courant contient **790 fichiers**, révision `sha256:bbd20f87e9e141f1b10d02655d53e95a0c94199ac7418a8018e905aa7eb2bf05`.
Le workspace reste à 20 membres et aucun paquet tiers ne change.

Prochaine tranche : v/l et le diagnostic technique F-CFG-006, puis n/s. J7 reste
ouvert; l’import, les exemples et la livraison gardent leurs validations restantes.

## Dernière revue structurelle — 9 novembre 2026

**RS-QUALITY-J0 reste en cours; F-NFR-002/008 conservent leur qualification.** La
[comparaison actualisée](../rust/REVUE_STRUCTURE_2026_11.md) relit les quatre fichiers
SolidCraft/WordCraft à des révisions figées et ordonne les extractions suivantes.
Le contrôle des couches active désormais toutes les fonctionnalités Cargo : une
GUI optionnelle désactivée par défaut ne peut plus lui échapper. Les métadonnées
des membres héritent aussi de la racine. AGENTS, le guide, la décision D-011 et les
deux scripts de politique sont actualisés; aucun fichier Rust ni manifeste Cargo
ne change dans cette tranche.

[Preuves](../verification/STRUCTURE-REVUE-2026-11.md) : douze tests de politique,
`cargo xtask ci` réussi localement, Clippy sans avertissement, 265 tests workspace
plus un enfant du pont, cinq ignorés, quatre PNG contrôlés. Les 496 PNG du manifeste
précédent, les catalogues FR EN ES IT PT DE et les contrats restent identiques.
Aucun test GPU supplémentaire n’est revendiqué pour cette modification d’outillage.
Le manifeste de cette revue contient **787 fichiers**, révision
`sha256:40cc7928a7359d07ae577db0e47b05f5701e34c821bade2937ac0adc05cc83de`.
Les identifiants, `planned_paths` et statuts des deux registres sont préservés.
La prochaine extraction structurelle vise les dialogues natifs encore synchrones
sans créer un second chemin d’opérations de document. Les options J7 ci-dessous
restent la prochaine tranche fonctionnelle; cette revue ne les réalise pas.

## Dernière tranche : configuration de démarrage

**F-CFG-004 est vérifié; F-CFG-005 et RS-PLATFORM-J7 restent en cours.** Le
[profil portable](../agnostique/CONFIGURATION_J7.md), l’[adaptateur](../rust/CONFIGURATION_J7.md),
[D-013](../rust/decisions/D-013-configuration-j7.md) et la
[qualification](../verification/J7-CONFIGURATION.md) fixent les priorités intégrées /
administrateur / utilisateur / CLI, les valeurs sûres et les diagnostics localisés.
L’état avant CLI est distinct de l’affichage effectif; les modifications UI ne
copient pas les options temporaires sans rapport dans le profil.

Le lanceur propose aide, version longue, contrôle sans fenêtre, chemins, répertoire
de travail et options d’affichage. Il partage la résolution et le constructeur du
projet avec l’interface. Les fichiers sont préservés sur invalidité et protégés selon
leur rôle, y compris après traversée `..` et liens. Les clics ordinaires dans l’aide
ne mémorisent plus de géométrie temporaire; un déplacement réel reste enregistré.

Fichiers principaux : `sns-settings/src/configuration.rs`, `workbench/configuration_ui.rs`,
`apps/sns-desktop/src/launch.rs`, point d’entrée natif, contrats/fixtures et recettes.
Les chemins précis sont dans le registre Rust. Les préférences d’affichage restent
qualifiées dans leur [rapport](../verification/J7-AFFICHAGE.md).

Qualification : **265 tests workspace et un enfant**, cinq ignorés, Clippy sans
avertissement et contrôles réussis; **21 tests de la suite graphique**, **108 captures
comparées sans mise à jour**, dont **12 nouvelles**, **483 anciennes images inchangées**;
**849 clés × six langues**. Le vrai binaire est testé sans fenêtre, avec les six
langues, le projet effectivement chargé, les valeurs invalides et les chemins.
Six aides et douze rapports réels sont aussi enregistrés, entrées inchangées.

Manifeste : **787 fichiers**,
`sha256:e4b36f5f1bf57c7a268f27ce0bd12dcb529ad9e170e071e84d69c9c7fcff48d2`.
Le workspace reste à **20 membres**; aucun paquet tiers ajouté, retiré ou changé.

## Socle et périmètre déjà qualifié

La [décision D-011](../rust/decisions/D-011-structure-et-workflow.md), le
[guide de développement](../rust/DEVELOPPEMENT.md) et la [carte actuelle](../rust/ARCHITECTURE.md)
fixent les responsabilités et les vérifications communes. Le [complément de politique](../verification/STRUCTURE-POLITIQUE-2026-11.md)
refuse une catégorie mal orthographiée avant l’analyse du graphe.

- [Import](../verification/J7-IMPORT-EN-COURS.md) : données ZIP/XML bornées, original préservé, rapport de pertes; **F-PROJ-005 reste implemented**, pas verified.
- [Scénarios/reprise/rejeu](../verification/J7-REPRISE-EN-COURS.md) et [pannes de liaison](../verification/J7-PANNES.md) : F-SIM-007/008.
- [Duplication/alignement](../verification/J7-TOPOLOGIE.md) et [nuage](../verification/J7-PRESENTATION.md) : F-TOP-009, F-EQU-008.
- [Observation](../verification/J7-OBSERVATION.md) et [diagnostic interne](../verification/J7-TERMINAL.md) : F-OBS-006/008, F-CLI-019.
- [Session/récupération](../verification/J7-SESSION.md) : F-PROJ-003/006.
- [Notes/zones](../verification/J7-ANNOTATIONS.md), [PNG](../verification/J7-PNG.md) et [PDF](../verification/J7-RAPPORT.md) : F-DOC-001/002/003/004.
- [Aide contextuelle et informations](../verification/J7-AIDE.md) : F-CFG-002; F1 et Échap préservent une saisie active.

## Prochaine action et limites

Poursuivre **RS-PLATFORM-J7** avec **F-CFG-005**, intentions v/l/n/s encore absentes :
verbosité, fichier de journal annoncé, apparence système et petit écran.
h/w et le fichier natif sont raccordés; `--version` utilise une option longue.
Les prérequis F-PROJ-001 et RS-PROJECTS-J1 sont vérifiés. Le profil 2 et la séparation
des options temporaires doivent être conservés. La politique RTT réalisée reste
distincte de la vitesse d’affichage et appartient à la provenance du rejeu.
Puis traiter F-CFG-006, diagnostic technique et export, sans le confondre avec la
trace réseau ou les données pédagogiques. Les repères d’archive sont dans l’adaptateur d’aide.

Restent aussi couverture sémantique de l’import, diagnostics, exemples, packaging
et parcours réels sur trois OS. F-NFR-001/006 et RS-QUALITY-J0 restent en cours.
La suite GPU historique complète et l’accessibilité globale doivent être réconciliées
avec J7. La commande graphique ciblée couvre PNG, PDF, aide, préférences et configuration.
Les fenêtres d’une même catégorie partagent leur géométrie initiale; les dimensions
principales viennent du panneau et ne suivent pas automatiquement les gestes natifs.
Le zoom réseau reste distinct de la taille des widgets.

Aucun sélecteur natif nouvellement manipulé, parcours manuel autonome,
résultat Windows/Linux ou run distant n’est revendiqué. Les sockets hôte restent
réservées au pont explicitement activé. Les archives Filius et network-kit restent
en lecture seule; ni audit recalculé, ni commit, push ou publication effectués.
