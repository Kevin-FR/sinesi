# J7 en cours — import, scénarios, rejeu et livraison

Le périmètre intégral reste celui de [PROJETS_J7](../agnostique/PROJETS_J7.md) et de la roadmap. Première tranche : import `.fls` dans `sns-filius-import`, branche CLI et import en arrière-plan dans la GUI. Aucun checkpoint, autosauvegarde, export PDF/PNG ou résultat multiplateforme n’est encore annoncé pour J7.

## Import

`sns-filius-import` prend des octets et un nom de source, puis renvoie `Project` et `ImportReport`. Le crate ne fait aucune I/O hôte. `archive.rs` borne le ZIP, ses noms et la décompression; `xml.rs` construit un arbre en lecture seule et résout les références; `convert.rs` et `mail.rs` contiennent les correspondances explicites. Les propriétés non utilisées restent dans le rapport et les octets des entrées sont conservés dans les ressources.

Le lockfile fixe `zip 9.4.1` (sans fonctionnalités par défaut, Deflate) et `roxmltree 0.20.0`, déjà présent dans le graphe de rendu. La configuration de l’analyseur refuse les DTD et borne les nœuds; le préfiltre refuse aussi les déclarations d’entités. Les décisions de noms/tailles/chemins et références restent dans SNS, indépendamment des protections de bibliothèque. Voir la [documentation ZIP](https://docs.rs/zip/9.4.1/zip/struct.ZipArchive.html) et les [options XML](https://docs.rs/roxmltree/0.20.0/roxmltree/struct.ParsingOptions.html).

`Editor::mark_unsaved` distingue une importation encore sans fichier utilisateur d’un projet enregistré. `import_ui.rs` utilise un canal borné et un fil de traitement; le résultat validé est publié d’un bloc, les erreurs conservent le projet antérieur. Le rapport affiche écarts, champs, classes et pièces dans les six langues et peut être exporté en JSON. Les vues Icônes/Schéma restent des projections.

```sh
cargo run -p sns-cli --locked --offline -- import-filius source.fls --output converted.sinesi.json --report coverage.json
cargo test -p sns-filius-import --locked --offline
SNS_RECORD_J7_IMPORT="$PWD/docs/verification/j7-import-corpus.json" SNS_RECORD_J7_IMPORT_DIR="$PWD/docs/verification" cargo test -p sns-filius-import --test import --locked --offline -- --ignored
cargo test -p sns-ui-egui --features ui-snapshots --test lan j7_background --locked --offline
```

Les deux tests ignorés par défaut nécessitent `_archive/filius-master` : corpus des 20 fichiers et ping du LAN historique. Ils échouent si l’archive manque lorsqu’on les demande explicitement. Les tests ordinaires utilisent une fixture ZIP/XML synthétique propre à Sinesi et couvrent import, références, champs inconnus, pièces inactives, corruption, chemins, entités, quotas et vrai ping simulé. Le corpus, ses sources et son runtime ne sont pas redistribués.

## Suites requises

Finaliser la couverture sémantique d’import et ses écarts. Puis réaliser état complet/checkpoint/rejeu et pannes, récupération/session, annotations et scène commune d’export, filtres structurés/parcours, duplication/alignement, préférences/aide/CLI/diagnostics, exemples et packaging. Ne pas fermer RS-PROJECTS-J7 sur la seule présence de l’importeur. La validation Windows/Linux/macOS doit être fondée sur des résultats réellement obtenus.
