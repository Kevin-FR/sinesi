//! Mail settings are data. Historical messages and extra identities remain in the loss report.
use super::*;
use crate::{
    convert::{issue, scalar},
    xml::Source,
};
use roxmltree::Node;
pub(super) fn configuration(
    s: &Source<'_>,
    bean: Node<'_, '_>,
    software: Software,
    target: &str,
    report: &mut ImportReport,
) -> Result<Option<ServiceConfig>, Diagnostic> {
    let list = s.prop(
        bean,
        if software == Software::MailServer {
            "listeBenutzerkonten"
        } else {
            "kontoListe"
        },
        target,
    )?;
    let Some(list) = list else {
        issue(
            report,
            s,
            bean,
            "import.unsupported_data",
            "mail_accounts_require_configuration",
        );
        return Ok(None);
    };
    let accounts = list
        .children()
        .filter(|n| n.attribute("method") == Some("add"))
        .map(|n| s.view(n))
        .collect::<Result<Vec<_>, _>>()?;
    if software == Software::MailServer {
        let mut cfg = MailServerConfig {
            domain: scalar(s, bean, "mailDomain", target, "filius.de")?
                .trim_end_matches('.')
                .to_ascii_lowercase(),
            smtp_port: 25,
            pop3_port: 110,
            accounts: vec![],
        };
        for a in accounts {
            cfg.accounts.push(MailAccount {
                username: scalar(s, a, "benutzername", target, "")?,
                password: scalar(s, a, "passwort", target, "")?,
                first_name: scalar(s, a, "vorname", target, "")?,
                last_name: scalar(s, a, "nachname", target, "")?,
            });
        }
        Ok(Some(ServiceConfig::MailServer(cfg)))
    } else {
        let Some(a) = accounts.first().copied() else {
            issue(
                report,
                s,
                bean,
                "import.unsupported_data",
                "mail_identity_requires_configuration",
            );
            return Ok(None);
        };
        if accounts.len() > 1 {
            issue(
                report,
                s,
                bean,
                "import.unsupported_data",
                "additional_mail_identities_preserved_in_original",
            );
        }
        let cfg = MailClientConfig {
            address: scalar(s, a, "emailAdresse", target, "")?,
            display_name: format!(
                "{} {}",
                scalar(s, a, "vorname", target, "")?,
                scalar(s, a, "nachname", target, "")?
            )
            .trim()
            .to_string(),
            smtp_server: scalar(s, a, "smtpserver", target, "")?,
            smtp_port: scalar(s, a, "smtpport", target, "25")?.parse().unwrap_or(0),
            pop3_server: scalar(s, a, "pop3server", target, "")?,
            pop3_port: scalar(s, a, "pop3port", target, "110")?
                .parse()
                .unwrap_or(0),
            username: scalar(s, a, "benutzername", target, "")?,
            password: scalar(s, a, "passwort", target, "")?,
        };
        Ok(Some(ServiceConfig::MailClient(cfg)))
    }
}
