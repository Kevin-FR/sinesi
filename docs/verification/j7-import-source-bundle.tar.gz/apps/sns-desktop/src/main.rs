use eframe::egui;
enum Workbench {
    Lan(Box<sns_ui_egui::LanUi>),
    Prototype(Box<sns_ui_egui::SinesiUi>),
}
struct Desktop {
    ui: Workbench,
}
impl eframe::App for Desktop {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        match &mut self.ui {
            Workbench::Lan(app) => app.show(ui),
            Workbench::Prototype(app) => app.show(ui),
        }
    }
}
fn main() -> eframe::Result {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Sinesi — Simple network simulator")
            .with_inner_size([1320.0, 880.0])
            .with_min_inner_size([1050.0, 650.0]),
        ..Default::default()
    };
    eframe::run_native(
        "Sinesi",
        options,
        Box::new(|context| {
            context.egui_ctx.set_visuals(egui::Visuals::dark());
            Ok(Box::new(Desktop {
                ui: if std::env::args().any(|arg| arg == "--prototype-j0") {
                    Workbench::Prototype(Box::new(
                        sns_ui_egui::SinesiUi::new().map_err(std::io::Error::other)?,
                    ))
                } else {
                    Workbench::Lan(Box::new(
                        sns_ui_egui::LanUi::native().map_err(std::io::Error::other)?,
                    ))
                },
            }))
        }),
    )
}
