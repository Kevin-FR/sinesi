param(
    [Parameter(Mandatory = $true)][string]$Package,
    [Parameter(Mandatory = $true)][string]$WorkDirectory
)
$ErrorActionPreference = 'Stop'
$prog = 'HKCU:\Software\Classes\Sinesi.Project'
if (Test-Path $prog) { throw 'Sinesi is already registered for this user' }
$root = [IO.Path]::GetFullPath($WorkDirectory)
$install = Join-Path $root 'app'
$exercise = Join-Path $root 'exercise'
$installer = (Resolve-Path -LiteralPath $Package).Path
$setup = Start-Process -Wait -PassThru -FilePath $installer -ArgumentList @(
    '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', ('/DIR="{0}"' -f $install)
)
if ($setup.ExitCode -ne 0) { throw "Installer failed ($($setup.ExitCode))" }
try {
    $desktop = Join-Path $install 'sns-desktop.exe'
    $cli = Join-Path $install 'sinesi.exe'
    $expected = '"' + $desktop + '" -- "%1"'
    $registered = (Get-Item -LiteralPath "$prog\shell\open\command").GetValue('')
    if ($registered -ne $expected) { throw "Incorrect command: $registered" }
    $extension = 'HKCU:\Software\Classes\.sinesi\OpenWithProgids'
    if ((Get-Item -LiteralPath $extension).GetValue('Sinesi.Project', $null) -ne '') {
        throw 'The project association was not registered'
    }
    python packaging/smoke.py --desktop $desktop --cli $cli --exercise-dir $exercise
    if ($LASTEXITCODE -ne 0) { throw "Packaged binaries failed ($LASTEXITCODE)" }
    $project = Get-ChildItem -LiteralPath $exercise -Filter '*.sinesi' -File
    $hash = (Get-FileHash -LiteralPath $project.FullName).Hash
} finally {
    $uninstall = Start-Process -Wait -PassThru -FilePath (Join-Path $install 'unins000.exe') -ArgumentList @(
        '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART'
    )
    if ($uninstall.ExitCode -ne 0) { throw "Uninstaller failed ($($uninstall.ExitCode))" }
}
if ((Test-Path $prog) -or (Test-Path -LiteralPath $desktop)) { throw 'Uninstall left Sinesi registered or installed' }
if ((Get-FileHash -LiteralPath $project.FullName).Hash -ne $hash) { throw 'Uninstall changed the project' }
Write-Output 'OK — Sinesi uninstalled and the project was preserved'
