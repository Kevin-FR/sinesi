param(
    [Parameter(Mandatory = $true)][string]$Package,
    [Parameter(Mandatory = $true)][string]$WorkDirectory
)
$ErrorActionPreference = 'Stop'

function Test-AssociatedWindow([string]$Project, [string]$Desktop, [string]$Exercise) {
    Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

public static class SinesiShellSmoke {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct ShellExecuteInfo {
        public uint Size, Mask;
        public IntPtr Window;
        public string Verb, File, Parameters, Directory;
        public int Show;
        public IntPtr Instance, ItemList;
        public string ClassName;
        public IntPtr ClassKey;
        public uint HotKey;
        public IntPtr IconOrMonitor, ProcessHandle;
    }
    [DllImport("shell32.dll", ExactSpelling = true, SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern bool ShellExecuteExW(ref ShellExecuteInfo info);
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern uint GetProcessId(IntPtr process);
    [DllImport("kernel32.dll")]
    private static extern bool CloseHandle(IntPtr handle);

    public static Process Open(string project) {
        const uint ClassName = 0x00000001, NoCloseProcess = 0x00000040;
        const uint NoAsync = 0x00000100, NoErrorDialog = 0x00000400;
        var info = new ShellExecuteInfo {
            Size = (uint)Marshal.SizeOf(typeof(ShellExecuteInfo)),
            Mask = ClassName | NoCloseProcess | NoAsync | NoErrorDialog,
            Verb = "open", File = project, ClassName = "Sinesi.Project", Show = 1
        };
        if (!ShellExecuteExW(ref info)) throw new Win32Exception(Marshal.GetLastWin32Error());
        if (info.ProcessHandle == IntPtr.Zero) throw new InvalidOperationException("No shell process");
        try {
            uint pid = GetProcessId(info.ProcessHandle);
            if (pid == 0) throw new Win32Exception(Marshal.GetLastWin32Error());
            return Process.GetProcessById((int)pid);
        } finally {
            CloseHandle(info.ProcessHandle);
        }
    }
}
'@
    $settings = $env:SINESI_SETTINGS_PATH
    $sessions = $env:SINESI_SESSION_DIR
    try {
        $env:SINESI_SETTINGS_PATH = Join-Path $Exercise 'settings.json'
        $env:SINESI_SESSION_DIR = Join-Path $Exercise 'sessions'
        # Select the registered handler without changing the user's default app.
        $process = [SinesiShellSmoke]::Open($Project)
    } finally {
        $env:SINESI_SETTINGS_PATH = $settings
        $env:SINESI_SESSION_DIR = $sessions
    }
    try {
        $command = (Get-CimInstance Win32_Process -Filter "ProcessId = $($process.Id)").CommandLine
        if ($process.MainModule.FileName -ne $Desktop -or
            -not $command.EndsWith((' -- "{0}"' -f $Project), [StringComparison]::OrdinalIgnoreCase)) {
            throw 'The shell did not launch the expected executable and project'
        }
        $deadline = [DateTime]::UtcNow.AddSeconds(20)
        do {
            $process.Refresh()
            if ($process.HasExited) { throw "Desktop exited ($($process.ExitCode))" }
            if ($process.MainWindowHandle -ne 0) {
                Write-Output 'OK — the Windows shell opened the associated project in Sinesi'
                return
            }
            Start-Sleep -Milliseconds 100
        } while ([DateTime]::UtcNow -lt $deadline)
        throw 'Sinesi did not show its main window'
    } finally {
        if (-not $process.HasExited) {
            $null = $process.CloseMainWindow()
            if (-not $process.WaitForExit(5000)) { $process.Kill(); $process.WaitForExit() }
        }
        $process.Dispose()
    }
}

$prog = 'HKCU:\Software\Classes\Sinesi.Project'
if (Test-Path $prog) { throw 'Sinesi is already registered for this user' }
$root = [IO.Path]::GetFullPath($WorkDirectory)
$install = Join-Path $root 'app'
$exercise = Join-Path $root 'exercise'
$installer = (Resolve-Path -LiteralPath $Package).Path
$setup = Start-Process -Wait -PassThru -FilePath $installer -ArgumentList @(
    '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', ('/DIR="{0}"' -f $install)
)
if ($setup.ExitCode -ne 0) { throw "Installer failed ($($setup.ExitCode))" }
try {
    $desktop = Join-Path $install 'sns-desktop.exe'
    $cli = Join-Path $install 'sinesi.exe'
    $expected = '"' + $desktop + '" -- "%1"'
    $registered = (Get-Item -LiteralPath "$prog\shell\open\command").GetValue('')
    if ($registered -ne $expected) { throw "Incorrect command: $registered" }
    $extension = 'HKCU:\Software\Classes\.sinesi\OpenWithProgids'
    if ((Get-Item -LiteralPath $extension).GetValue('Sinesi.Project', $null) -ne '') {
        throw 'The project association was not registered'
    }
    python packaging/smoke.py --desktop $desktop --cli $cli --exercise-dir $exercise
    if ($LASTEXITCODE -ne 0) { throw "Packaged binaries failed ($LASTEXITCODE)" }
    $project = Get-ChildItem -LiteralPath $exercise -Filter '*.sinesi' -File
    $hash = (Get-FileHash -LiteralPath $project.FullName).Hash
    Test-AssociatedWindow $project.FullName $desktop $exercise
} finally {
    $uninstall = Start-Process -Wait -PassThru -FilePath (Join-Path $install 'unins000.exe') -ArgumentList @(
        '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART'
    )
    if ($uninstall.ExitCode -ne 0) { throw "Uninstaller failed ($($uninstall.ExitCode))" }
}
if ((Test-Path $prog) -or (Test-Path -LiteralPath $desktop)) { throw 'Uninstall left Sinesi registered or installed' }
$extensionKey = Get-Item -LiteralPath $extension -ErrorAction SilentlyContinue
if ($extensionKey -and $null -ne $extensionKey.GetValue('Sinesi.Project', $null)) {
    throw 'Uninstall left the Sinesi Open With entry'
}
if ((Get-FileHash -LiteralPath $project.FullName).Hash -ne $hash) { throw 'Uninstall changed the project' }
Write-Output 'OK — Sinesi uninstalled and the project was preserved'
