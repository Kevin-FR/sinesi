//! J1 topology workbench. Editing is transactional; simulation runs on a worker.
#[path = "annotations.rs"]
mod annotations;
#[path = "export_ui.rs"]
mod export_ui;
pub use export_ui::PngReceipt;
#[path = "desktop.rs"]
mod desktop;
#[path = "import_ui.rs"]
mod import_ui;
#[path = "link_conditions_ui.rs"]
mod link_conditions_ui;
#[path = "presentation_ui.rs"]
mod presentation_ui;
#[path = "routing_ui.rs"]
mod routing_ui;
#[path = "runtime_ui.rs"]
mod runtime_ui;
#[path = "security_ui.rs"]
mod security_ui;
#[path = "session_ui.rs"]
mod session_ui;
#[path = "topology_ui.rs"]
mod topology_ui;
#[path = "trace_ui.rs"]
mod trace_ui;
use crate::lan_worker::{Job, Worker};
use egui::{Color32, Pos2, Rect, Sense, Stroke, Vec2};
use sns_i18n::Language;
use sns_model::*;
use sns_topology::{Edit, Editor, display_label};
use std::{collections::BTreeSet, path::PathBuf};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    Design,
    Simulation,
    Documentation,
}
#[derive(Clone, Copy, PartialEq)]
enum Page {
    Topology,
    Trace,
    Tables,
    Desktop,
}
#[derive(Clone, Copy)]
enum Replacement {
    RecoverSession,
    New,
    Open,
    ImportFilius,
    LoadScenario,
    RestoreCheckpoint,
    ReplayRecording,
    Example,
    HostsExample,
    RoutedExample,
    RipExample,
    ClassroomExample,
    ServicesExample,
    PrivateExample,
    MailExample,
    P2pExample,
    WirelessExample,
    Close,
}
struct Drag {
    origin: Pos2,
    positions: Vec<Position>,
}
pub struct LanUi {
    export_ui: export_ui::ExportUi,
    annotations: annotations::AnnotationUi,
    session_ui: session_ui::SessionUi,
    observation: trace_ui::ObservationUi,
    duplicate_omitted: usize,
    conditions_ui: link_conditions_ui::ConditionsUi,
    runtime_ui: runtime_ui::RuntimeUi,
    import_ui: import_ui::ImportUi,
    desktop: desktop::DesktopState,
    synced_revision: u64,
    art: crate::network_art::NetworkArt,
    routing_ui: routing_ui::RoutingUi,
    security_ui: security_ui::SecurityUi,
    language: Language,
    settings_path: Option<PathBuf>,
    settings_writable: bool,
    settings_error: Option<String>,
    editor: Editor,
    worker: Worker,
    pub mode: Mode,
    page: Page,
    selected: BTreeSet<Id>,
    draft: Option<(Device, LanConfig)>,
    cable: Option<Id>,
    cabling: bool,
    zoom: f32,
    pan: Vec2,
    drag: Option<Drag>,
    preview: Vec<Position>,
    rectangle: Option<Pos2>,
    target: String,
    ttl: u8,
    speed: u32,
    manual_loss: bool,
    path: Option<PathBuf>,
    error: Option<String>,
    traffic: crate::traffic::TrafficFilter,
    observed_trace: usize,
    active_links: std::collections::BTreeMap<Id, f64>,
    filter: String,
    event_index: Option<usize>,
    help: bool,
    annotation: String,
    pending: Option<Replacement>,
    fit: bool,
    close_confirmed: bool,
}
impl LanUi {
    pub fn new() -> Result<Self, String> {
        let project =
            sns_project::parse_project(include_bytes!("../../../fixtures/valid/lan.json"))
                .map_err(|e| e.to_string())?;
        Self::from_project(project)
    }
    pub fn from_project(project: Project) -> Result<Self, String> {
        Ok(Self {
            export_ui: Default::default(),
            annotations: Default::default(),
            session_ui: Default::default(),
            observation: Default::default(),
            duplicate_omitted: 0,
            conditions_ui: Default::default(),
            runtime_ui: Default::default(),
            import_ui: Default::default(),
            desktop: Default::default(),
            synced_revision: 0,
            art: Default::default(),
            routing_ui: Default::default(),
            security_ui: Default::default(),
            language: Language::Fr,
            settings_path: None,
            settings_writable: true,
            settings_error: None,
            editor: Editor::new(project.clone()).map_err(|e| e.to_string())?,
            worker: Worker::new(project)?,
            mode: Mode::Design,
            page: Page::Topology,
            selected: BTreeSet::new(),
            draft: None,
            cable: None,
            cabling: false,
            zoom: 1.,
            pan: Vec2::ZERO,
            drag: None,
            preview: vec![],
            rectangle: None,
            target: "192.168.1.3".into(),
            ttl: 64,
            speed: 1,
            manual_loss: false,
            path: None,
            error: None,
            traffic: Default::default(),
            observed_trace: 0,
            active_links: Default::default(),
            filter: String::new(),
            event_index: None,
            help: false,
            annotation: String::new(),
            pending: None,
            fit: true,
            close_confirmed: false,
        })
    }
    pub fn native() -> Result<Self, String> {
        Self::native_with_project(None)
    }
    pub fn native_with_project(project: Option<PathBuf>) -> Result<Self, String> {
        Self::with_storage(
            sns_settings::default_path(),
            sns_settings::default_session_directory(),
            project,
        )
    }
    pub fn with_preferences(path: Option<PathBuf>) -> Result<Self, String> {
        let mut app = Self::new()?;
        if let Some(path) = &path {
            match sns_settings::load(path) {
                Ok(s) => app.language = s.language,
                Err(e) => {
                    app.settings_error = Some(e);
                    app.settings_writable = false;
                }
            }
        }
        app.settings_path = path;
        Ok(app)
    }
    pub fn language(&self) -> Language {
        self.language
    }
    pub fn choose_language(&mut self, language: Language) {
        self.language = language;
        if !self.settings_writable {
            return;
        }
        if let Some(path) = &self.settings_path {
            if self
                .path
                .as_ref()
                .is_some_and(|project| session_ui::same_destination(path, project))
            {
                self.settings_error = Some("settings.project_path_conflict".into());
                self.settings_writable = false;
                return;
            }
            self.settings_error = sns_settings::save(
                path,
                &sns_settings::Settings {
                    language,
                    ..Default::default()
                },
            )
            .err();
        }
    }
    fn device_label(&self, device: &Device) -> String {
        if self.mode == Mode::Simulation
            && self.worker.current()
            && let Some(effective) = self.worker.view.effective.device(&device.id)
        {
            return display_label(&self.worker.view.effective, effective);
        }
        display_label(self.project(), device)
    }
    pub fn project(&self) -> &Project {
        self.editor.project()
    }
    pub fn selected(&self) -> &BTreeSet<Id> {
        &self.selected
    }
    pub fn trace(&self) -> &[sns_engine::TraceEvent] {
        &self.worker.view.trace
    }
    pub fn run_id(&self) -> &Id {
        &self.worker.view.run_id
    }
    pub fn now(&self) -> u64 {
        self.worker.view.now
    }
    pub fn wait_for_worker(&mut self) -> Result<(), String> {
        self.worker.wait()?;
        self.sync_applications();
        Ok(())
    }
    fn sync_applications(&mut self) {
        if self.worker.current() && self.worker.view.revision > self.synced_revision {
            let start = if self.worker.view.trace.len() < self.observed_trace {
                0
            } else {
                self.observed_trace
            };
            let presentation_devices = self
                .worker
                .view
                .trace
                .iter()
                .skip(start)
                .filter(|e| e.kind == "presentation.symbol.changed")
                .map(|e| e.device_id.clone())
                .collect();
            match self
                .editor
                .accept_runtime((*self.worker.view.project).clone(), &presentation_devices)
            {
                Ok(()) => {
                    self.synced_revision = self.worker.view.revision;
                    if let Some((d, _)) = &self.draft
                        && let Some(updated) = self.editor.project().device(&d.id)
                    {
                        self.draft = Some((
                            updated.clone(),
                            self.editor
                                .project()
                                .lan
                                .get(&d.id)
                                .cloned()
                                .unwrap_or_default(),
                        ));
                    }
                }
                Err(e) => self.error = Some(e.to_string()),
            }
        }
    }
    fn apply(&mut self, edit: Edit) {
        if self.mode == Mode::Simulation {
            self.error = Some("state.editing_locked".into());
            return;
        }
        if self.mode == Mode::Documentation
            && !match &edit {
                Edit::Annotate(_) | Edit::AddAnnotation { .. } => true,
                Edit::Delete(ids) => ids
                    .iter()
                    .all(|id| self.project().annotations.iter().any(|a| &a.id == id)),
                _ => false,
            }
        {
            self.error = Some("state.editing_locked".into());
            return;
        }
        if self.worker.pending_commands() {
            self.error = Some("state.pending_commands".into());
            return;
        }
        match self.editor.apply(self.editor.revision(), edit) {
            Ok(outcome) => {
                self.duplicate_omitted = outcome.omitted_links.len();
                if !outcome.created.is_empty() {
                    self.selected = outcome.created;
                    self.refresh_draft();
                    self.fit = true;
                }
                self.error = None;
            }
            Err(e) => self.error = Some(e.to_string()),
        }
    }
    fn select(&mut self, id: Id, extend: bool) {
        self.annotations.draft = self
            .project()
            .annotations
            .iter()
            .find(|a| a.id == id)
            .cloned();
        self.routing_ui = Default::default();
        if !extend {
            self.selected.clear();
        }
        if extend && self.selected.contains(&id) {
            self.selected.remove(&id);
        } else {
            self.selected.insert(id.clone());
        }
        self.draft = self.project().device(&id).map(|d| {
            (
                d.clone(),
                self.project().lan.get(&id).cloned().unwrap_or_default(),
            )
        });
    }
    fn set_mode(&mut self, mode: Mode) {
        if self.mode == mode {
            return;
        }
        if mode == Mode::Simulation {
            self.worker.restart(self.project().clone());
            self.synced_revision = 0;
            self.manual_loss = false;
            self.traffic.after = 0;
            self.observed_trace = 0;
            self.active_links.clear();
        } else if self.mode == Mode::Simulation {
            self.worker.submit(Job::Stop);
        }
        self.mode = mode;
        self.cable = None;
        self.cabling = false;
        self.preview.clear();
        self.drag = None;
        self.annotations.cancel_gesture();
    }
    fn replace(&mut self, action: Replacement) {
        if self.worker.pending_commands() {
            self.error = Some("state.pending_commands".into());
            return;
        }
        if self.editor.dirty() || self.desktop.dirty() {
            self.pending = Some(action);
        } else {
            self.replace_now(action);
        }
    }
    fn replace_now(&mut self, action: Replacement) {
        let language = self.language;
        if matches!(action, Replacement::Close) {
            self.close_confirmed = true;
            return;
        }
        let result = match action {
            Replacement::RecoverSession => {
                self.load_requested_session();
                Ok(None)
            }
            Replacement::Close => unreachable!(),
            Replacement::LoadScenario
            | Replacement::RestoreCheckpoint
            | Replacement::ReplayRecording => {
                if let Some(path) = rfd::FileDialog::new()
                    .add_filter("JSON", &["json"])
                    .pick_file()
                    && let Err(e) = self.begin_runtime_file(path, action)
                {
                    self.error = Some(e);
                }
                Ok(None)
            }
            Replacement::New => {
                let mut project = Editor::empty().project().clone();
                project.name = language.text("new_network").into();
                Editor::new(project)
                    .map_err(sns_project::Error::from)
                    .map(|editor| Some((editor, None)))
            }
            Replacement::WirelessExample => {
                sns_project::parse_project(include_bytes!("../../../fixtures/valid/wireless.json"))
                    .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                    .map(|e| Some((e, None)))
            }
            Replacement::MailExample | Replacement::P2pExample => {
                sns_project::parse_project(if matches!(action, Replacement::MailExample) {
                    include_bytes!("../../../fixtures/valid/mail.json").as_slice()
                } else {
                    include_bytes!("../../../fixtures/valid/p2p.json").as_slice()
                })
                .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                .map(|e| Some((e, None)))
            }
            Replacement::PrivateExample => {
                sns_project::parse_project(include_bytes!("../../../fixtures/valid/private.json"))
                    .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                    .map(|e| Some((e, None)))
            }
            Replacement::ClassroomExample | Replacement::ServicesExample => {
                sns_project::parse_project(if matches!(action, Replacement::ServicesExample) {
                    include_bytes!("../../../fixtures/valid/services.json").as_slice()
                } else {
                    include_bytes!("../../../fixtures/valid/classroom.json").as_slice()
                })
                .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                .map(|e| Some((e, None)))
            }
            Replacement::RoutedExample | Replacement::RipExample => {
                sns_project::parse_project(if matches!(action, Replacement::RipExample) {
                    include_bytes!("../../../fixtures/valid/rip.json").as_slice()
                } else {
                    include_bytes!("../../../fixtures/valid/routed.json").as_slice()
                })
                .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                .map(|e| Some((e, None)))
            }
            Replacement::HostsExample => {
                sns_project::parse_project(include_bytes!("../../../fixtures/valid/hosts.json"))
                    .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                    .map(|e| Some((e, None)))
            }
            Replacement::Example => {
                sns_project::parse_project(include_bytes!("../../../fixtures/valid/lan.json"))
                    .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                    .map(|e| Some((e, None)))
            }
            Replacement::ImportFilius => {
                if let Some(path) = rfd::FileDialog::new()
                    .add_filter("Filius", &["fls"])
                    .pick_file()
                    && let Err(e) = self.import_ui.file(path)
                {
                    self.error = Some(e.to_string());
                }
                Ok(None)
            }
            Replacement::Open => {
                if let Some(path) = rfd::FileDialog::new()
                    .add_filter(language.text("project_file"), &["json"])
                    .pick_file()
                {
                    sns_project::load_project(&path)
                        .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                        .map(|e| Some((e, Some(path))))
                } else {
                    Ok(None)
                }
            }
        };
        match result {
            Ok(Some((editor, path))) => {
                self.session_ui.can_save = true;
                self.set_mode(Mode::Design);
                self.editor = editor;
                self.duplicate_omitted = 0;
                self.desktop = Default::default();
                self.worker.restart(self.project().clone());
                self.synced_revision = 0;
                self.page = Page::Topology;
                self.event_index = None;
                self.filter.clear();
                self.path = path;
                self.selected.clear();
                self.draft = None;
                self.annotations = Default::default();
                self.fit = true;
                self.error = None;
            }
            Ok(None) => {}
            Err(e) => self.error = Some(e.to_string()),
        }
    }
    fn save(&mut self, save_as: bool) -> bool {
        if self.worker.pending_commands() {
            self.error = Some("state.pending_commands".into());
            return false;
        }
        let language = self.language;
        let path = if save_as || self.path.is_none() {
            rfd::FileDialog::new()
                .add_filter(language.text("project_file"), &["json"])
                .set_file_name(language.text("project_filename"))
                .save_file()
        } else {
            self.path.clone()
        };
        let Some(path) = path else {
            return false;
        };
        match self.save_project_to(path) {
            Ok(()) => true,
            Err(e) => {
                self.error = Some(e);
                false
            }
        }
    }
    pub fn save_project_to(&mut self, path: PathBuf) -> Result<(), String> {
        if self.worker.pending_commands() {
            return Err("state.pending_commands".into());
        }
        self.document_output_allowed(&path)?;
        match sns_project::save_project(&path, self.project()) {
            Ok(()) => {
                self.path = Some(path);
                self.editor.mark_saved();
                Ok(())
            }
            Err(e) => {
                self.error = Some(e.to_string());
                Err(e.to_string())
            }
        }
    }
    fn shortcuts(&mut self, ctx: &egui::Context) {
        if ctx.text_edit_focused() {
            return;
        }
        let keys = ctx.input(|i| {
            (
                i.modifiers.command,
                i.modifiers.shift,
                i.key_pressed(egui::Key::N),
                i.key_pressed(egui::Key::O),
                i.key_pressed(egui::Key::S),
                i.key_pressed(egui::Key::Z),
                i.key_pressed(egui::Key::Y),
                i.key_pressed(egui::Key::Delete),
                i.key_pressed(egui::Key::C),
                i.key_pressed(egui::Key::F1),
                i.key_pressed(egui::Key::F2),
                i.key_pressed(egui::Key::F3),
                i.key_pressed(egui::Key::F4),
                i.key_pressed(egui::Key::F5),
                i.key_pressed(egui::Key::Escape),
                i.key_pressed(egui::Key::D),
            )
        });
        let (command, shift, n, o, s, z, y, delete, c, help, f2, f3, f4, f5, escape, duplicate) =
            keys;
        if command {
            if n {
                self.replace(Replacement::New);
            }
            if o {
                self.replace(Replacement::Open);
            }
            if s {
                self.save(shift);
            }
            if self.mode != Mode::Simulation {
                if duplicate {
                    self.duplicate_selected();
                }
                if z && !shift {
                    self.editor.undo();
                    self.duplicate_omitted = 0;
                    self.refresh_draft();
                }
                if y || (z && shift) {
                    self.editor.redo();
                    self.duplicate_omitted = 0;
                    self.refresh_draft();
                }
            }
        } else {
            if delete && self.mode == Mode::Design {
                self.delete();
            }
            if c && self.mode == Mode::Design {
                self.cabling = !self.cabling;
                self.cable = None;
            }
            if f2 {
                self.set_mode(Mode::Design);
            }
            if f3 {
                self.set_mode(Mode::Simulation);
            }
            if f4 {
                self.set_mode(Mode::Documentation);
            }
            if f5 {
                self.speed = if self.speed == 100 {
                    1
                } else {
                    self.speed * 10
                };
                self.worker.submit(Job::Speed(self.speed));
            }
        }
        if help {
            self.help = !self.help;
        }
        if escape {
            self.cabling = false;
            self.cable = None;
            self.annotations.cancel_gesture();
        }
    }
    fn refresh_draft(&mut self) {
        self.annotations.cancel_gesture();
        self.annotations.draft = self
            .project()
            .annotations
            .iter()
            .find(|a| self.selected.contains(&a.id))
            .cloned();
        let project = self.editor.project();
        self.selected.retain(|id| {
            project.device(id).is_some()
                || project.links.iter().any(|l| &l.id == id)
                || project.annotations.iter().any(|a| &a.id == id)
        });
        self.draft = self.selected.iter().find_map(|id| {
            self.project().device(id).map(|d| {
                (
                    d.clone(),
                    self.project().lan.get(id).cloned().unwrap_or_default(),
                )
            })
        });
    }
    fn delete(&mut self) {
        self.annotations.cancel_gesture();
        self.annotations.draft = None;
        self.apply(Edit::Delete(self.selected.clone()));
        self.selected.clear();
        self.draft = None;
    }
    pub fn show(&mut self, ui: &mut egui::Ui) {
        annotations::install_fonts(ui.ctx());
        self.poll_png_export(ui.ctx());
        self.poll_session(ui.ctx());
        if ui.input(|i| i.viewport().close_requested())
            && (self.session_enabled() || self.png_export_busy())
            && !self.close_confirmed
        {
            ui.ctx()
                .send_viewport_cmd(egui::ViewportCommand::CancelClose);
            self.session_ui.close_requested = true;
        }
        if self.session_ui.loading {
            ui.spinner();
            ui.label(self.language.text("session_saving"));
            return;
        }
        self.poll_runtime(ui.ctx());
        if self.runtime_busy() {
            ui.spinner();
            ui.label(self.language.text("runtime_working"));
            return;
        }
        self.runtime_window(ui.ctx());
        self.poll_import(ui.ctx());
        let language = self.language;
        if self.import_ui.receiver.is_some() {
            ui.spinner();
            ui.label(language.text("import_working"));
            return;
        }
        self.import_window(ui.ctx());
        self.png_export_window(ui.ctx());
        self.worker.attach_context(ui.ctx());
        self.worker.poll();
        self.sync_applications();
        if self.close_confirmed {
            if self.session_close_ready(ui.ctx()) {
                ui.ctx().send_viewport_cmd(egui::ViewportCommand::Close);
            } else {
                ui.spinner();
                ui.label(self.language.text("session_saving"));
            }
            return;
        }
        self.link_conditions_window(ui.ctx());
        self.update_activity(ui.ctx());
        if (ui.input(|i| i.viewport().close_requested()) || self.session_ui.close_requested)
            && !self.close_confirmed
        {
            self.session_ui.close_requested = false;
            if self.editor.dirty() || self.desktop.dirty() || self.worker.pending_commands() {
                ui.ctx()
                    .send_viewport_cmd(egui::ViewportCommand::CancelClose);
                self.pending = Some(Replacement::Close);
            } else if self.session_enabled() || self.png_export_busy() {
                self.close_confirmed = true;
            }
        }
        if self.pending.is_none() {
            self.shortcuts(ui.ctx());
        }
        egui::Frame::central_panel(ui.style()).show(ui, |ui| {
            ui.set_min_size(ui.available_size());
            ui.horizontal_wrapped(|ui| {
                ui.heading("Sinesi");
                ui.label(language.text("workbench"));
                egui::ComboBox::new("ui-language", language.text("language"))
                    .selected_text(self.language.label())
                    .show_ui(ui, |ui| {
                        for value in Language::ALL {
                            if ui
                                .selectable_label(self.language == value, value.label())
                                .clicked()
                            {
                                self.choose_language(value);
                            }
                        }
                    });
                if ui.button(language.text("new")).clicked() {
                    self.replace(Replacement::New);
                }
                if ui.button(language.text("import_filius")).clicked() {
                    self.replace(Replacement::ImportFilius);
                }
                if self.import_ui.report.is_some()
                    && ui.button(language.text("import_report")).clicked()
                {
                    self.import_ui.open = true;
                }
                if ui.button(language.text("open")).clicked() {
                    self.replace(Replacement::Open);
                }
                if ui.button(language.text("save")).clicked() {
                    self.save(false);
                }
                if ui.button(language.text("save_as")).clicked() {
                    self.save(true);
                }
                self.session_toolbar(ui);
                if ui.button(language.text("example")).clicked() {
                    self.replace(Replacement::Example);
                }
                if ui.button(language.text("software_example")).clicked() {
                    self.replace(Replacement::HostsExample);
                }
                egui::ComboBox::from_id_salt("routing-examples")
                    .selected_text(language.text("routing_examples"))
                    .show_ui(ui, |ui| {
                        if ui.button(language.text("wireless_example")).clicked() {
                            self.replace(Replacement::WirelessExample);
                            ui.close();
                        }
                        if ui.button(language.text("mail_example")).clicked() {
                            self.replace(Replacement::MailExample);
                            ui.close();
                        }
                        if ui.button(language.text("p2p_example")).clicked() {
                            self.replace(Replacement::P2pExample);
                            ui.close();
                        }
                        if ui.button(language.text("private_example")).clicked() {
                            self.replace(Replacement::PrivateExample);
                            ui.close();
                        }
                        if ui.button(language.text("services_example")).clicked() {
                            self.replace(Replacement::ServicesExample);
                            ui.close();
                        }
                        if ui.button(language.text("classroom_example")).clicked() {
                            self.replace(Replacement::ClassroomExample);
                            ui.close();
                        }
                        if ui.button(language.text("static_example")).clicked() {
                            self.replace(Replacement::RoutedExample);
                            ui.close();
                        }
                        if ui.button(language.text("rip_example")).clicked() {
                            self.replace(Replacement::RipExample);
                            ui.close();
                        }
                    })
                    .response
                    .widget_info(|| {
                        egui::WidgetInfo::labeled(
                            egui::Role::ComboBox,
                            true,
                            language.text("routing_examples"),
                        )
                    });
                if ui.button(language.text("runtime_menu")).clicked() {
                    self.runtime_ui.open = true;
                }
                if ui.button(language.text("export_network")).clicked() {
                    self.export_ui.open = true;
                }
                if ui
                    .button(format!("{} · F1", language.text("help")))
                    .clicked()
                {
                    self.help = !self.help;
                }
            });
            ui.horizontal_wrapped(|ui| {
                for (mode, label) in [
                    (Mode::Design, format!("{} · F2", language.text("design"))),
                    (
                        Mode::Simulation,
                        format!("{} · F3", language.text("simulation")),
                    ),
                    (
                        Mode::Documentation,
                        format!("{} · F4", language.text("documentation")),
                    ),
                ] {
                    if ui.selectable_label(self.mode == mode, label).clicked() {
                        self.set_mode(mode);
                    }
                }
                ui.separator();
                let dirty = if self.editor.dirty() {
                    format!(" • {}", language.text("modified"))
                } else {
                    String::new()
                };
                ui.label(format!(
                    "{}{} · {}",
                    self.project().name,
                    dirty,
                    language
                        .format(
                            "revision",
                            &[("revision", &self.editor.revision().to_string())]
                        )
                        .unwrap()
                ));
            });
            if self.mode == Mode::Simulation {
                ui.horizontal_wrapped(|ui| {
                    if ui
                        .button(if self.worker.view.running {
                            language.text("pause")
                        } else {
                            language.text("resume")
                        })
                        .clicked()
                    {
                        self.worker.submit(Job::Running(!self.worker.view.running));
                    }
                    if ui
                        .add_enabled(
                            !self.worker.view.running,
                            egui::Button::new(language.text("step")),
                        )
                        .clicked()
                    {
                        self.worker.submit(Job::Step);
                    }
                    if ui.button(language.text("stop")).clicked() {
                        self.set_mode(Mode::Design);
                    }
                    ui.label(language.text("speed"));
                    if ui
                        .add(
                            egui::Slider::new(&mut self.speed, 1..=100)
                                .suffix("×")
                                .text(language.text("speed")),
                        )
                        .changed()
                    {
                        self.worker.submit(Job::Speed(self.speed));
                    }
                    let loss = ui.button(language.text("drop_hold"));
                    if loss.clicked() {
                        self.runtime_ui.preserve_manual_loss = false;
                    }
                    let held = self.runtime_ui.preserve_manual_loss
                        || loss.is_pointer_button_down_on()
                        || (loss.has_focus() && ui.input(|i| i.key_down(egui::Key::Space)));
                    if held != self.manual_loss {
                        self.manual_loss = held;
                        self.worker
                            .submit(Job::Command(Command::ManualLoss { enabled: held }));
                    }
                    ui.label(if self.manual_loss {
                        language.text("loss_on")
                    } else if self
                        .worker
                        .view
                        .link_conditions
                        .values()
                        .any(|c| c.loss_ppm > 0)
                    {
                        language.text("link_conditions_active")
                    } else {
                        language.text("loss_off")
                    });
                });
                ui.label(format!(
                    "{} · {}",
                    self.worker.view.run_id.as_str(),
                    language
                        .format(
                            "runtime",
                            &[
                                ("time", &self.worker.view.now.to_string()),
                                ("pending", &self.worker.view.pending.to_string()),
                                ("facts", &self.trace().len().to_string()),
                                (
                                    "state",
                                    language.text(if self.worker.view.running {
                                        "running"
                                    } else {
                                        "paused"
                                    })
                                )
                            ]
                        )
                        .unwrap()
                ));
            } else {
                ui.horizontal(|ui| {
                    if ui
                        .add_enabled(
                            self.editor.can_undo(),
                            egui::Button::new(language.text("undo")),
                        )
                        .clicked()
                    {
                        self.editor.undo();
                        self.refresh_draft();
                    }
                    if ui
                        .add_enabled(
                            self.editor.can_redo(),
                            egui::Button::new(language.text("redo")),
                        )
                        .clicked()
                    {
                        self.editor.redo();
                        self.refresh_draft();
                    }
                    ui.label(language.text("persistent_hint"));
                });
            }
            ui.horizontal(|ui| {
                for (page, label) in [
                    (Page::Topology, language.text("topology")),
                    (Page::Trace, language.text("exchanges")),
                    (Page::Tables, language.text("tables")),
                    (Page::Desktop, language.text("desktop")),
                ] {
                    ui.selectable_value(&mut self.page, page, label);
                }
            });
            if let Some(error) = self.error.as_ref().or(self.worker.view.error.as_ref()) {
                ui.horizontal_wrapped(|ui| {
                    ui.colored_label(
                        Color32::LIGHT_RED,
                        language
                            .format("error", &[("message", &language.describe_error(error))])
                            .unwrap(),
                    );
                });
            }
            if let Some(error) = &self.settings_error {
                ui.label(
                    language
                        .format("settings_error", &[("error", error)])
                        .unwrap(),
                );
            }
            ui.separator();
            self.desktop.top = ui.cursor().top();
            if self.page == Page::Trace {
                self.trace_ui(ui);
            } else if self.page == Page::Desktop {
                self.desktop_ui(ui);
            } else if self.page == Page::Tables {
                egui::ScrollArea::both().show(ui, |ui| {
                    ui.monospace(&self.worker.view.tables);
                });
            } else {
                let size = ui.available_size();
                let center = (size.x - 505.).max(200.);
                ui.horizontal_top(|ui| {
                    ui.allocate_ui_with_layout(
                        Vec2::new(185., size.y),
                        egui::Layout::top_down(egui::Align::Min),
                        |ui| {
                            egui::ScrollArea::vertical()
                                .id_salt("palette-scroll")
                                .show(ui, |ui| {
                                    self.palette(ui);
                                });
                        },
                    );
                    ui.separator();
                    ui.allocate_ui_with_layout(
                        Vec2::new(center, size.y),
                        egui::Layout::top_down(egui::Align::Min),
                        |ui| {
                            self.canvas(ui);
                        },
                    );
                    ui.separator();
                    ui.allocate_ui_with_layout(
                        Vec2::new(280., size.y),
                        egui::Layout::top_down(egui::Align::Min),
                        |ui| {
                            egui::ScrollArea::vertical()
                                .id_salt("inspector-scroll")
                                .show(ui, |ui| {
                                    self.inspector(ui);
                                });
                        },
                    );
                });
            }
        });
        self.application_windows(ui.ctx());
        self.journey_window(ui.ctx());
        self.session_window(ui.ctx());
        if self.help {
            egui::Window::new(language.text("help_title"))
                .id(ui.scope_id().with("workbench-help"))
                .open(&mut self.help)
                .show(ui.ctx(), |ui| {
                    ui.set_max_width(680.);
                    for key in [
                        "help_drag",
                        "help_navigation",
                        "help_keyboard",
                        "help_shortcuts",
                        "help_scope",
                    ] {
                        ui.label(language.text(key));
                    }
                });
        }
        if self.close_confirmed && self.session_close_ready(ui.ctx()) {
            ui.ctx().send_viewport_cmd(egui::ViewportCommand::Close);
        }
        if let Some(action) = self.pending {
            egui::Modal::new(ui.scope_id().with("unsaved-project")).show(ui.ctx(), |ui| {
                ui.heading(language.text("unsaved_title"));
                ui.label(language.text("unsaved_prompt"));
                if ui
                    .add_enabled(
                        !self.desktop.dirty(),
                        egui::Button::new(language.text("save_continue")),
                    )
                    .clicked()
                    && self.save(false)
                {
                    self.pending = None;
                    self.replace_now(action);
                }
                if ui.button(language.text("discard")).clicked() {
                    if matches!(action, Replacement::Close) {
                        self.session_ui.discard_on_close = true;
                    }
                    self.pending = None;
                    self.replace_now(action);
                }
                if matches!(action, Replacement::Close)
                    && self.session_enabled()
                    && ui.button(language.text("session_keep_and_close")).clicked()
                {
                    self.pending = None;
                    self.session_ui.discard_on_close = false;
                    self.close_confirmed = true;
                }
                if ui.button(language.text("continue_editing")).clicked() {
                    self.pending = None;
                }
            });
        }
        if !self.close_confirmed {
            self.tick_session(ui.ctx());
        }
    }
    pub fn request_close(&mut self) {
        self.replace(Replacement::Close);
    }
    fn palette(&mut self, ui: &mut egui::Ui) {
        let language = self.language;
        ui.heading(language.text("devices"));
        ui.horizontal(|ui| {
            ui.selectable_value(&mut self.art.diagram, false, language.text("view_icons"));
            ui.selectable_value(&mut self.art.diagram, true, language.text("view_diagram"));
        });
        ui.add_enabled_ui(self.mode == Mode::Design, |ui| {
            for (kind, label) in [
                (DeviceKind::Workstation, language.text("add_workstation")),
                (DeviceKind::Notebook, language.text("add_notebook")),
                (DeviceKind::Switch, language.text("add_switch")),
                (DeviceKind::Router, language.text("add_router")),
                (DeviceKind::Gateway, language.text("add_gateway")),
                (DeviceKind::Modem, language.text("add_modem")),
            ] {
                let response = ui.add(egui::Button::new(label).sense(Sense::click_and_drag()));
                response.dnd_set_drag_payload(kind);
                if response.clicked() {
                    let n = self.project().devices.len();
                    self.apply(Edit::AddNamed {
                        name: format!("{} {}", kind_label(language, kind), n + 1),
                        kind,
                        x: 80. + (n % 4) as f32 * 140.,
                        y: 80. + (n / 4) as f32 * 100.,
                    });
                    if let Some(d) = self.project().devices.last() {
                        self.select(d.id.clone(), false);
                    }
                }
            }
            ui.checkbox(
                &mut self.cabling,
                format!("{} · C", language.text("cable_tool")),
            );
            if !self.cabling {
                self.cable = None;
            }
            if ui.button(language.text("delete_selection")).clicked() {
                self.delete();
            }
            self.topology_tools(ui);
        });
        ui.separator();
        ui.heading(language.text("selection"));
        let devices = self.project().devices.clone();
        for d in devices {
            if ui
                .selectable_label(
                    self.selected.contains(&d.id),
                    format!(
                        "{} · {}",
                        self.device_label(&d),
                        self.project()
                            .lan
                            .get(&d.id)
                            .and_then(|c| c.symbol)
                            .map(|s| language.text(s.key()))
                            .unwrap_or_else(|| kind_label(language, d.kind))
                    ),
                )
                .clicked()
            {
                self.select(d.id, ui.input(|i| i.modifiers.shift));
            }
        }
        ui.separator();
        self.ipv4_warning_panel(ui);
        if self.mode == Mode::Documentation {
            self.annotation_palette(ui);
        }
    }

    fn inspector(&mut self, ui: &mut egui::Ui) {
        let language = self.language;
        ui.heading(language.text("inspector"));
        if self.annotation_inspector(ui) {
            return;
        }
        if let Some(link) = self
            .selected
            .iter()
            .find(|id| self.project().links.iter().any(|l| &l.id == *id))
            .cloned()
            && ui.button(language.text("link_conditions_menu")).clicked()
        {
            self.open_link_conditions(Some(link));
        }
        let Some((mut device, mut config)) = self.draft.clone() else {
            ui.label(language.text("select_hint"));
            return;
        };
        ui.label(
            language
                .format("identity", &[("id", device.id.as_str())])
                .unwrap(),
        );
        self.cloud_checkbox(ui, &device, &mut config);
        ui.add_enabled_ui(
            self.mode == Mode::Design && !self.worker.pending_commands(),
            |ui| {
                let label = ui.label(language.text("device_name"));
                ui.text_edit_singleline(&mut device.label)
                    .labelled_by(label.id);
                egui::ComboBox::new("device-display-mode", language.text("display_mode"))
                    .selected_text(match config.display {
                        DisplayName::Name => language.text("name"),
                        DisplayName::Ipv4 => "IPv4",
                        DisplayName::Mac => "MAC",
                    })
                    .show_ui(ui, |ui| {
                        for (v, label) in [
                            (DisplayName::Name, language.text("name")),
                            (DisplayName::Ipv4, "IPv4"),
                            (DisplayName::Mac, "MAC"),
                        ] {
                            ui.selectable_value(&mut config.display, v, label);
                        }
                    });
                if self.mode == Mode::Design {
                    egui::ComboBox::new("device-symbol", language.text("device_symbol"))
                        .selected_text(
                            language.text(
                                config
                                    .symbol
                                    .unwrap_or(if device.network.ssid.is_some() {
                                        DeviceSymbol::AccessPoint
                                    } else {
                                        DeviceSymbol::automatic(device.kind)
                                    })
                                    .key(),
                            ),
                        )
                        .show_ui(ui, |ui| {
                            for symbol in DeviceSymbol::ALL
                                .into_iter()
                                .filter(|s| *s != DeviceSymbol::Cloud)
                            {
                                ui.selectable_value(
                                    &mut config.symbol,
                                    Some(symbol),
                                    language.text(symbol.key()),
                                );
                            }
                        });
                    ui.label(language.text("symbol_hint"));
                }
                if device.kind == DeviceKind::Modem {
                    let modem = device.network.modem.get_or_insert_with(Default::default);
                    ui.label(language.text("bridge_external_hint"));
                    let role_label = ui.label(language.text("bridge_role"));
                    egui::ComboBox::from_id_salt("modem-role")
                        .selected_text(language.text(if modem.role == ModemRole::Listen {
                            "bridge_listen_role"
                        } else {
                            "bridge_connect_role"
                        }))
                        .show_ui(ui, |ui| {
                            ui.selectable_value(
                                &mut modem.role,
                                ModemRole::Listen,
                                language.text("bridge_listen_role"),
                            );
                            ui.selectable_value(
                                &mut modem.role,
                                ModemRole::Connect,
                                language.text("bridge_connect_role"),
                            );
                        })
                        .response
                        .labelled_by(role_label.id);
                    let label = ui.label(language.text("bridge_endpoint"));
                    ui.text_edit_singleline(&mut modem.endpoint)
                        .labelled_by(label.id);
                }
                if device.kind == DeviceKind::Switch {
                    let label = ui.label(language.text("sat_retention"));
                    ui.add(
                        egui::DragValue::new(&mut config.sat_retention_us.0)
                            .range(1..=86_400_000_000_u64),
                    )
                    .labelled_by(label.id);
                }
                if device.kind == DeviceKind::Switch
                    && device
                        .interfaces
                        .iter()
                        .any(|i| i.medium == Medium::Wireless)
                {
                    let mut ssid = device.network.ssid.clone().unwrap_or_default();
                    let label = ui.label(language.text("wireless_ssid"));
                    if ui
                        .text_edit_singleline(&mut ssid)
                        .labelled_by(label.id)
                        .changed()
                    {
                        device.network.ssid = if ssid.is_empty() { None } else { Some(ssid) };
                    }
                }
                for nic in &mut device.interfaces {
                    ui.separator();
                    ui.label(
                        language
                            .format(
                                "interface",
                                &[(
                                    "id",
                                    &if let Some(g) = &device.network.gateway {
                                        format!(
                                            "{} · {}",
                                            if nic.id == g.lan { "LAN" } else { "WAN" },
                                            nic.id.as_str()
                                        )
                                    } else {
                                        nic.id.as_str().to_string()
                                    },
                                )],
                            )
                            .unwrap(),
                    );
                    egui::ComboBox::new(
                        ("interface-medium", &nic.id),
                        language.text("connection_medium"),
                    )
                    .selected_text(language.text(if nic.medium == Medium::Ethernet {
                        "ethernet_medium"
                    } else {
                        "wireless_medium"
                    }))
                    .show_ui(ui, |ui| {
                        ui.selectable_value(
                            &mut nic.medium,
                            Medium::Ethernet,
                            language.text("ethernet_medium"),
                        );
                        ui.selectable_value(
                            &mut nic.medium,
                            Medium::Wireless,
                            language.text("wireless_medium"),
                        );
                    });
                    if nic.medium == Medium::Ethernet {
                        device.network.wireless.remove(&nic.id);
                    } else if !matches!(device.kind, DeviceKind::Switch | DeviceKind::Modem) {
                        let mut ssid = device
                            .network
                            .wireless
                            .get(&nic.id)
                            .cloned()
                            .unwrap_or_default();
                        let label = ui.label(language.text("wireless_ssid"));
                        if ui
                            .text_edit_singleline(&mut ssid)
                            .labelled_by(label.id)
                            .changed()
                        {
                            if ssid.is_empty() {
                                device.network.wireless.remove(&nic.id);
                            } else {
                                device.network.wireless.insert(nic.id.clone(), ssid);
                            }
                        }
                    }
                    let label = ui.label(language.text("mac_address"));
                    ui.text_edit_singleline(&mut nic.mac).labelled_by(label.id);
                    if !matches!(device.kind, DeviceKind::Switch | DeviceKind::Modem) {
                        let mut automatic = matches!(nic.ipv4, Some(Ipv4Config::Dhcp));
                        if ui
                            .checkbox(&mut automatic, language.text("dhcp_client"))
                            .changed()
                        {
                            nic.ipv4 = if automatic {
                                Some(Ipv4Config::Dhcp)
                            } else {
                                None
                            };
                        }
                        let (mut address, mut prefix) = match &nic.ipv4 {
                            Some(Ipv4Config::Static {
                                address,
                                prefix_length,
                            }) => (address.clone(), *prefix_length),
                            _ => (String::new(), 24),
                        };
                        let label = ui.label(language.text("ipv4_address"));
                        let changed = ui
                            .add_enabled(!automatic, egui::TextEdit::singleline(&mut address))
                            .labelled_by(label.id)
                            .changed();
                        let changed = ui
                            .add_enabled(
                                !automatic,
                                egui::DragValue::new(&mut prefix).range(0..=32).prefix("/ "),
                            )
                            .changed()
                            || changed;
                        if changed && !automatic {
                            nic.ipv4 = if address.is_empty() {
                                None
                            } else {
                                Some(Ipv4Config::Static {
                                    address: address.clone(),
                                    prefix_length: prefix,
                                })
                            };
                        }
                        if let Ok(address) = address.parse()
                            && let Ok((net, broadcast)) = sns_protocols::subnet(address, prefix)
                        {
                            ui.label(
                                language
                                    .format(
                                        "subnet",
                                        &[
                                            ("network", &net.to_string()),
                                            ("broadcast", &broadcast.to_string()),
                                        ],
                                    )
                                    .unwrap(),
                            );
                        }
                    }
                }
                if !device
                    .interfaces
                    .iter()
                    .any(|i| i.medium == Medium::Wireless)
                {
                    device.network.ssid = None;
                }
                for (label, value) in [
                    (
                        language.text("gateway"),
                        &mut device.network.default_gateway,
                    ),
                    (language.text("dns_server"), &mut device.network.dns_server),
                ]
                .into_iter()
                .filter(|_| device.kind != DeviceKind::Modem)
                {
                    let label = ui.label(label);
                    let mut text = value.clone().unwrap_or_default();
                    if ui
                        .text_edit_singleline(&mut text)
                        .labelled_by(label.id)
                        .changed()
                    {
                        *value = if text.is_empty() { None } else { Some(text) };
                    }
                }
                let dhcp_valid = ui
                    .push_id(("dhcp", device.id.clone()), |ui| {
                        desktop::dhcp_controls(ui, language, &mut device)
                    })
                    .inner;
                if ui
                    .add_enabled(dhcp_valid, egui::Button::new(language.text("apply")))
                    .clicked()
                {
                    self.apply(Edit::Configure(Box::new(device.clone()), config.clone()));
                }
                if ui.button(language.text("disconnect")).clicked() {
                    self.apply(Edit::Disconnect(device.id.clone()));
                }
            },
        );
        if device.kind == DeviceKind::Modem {
            ui.separator();
            ui.label(language.text("bridge_external_hint"));
            if let Some(view) = self.worker.view.bridges.get(&device.id) {
                ui.label(language.text(&view.state));
                ui.monospace(&view.endpoint);
                if let Some(code) = &view.detail
                    && code != &view.state
                {
                    ui.label(language.text(code));
                }
            }
            ui.add_enabled_ui(self.mode == Mode::Simulation, |ui| {
                if ui.button(language.text("bridge_activate")).clicked() {
                    self.worker.submit(Job::BridgeStart {
                        device: device.id.clone(),
                        config: device.network.modem.clone().unwrap_or_default(),
                    });
                }
                if ui.button(language.text("bridge_deactivate")).clicked() {
                    self.worker.submit(Job::BridgeStop {
                        device: device.id.clone(),
                    });
                }
            });
        }
        self.draft = Some((device.clone(), config));
        ui.separator();
        ui.heading(language.text("ports"));
        for nic in &device.interfaces {
            let busy = self
                .project()
                .links
                .iter()
                .any(|l| l.endpoints.contains(&nic.id));
            if ui
                .add_enabled(
                    !busy && self.mode == Mode::Design,
                    egui::Button::new(format!(
                        "{} · {}",
                        if let Some(g) = &device.network.gateway {
                            format!(
                                "{} · {}",
                                if nic.id == g.lan { "LAN" } else { "WAN" },
                                nic.id.as_str()
                            )
                        } else {
                            nic.id.as_str().to_string()
                        },
                        if busy {
                            language.text("port_busy")
                        } else {
                            language.text("port_free")
                        }
                    )),
                )
                .clicked()
            {
                self.port_click(nic.id.clone());
            }
        }
        if let Some(port) = &self.cable {
            ui.label(
                language
                    .format("cable_start", &[("port", port.as_str())])
                    .unwrap(),
            );
        }
        if device.kind == DeviceKind::Modem {
            return;
        }
        if self.mode == Mode::Simulation {
            if !matches!(device.kind, DeviceKind::Switch | DeviceKind::Modem) {
                if ui.button(language.text("open_desktop")).clicked() {
                    self.desktop.host = Some(device.id.clone());
                    self.page = Page::Desktop;
                }
                ui.heading(language.text("ping_title"));
                let label = ui.label(language.text("ping_target"));
                ui.text_edit_singleline(&mut self.target)
                    .labelled_by(label.id);
                ui.add(
                    egui::DragValue::new(&mut self.ttl)
                        .range(0..=255)
                        .prefix("TTL "),
                );
                if ui.button(language.text("send_ping")).clicked() {
                    self.worker.submit(Job::Command(Command::Ping {
                        source: device.id.clone(),
                        destination: self.target.clone(),
                        ttl: self.ttl,
                    }));
                }
                if ui.button(language.text("purge_arp")).clicked() {
                    self.worker.submit(Job::Command(Command::PurgeArp {
                        device: device.id.clone(),
                    }));
                }
            } else if ui.button(language.text("purge_sat")).clicked() {
                self.worker.submit(Job::Command(Command::PurgeSat {
                    device: device.id.clone(),
                }));
            }
            ui.label(language.text("paused_hint"));
        }
        self.routing_inspector(ui, &device);
        self.security_inspector(ui, &device);
    }
    fn port_click(&mut self, port: Id) {
        if let Some(start) = self.cable.take() {
            self.apply(Edit::Connect { a: start, b: port });
        } else {
            self.cable = Some(port);
            self.cabling = true;
        }
    }
    fn canvas(&mut self, ui: &mut egui::Ui) {
        let language = self.language;
        let journey_device = self.journey_event().map(|e| e.device_id.clone());
        ui.horizontal(|ui| {
            ui.add(egui::Slider::new(&mut self.zoom, 0.25..=3.).text(language.text("zoom")));
            if ui.button(language.text("fit")).clicked() {
                self.fit = true;
            }
        });
        ui.label(language.text("canvas_hint"));
        let (rect, response) = ui.allocate_exact_size(
            ui.available_size().max(Vec2::splat(10.)),
            Sense::click_and_drag(),
        );
        let positions = self.project().layout.devices.clone();
        if self.fit && !self.project().annotations.is_empty() {
            let mut bounds = Rect::NOTHING;
            for position in &positions {
                bounds = bounds.union(Rect::from_center_size(
                    Pos2::new(position.x, position.y),
                    Vec2::new(120., 82.),
                ));
            }
            for note in &self.project().annotations {
                let style = note.effective_style();
                bounds = bounds.union(Rect::from_min_size(
                    Pos2::new(note.x, note.y),
                    Vec2::new(style.width, style.height),
                ));
            }
            self.zoom = ((rect.width() - 40.) / bounds.width())
                .min((rect.height() - 40.) / bounds.height())
                .clamp(0.25, 2.);
            self.pan = rect.size() / 2. - bounds.center().to_vec2() * self.zoom;
            self.fit = false;
        }
        if self.fit && !positions.is_empty() {
            let min = positions
                .iter()
                .fold(Pos2::new(f32::MAX, f32::MAX), |a, p| {
                    Pos2::new(a.x.min(p.x), a.y.min(p.y))
                });
            let max = positions
                .iter()
                .fold(Pos2::new(f32::MIN, f32::MIN), |a, p| {
                    Pos2::new(a.x.max(p.x), a.y.max(p.y))
                });
            self.zoom = ((rect.width() - 130.) / (max.x - min.x + 100.))
                .min((rect.height() - 100.) / (max.y - min.y + 80.))
                .clamp(0.25, 2.);
            self.pan = rect.size() / 2.
                - Vec2::new((min.x + max.x) / 2., (min.y + max.y) / 2.) * self.zoom;
            self.fit = false;
        }
        let zoom = self.zoom;
        let pan_offset = self.pan;
        let world_to_screen = |x: f32, y: f32| rect.min + pan_offset + Vec2::new(x, y) * zoom;
        let mut rendered = positions.clone();
        for p in &mut rendered {
            if let Some(v) = self.preview.iter().find(|v| v.device_id == p.device_id) {
                *p = v.clone();
            }
        }
        let point = |id: &Id| {
            rendered
                .iter()
                .find(|p| &p.device_id == id)
                .map(|p| world_to_screen(p.x, p.y))
        };
        let painter = ui.painter_at(rect);
        painter.rect_filled(
            rect,
            8.,
            if self.art.diagram {
                Color32::from_rgb(246, 249, 251)
            } else {
                Color32::from_rgb(20, 28, 38)
            },
        );
        self.paint_annotations(ui, rect);
        let annotation_background = self
            .project()
            .annotations
            .iter()
            .any(|a| a.style.as_ref().is_some_and(|s| s.fill_color[3] > 0));
        let mut segments = Vec::new();
        for link in &self.project().links {
            let a = self
                .project()
                .device_for_interface(&link.endpoints[0])
                .and_then(|d| point(&d.id));
            let b = self
                .project()
                .device_for_interface(&link.endpoints[1])
                .and_then(|d| point(&d.id));
            if let (Some(a), Some(b)) = (a, b) {
                if annotation_background {
                    let width = if self.selected.contains(&link.id)
                        || self.active_links.contains_key(&link.id)
                    {
                        6.
                    } else {
                        4.
                    };
                    painter.line_segment([a, b], Stroke::new(width, Color32::from_rgb(15, 30, 40)));
                }
                painter.line_segment(
                    [a, b],
                    Stroke::new(
                        if self.selected.contains(&link.id)
                            || self.active_links.contains_key(&link.id)
                        {
                            4.
                        } else {
                            2.
                        },
                        if self.mode == Mode::Simulation
                            && self
                                .worker
                                .view
                                .link_conditions
                                .get(&link.id)
                                .is_some_and(|c| c.loss_ppm > 0)
                        {
                            if self.worker.view.link_conditions[&link.id].loss_ppm == 1_000_000 {
                                Color32::from_rgb(210, 65, 65)
                            } else {
                                Color32::from_rgb(210, 140, 30)
                            }
                        } else if self.active_links.contains_key(&link.id) {
                            if self.art.diagram {
                                Color32::from_rgb(210, 100, 0)
                            } else {
                                Color32::LIGHT_YELLOW
                            }
                        } else {
                            if self.art.diagram {
                                Color32::from_rgb(40, 99, 140)
                            } else {
                                Color32::from_rgb(98, 184, 183)
                            }
                        },
                    ),
                );
                if self.mode == Mode::Simulation
                    && let Some(conditions) = self.worker.view.link_conditions.get(&link.id)
                {
                    painter.text(
                        a.lerp(b, 0.5) - Vec2::new(0., 6.),
                        egui::Align2::CENTER_BOTTOM,
                        format!("{} %", conditions.loss_ppm as f64 / 10_000.),
                        egui::FontId::proportional(12. * self.zoom),
                        if self.art.diagram {
                            Color32::from_rgb(40, 60, 80)
                        } else {
                            Color32::WHITE
                        },
                    );
                }
                segments.push((link.id.clone(), a, b));
            }
        }
        for (client, ap) in self.project().wireless_links() {
            let a = self
                .project()
                .device_for_interface(&client)
                .and_then(|d| point(&d.id));
            let b = self
                .project()
                .device_for_interface(&ap)
                .and_then(|d| point(&d.id));
            if let (Some(a), Some(b)) = (a, b) {
                for i in 0..12 {
                    let t = i as f32 / 12.;
                    let u = (i as f32 + 0.55) / 12.;
                    if annotation_background {
                        painter.line_segment(
                            [a + (b - a) * t, a + (b - a) * u],
                            Stroke::new(4., Color32::from_rgb(15, 30, 40)),
                        );
                    }
                    painter.line_segment(
                        [a + (b - a) * t, a + (b - a) * u],
                        Stroke::new(2., Color32::from_rgb(32, 150, 215)),
                    );
                }
            }
        }
        if let Some(start) = self
            .cable
            .as_ref()
            .and_then(|port| self.project().device_for_interface(port))
            .and_then(|d| point(&d.id))
            && let Some(pos) = ui.ctx().pointer_hover_pos()
        {
            painter.line_segment([start, pos], Stroke::new(2., Color32::LIGHT_YELLOW));
        }
        let mut open_host = None;
        let mut selected = None;
        let mut drag_start = None;
        let mut dragging = false;
        let mut stopped = false;
        for d in self.project().devices.clone() {
            let Some(pos) = point(&d.id) else {
                continue;
            };
            let node = Rect::from_center_size(pos, Vec2::new(120., 82.) * self.zoom);
            let r = ui.interact(
                node,
                ui.scope_id().with(d.id.as_str()),
                Sense::click_and_drag(),
            );
            r.widget_info(|| {
                egui::WidgetInfo::selected(
                    egui::Role::Button,
                    true,
                    self.selected.contains(&d.id),
                    language
                        .format("canvas_device", &[("label", &d.label)])
                        .unwrap(),
                )
            });
            if r.double_clicked()
                && self.mode == Mode::Simulation
                && !matches!(d.kind, DeviceKind::Switch | DeviceKind::Modem)
            {
                open_host = Some(d.id.clone());
            }
            let active = self.selected.contains(&d.id);
            painter.rect_filled(
                node,
                6.,
                if self.art.diagram {
                    if active {
                        Color32::from_rgb(201, 235, 245)
                    } else {
                        Color32::TRANSPARENT
                    }
                } else if active {
                    Color32::from_rgb(40, 92, 106)
                } else {
                    Color32::from_rgb(40, 54, 71)
                },
            );
            painter.rect_stroke(
                node,
                6.,
                Stroke::new(
                    if r.has_focus() { 3. } else { 1. },
                    if active {
                        Color32::WHITE
                    } else {
                        if self.art.diagram {
                            Color32::TRANSPARENT
                        } else {
                            Color32::GRAY
                        }
                    },
                ),
                egui::StrokeKind::Inside,
            );
            if journey_device.as_ref() == Some(&d.id) {
                painter.rect_stroke(
                    node.expand(4.),
                    7.,
                    Stroke::new(3., Color32::from_rgb(245, 160, 45)),
                    egui::StrokeKind::Outside,
                );
            }
            let symbol = self
                .project()
                .lan
                .get(&d.id)
                .and_then(|c| c.symbol)
                .unwrap_or(if d.network.ssid.is_some() {
                    DeviceSymbol::AccessPoint
                } else {
                    DeviceSymbol::automatic(d.kind)
                });
            let texture = self.art.texture(ui.ctx(), symbol);
            let picture = Rect::from_center_size(
                pos + Vec2::new(0., -10. * self.zoom),
                Vec2::splat(52. * self.zoom),
            );
            painter.image(
                texture,
                picture,
                Rect::from_min_max(Pos2::ZERO, Pos2::new(1., 1.)),
                Color32::WHITE,
            );
            let ink = if self.art.diagram {
                Color32::BLACK
            } else {
                Color32::WHITE
            };
            let mut caption = egui::text::LayoutJob::simple(
                self.device_label(&d),
                egui::FontId::proportional(12. * self.zoom),
                ink,
                110. * self.zoom,
            );
            caption.wrap.max_rows = 1;
            let caption = painter.layout_job(caption);
            let size = caption.size();
            let inside = self.art.diagram
                && matches!(symbol, DeviceSymbol::Router | DeviceSymbol::Switch)
                && size.x <= 40. * self.zoom;
            let origin = Pos2::new(
                pos.x - size.x / 2.,
                pos.y
                    + if inside {
                        -10. * self.zoom
                    } else {
                        27. * self.zoom
                    }
                    - size.y / 2.,
            );
            if self.art.diagram && !inside {
                painter.rect_filled(
                    Rect::from_min_size(origin, size).expand(2. * self.zoom),
                    2.,
                    Color32::from_rgb(246, 249, 251),
                );
            }
            painter.galley(origin, caption, ink);
            if r.clicked() || (r.has_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter))) {
                selected = Some(d.id.clone());
            }
            if self.mode == Mode::Design {
                if r.drag_started() {
                    drag_start = Some((
                        d.id.clone(),
                        ui.input(|i| i.pointer.press_origin()).unwrap_or(pos),
                    ));
                }
                dragging |= r.dragged();
                stopped |= r.drag_stopped();
            }
        }
        if let Some(id) = open_host {
            self.desktop.host = Some(id);
            self.page = Page::Desktop;
        }
        if let Some(id) = selected {
            if self.cabling && self.mode == Mode::Design {
                let free = self
                    .project()
                    .device(&id)
                    .and_then(|d| {
                        d.interfaces.iter().find(|i| {
                            !self
                                .project()
                                .links
                                .iter()
                                .any(|l| l.endpoints.contains(&i.id))
                        })
                    })
                    .map(|i| i.id.clone());
                if let Some(port) = free {
                    self.port_click(port);
                } else {
                    self.error = Some(language.text("no_free_port").into());
                }
            } else {
                self.select(id, ui.input(|i| i.modifiers.shift));
            }
        }
        if let Some((id, origin)) = drag_start {
            if !self.selected.contains(&id) {
                self.select(id, false);
            }
            self.drag = Some(Drag {
                origin,
                positions: positions
                    .iter()
                    .filter(|p| self.selected.contains(&p.device_id))
                    .cloned()
                    .collect(),
            });
        }
        if dragging
            && let Some(drag) = &self.drag
            && let Some(pointer) = ui.ctx().pointer_interact_pos()
        {
            let delta = (pointer - drag.origin) / self.zoom;
            self.preview = drag
                .positions
                .iter()
                .map(|p| Position {
                    device_id: p.device_id.clone(),
                    x: p.x + delta.x,
                    y: p.y + delta.y,
                })
                .collect();
        }
        if stopped && self.drag.take().is_some() {
            let next = std::mem::take(&mut self.preview);
            self.apply(Edit::Move(next));
        }
        let pan =
            ui.input(|i| i.modifiers.alt || i.pointer.button_down(egui::PointerButton::Middle));
        if pan && (response.dragged() || response.dragged_by(egui::PointerButton::Middle)) {
            self.pan += ui.input(|i| i.pointer.delta());
        }
        if !pan && self.mode == Mode::Design {
            if response.drag_started() {
                self.rectangle = ui.input(|i| i.pointer.press_origin());
            }
            if let (Some(start), Some(end)) = (self.rectangle, ui.ctx().pointer_interact_pos()) {
                let area = Rect::from_two_pos(start, end);
                painter.rect_stroke(
                    area,
                    0.,
                    Stroke::new(1., Color32::LIGHT_BLUE),
                    egui::StrokeKind::Inside,
                );
                if response.drag_stopped() {
                    self.selected = positions
                        .iter()
                        .filter(|p| area.contains(world_to_screen(p.x, p.y)))
                        .map(|p| p.device_id.clone())
                        .collect();
                    self.rectangle = None;
                    self.refresh_draft();
                }
            }
        }
        if response.clicked()
            && let Some(pos) = response.interact_pointer_pos()
            && let Some((id, _, _)) = segments
                .iter()
                .find(|(_, a, b)| distance_segment(pos, *a, *b) < 8.)
        {
            self.selected = BTreeSet::from([id.clone()]);
            self.draft = None;
        }
        if self.mode == Mode::Design
            && let Some(kind) = response.dnd_release_payload::<DeviceKind>()
            && let Some(pos) = ui.ctx().pointer_interact_pos()
        {
            let world = (pos - rect.min - self.pan) / self.zoom;
            self.apply(Edit::AddNamed {
                name: format!(
                    "{} {}",
                    kind_label(language, *kind),
                    self.project().devices.len() + 1
                ),
                kind: *kind,
                x: world.x,
                y: world.y,
            });
        }
    }
    fn update_activity(&mut self, ctx: &egui::Context) {
        let now = ctx.input(|i| i.time);
        if self.mode != Mode::Simulation {
            self.active_links.clear();
            return;
        }
        if !self.worker.current() {
            return;
        }
        if self.trace().len() < self.observed_trace {
            self.observed_trace = 0;
            self.active_links.clear();
        }
        for event in &self.worker.view.trace[self.observed_trace..] {
            if event.kind == "ethernet.sent" || event.kind == "ethernet.received" {
                let port = crate::traffic::interface(event);
                for link in &self.worker.view.project.links {
                    if link.endpoints.iter().any(|p| p.as_str() == port) {
                        self.active_links.insert(link.id.clone(), now + 0.45);
                    }
                }
            }
        }
        self.observed_trace = self.trace().len();
        self.active_links.retain(|_, expires| *expires > now);
        if !self.active_links.is_empty() {
            ctx.request_repaint_after(std::time::Duration::from_millis(100));
        }
    }
    fn trace_ui(&mut self, ui: &mut egui::Ui) {
        let language = self.language;
        self.trace_search_ui(ui);
        ui.horizontal_wrapped(|ui| {
            let label = ui.label(language.text("filter"));
            ui.text_edit_singleline(&mut self.filter)
                .labelled_by(label.id);
            egui::ComboBox::new("trace-interface", language.text("interface_label"))
                .selected_text(
                    self.traffic
                        .interface
                        .as_ref()
                        .map(Id::as_str)
                        .unwrap_or(language.text("all_interfaces")),
                )
                .show_ui(ui, |ui| {
                    ui.selectable_value(
                        &mut self.traffic.interface,
                        None,
                        language.text("all_interfaces"),
                    );
                    for device in &self.worker.view.project.devices {
                        for port in &device.interfaces {
                            ui.selectable_value(
                                &mut self.traffic.interface,
                                Some(port.id.clone()),
                                format!("{} · {}", device.label, port.id.as_str()),
                            );
                        }
                    }
                });
            ui.checkbox(&mut self.traffic.follow, language.text("follow"));
            if ui.button(language.text("clear_trace")).clicked() {
                self.traffic.after = self.trace().last().map(|e| e.sequence.0).unwrap_or(0);
                self.event_index = None;
            }
            if ui.button(language.text("export_text")).clicked()
                && let Some(path) = rfd::FileDialog::new()
                    .set_file_name("traffic.txt")
                    .save_file()
            {
                let text = self
                    .traffic
                    .export_text(self.trace(), &self.filter, language);
                if let Err(e) = self.export_output_allowed(&path).and_then(|()| {
                    sns_project::atomic_write(&path, text.as_bytes()).map_err(|e| e.to_string())
                }) {
                    self.error = Some(e);
                }
            }
            if ui.button(language.text("export_jsonl")).clicked()
                && let Some(path) = rfd::FileDialog::new()
                    .set_file_name("trace-lan.jsonl")
                    .save_file()
            {
                self.export_filtered_trace(&path, sns_trace::ExportFormat::Jsonl);
            }
            if ui.button(language.text("export_csv")).clicked()
                && let Some(path) = rfd::FileDialog::new()
                    .set_file_name("trace-lan.csv")
                    .save_file()
            {
                self.export_filtered_trace(&path, sns_trace::ExportFormat::Csv);
            }
        });
        ui.horizontal_wrapped(|ui| {
            ui.selectable_value(&mut self.traffic.layered, false, language.text("aggregate"));
            ui.selectable_value(&mut self.traffic.layered, true, language.text("layers"));
            for (index, key) in [
                "link_layer",
                "network_layer",
                "transport_layer",
                "application_layer",
            ]
            .iter()
            .enumerate()
            {
                ui.checkbox(&mut self.traffic.layers[index], language.text(key));
            }
        });
        let events = self.worker.view.trace.clone();
        let rows: Vec<_> = events
            .iter()
            .enumerate()
            .filter(|(_, e)| self.traffic.matches(e, &self.filter))
            .collect();
        if self
            .event_index
            .is_some_and(|i| !rows.iter().any(|(index, _)| *index == i))
        {
            self.event_index = None;
        }
        let height = (ui.available_height() * 0.55).max(80.);
        if rows.is_empty() {
            ui.label(language.text("no_events"));
        }
        egui_extras::TableBuilder::new(ui)
            .id_salt("network-trace-table")
            .resizable(true)
            .animate_scrolling(false)
            .striped(true)
            .max_scroll_height(height)
            .stick_to_bottom(self.traffic.follow)
            .column(egui_extras::Column::auto().at_least(65.).clip(true))
            .column(egui_extras::Column::auto().at_least(160.).clip(true))
            .column(egui_extras::Column::remainder().at_least(200.).clip(true))
            .column(egui_extras::Column::auto().at_least(105.).clip(true))
            .column(egui_extras::Column::auto().at_least(120.).clip(true))
            .column(egui_extras::Column::auto().at_least(90.).clip(true))
            .column(egui_extras::Column::auto().at_least(85.).clip(true))
            .header(24., |mut row| {
                for key in [
                    "number",
                    "time_us",
                    "event",
                    "device",
                    "interface_label",
                    "direction",
                    "protocol",
                ] {
                    row.col(|ui| {
                        ui.strong(language.text(key));
                    });
                }
            })
            .body(|body| {
                body.rows(23., rows.len(), |mut row| {
                    let (index, f) = rows[row.index()];
                    for value in [
                        f.sequence.0.to_string(),
                        f.time_us.0.to_string(),
                        f.kind.clone(),
                        f.device_id.as_str().into(),
                        crate::traffic::interface(f).into(),
                        crate::traffic::direction(f, language).into(),
                        crate::traffic::protocol(f).into(),
                    ] {
                        row.col(|ui| {
                            if ui
                                .selectable_label(self.event_index == Some(index), value)
                                .clicked()
                            {
                                self.event_index = Some(index);
                            }
                        });
                    }
                });
            });
        ui.separator();
        ui.heading(language.text("traffic_detail"));
        if let Some(event) = self.event_index.and_then(|i| events.get(i)) {
            ui.horizontal_wrapped(|ui| {
                ui.label(format!(
                    "{} · {}",
                    event.run_id.as_str(),
                    event.event_id.as_str()
                ));
                if ui.button(language.text("message_journey")).clicked()
                    && let Err(e) = self.open_message_journey(&event.event_id)
                {
                    self.error = Some(e.to_string());
                }
            });
            if let Some(reason) = event.payload.get("reason").and_then(|v| v.as_str()) {
                ui.label(format!(
                    "{}: {} · {}",
                    language.text("why_packet"),
                    language.describe_error(reason),
                    event.device_id.as_str()
                ));
            }
            if let Some(route) = event.payload.get("route") {
                ui.label(format!("{}: {}", language.text("selected_route"), route));
            }
            egui::ScrollArea::both()
                .id_salt("trace-details")
                .show(ui, |ui| {
                    if self.traffic.layered {
                        let value = serde_json::to_value(event).unwrap();
                        let frame = value.pointer("/payload/frame");
                        let packet = frame.and_then(|v| v.get("payload"));
                        for (key, part) in [
                            ("link_layer", frame),
                            ("network_layer", packet),
                            (
                                "transport_layer",
                                packet.and_then(|v| v.get("packet").or_else(|| v.get("icmp"))),
                            ),
                            (
                                "application_layer",
                                event.payload.get("data_base64").or_else(|| {
                                    packet.and_then(|v| v.pointer("/packet/data_base64"))
                                }),
                            ),
                        ] {
                            ui.collapsing(language.text(key), |ui| {
                                ui.monospace(
                                    part.map(|v| serde_json::to_string_pretty(v).unwrap())
                                        .unwrap_or_else(|| "—".into()),
                                );
                            });
                        }
                    } else {
                        ui.monospace(serde_json::to_string_pretty(event).unwrap());
                    }
                });
        } else {
            ui.label(language.text("traffic_hint"));
        }
    }
}
fn kind_label(language: Language, kind: DeviceKind) -> &'static str {
    language.text(match kind {
        DeviceKind::Workstation => "workstation",
        DeviceKind::Notebook => "notebook",
        DeviceKind::Switch => "switch",
        DeviceKind::Router => "router",
        DeviceKind::Gateway => "gateway_device",
        DeviceKind::Modem => "modem",
    })
}
fn distance_segment(p: Pos2, a: Pos2, b: Pos2) -> f32 {
    let ab = b - a;
    let t = if ab.length_sq() == 0. {
        0.
    } else {
        ((p - a).dot(ab) / ab.length_sq()).clamp(0., 1.)
    };
    p.distance(a + ab * t)
}

#[cfg(test)]
mod measurements {
    use super::*;
    mod load {
        include!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../fixtures/lan_load.rs"
        ));
    }
    #[test]
    #[ignore = "reference capacity measurement; run explicitly with --nocapture"]
    fn reference_load_100_nodes_150_links_10000_events() {
        let project = load::project();
        let mut e = sns_engine::Engine::from_project(
            project.clone(),
            42,
            sns_engine::Limits {
                trace: 250_000,
                ..Default::default()
            },
        )
        .unwrap();
        for n in 0..40 {
            e.command(CommandEnvelope {
                api_version: 1,
                command_id: Id::new(format!("bench-{n}")).unwrap(),
                project_id: project.project_id.clone(),
                expected_revision: Decimal(0),
                run_id: e.run_id().clone(),
                command: Command::Ping {
                    source: Id::new(format!("node-{n}")).unwrap(),
                    destination: format!("192.168.1.{}", (n + 1) % 50 + 2),
                    ttl: 64,
                },
            })
            .unwrap();
        }
        let start = std::time::Instant::now();
        let (processed, termination) = e.pump(10_000, None).unwrap();
        let engine_ms = start.elapsed().as_secs_f64() * 1000.;
        assert_eq!(processed, 10_000);
        let trace = e.trace().to_vec();
        let trace_len = trace.len();
        let mut state = LanUi::new().unwrap();
        state.editor = Editor::new(project).unwrap();
        state.worker.view.trace = std::sync::Arc::new(trace);
        let mut h = egui_kittest::Harness::builder()
            .with_size((1320., 880.))
            .build_ui_state(|ui, state: &mut LanUi| state.show(ui), state);
        h.run();
        let mut topology = Vec::new();
        for _ in 0..100 {
            let now = std::time::Instant::now();
            h.step();
            topology.push(now.elapsed().as_secs_f64() * 1000.);
        }
        h.state_mut().page = Page::Trace;
        h.run();
        let mut table = Vec::new();
        for _ in 0..100 {
            let now = std::time::Instant::now();
            h.step();
            table.push(now.elapsed().as_secs_f64() * 1000.);
        }
        topology.sort_by(f64::total_cmp);
        table.sort_by(f64::total_cmp);
        println!(
            "{}",
            serde_json::json!({"devices":100,"links":150,"processed_events":processed,"trace_facts":trace_len,"termination":termination,"engine_ms":engine_ms,"ui_topology_p95_ms":topology[94],"ui_trace_p95_ms":table[94],"ui_method":"egui CPU layout + accessibility, 1320x880, 100 frames; excludes GPU/presentation"})
        );
    }
}
