use eframe::egui;
use std::{ffi::OsString, path::PathBuf};
#[derive(Default, Debug, PartialEq)]
struct Launch {
    prototype: bool,
    project: Option<PathBuf>,
}
fn launch(arguments: impl IntoIterator<Item = OsString>) -> Result<Launch, std::io::Error> {
    let mut launch = Launch::default();
    let mut positional = false;
    for argument in arguments {
        if !positional && argument == "--" {
            positional = true;
            continue;
        }
        if !positional && argument == "--prototype-j0" {
            launch.prototype = true;
            continue;
        }
        if !positional && argument.to_string_lossy().starts_with('-') {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                "Unknown desktop option",
            ));
        }
        if launch.project.replace(argument.into()).is_some() {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                "Only one project may be opened at launch",
            ));
        }
    }
    if launch.prototype && launch.project.is_some() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            "The J0 prototype does not open network project files",
        ));
    }
    Ok(launch)
}
enum Workbench {
    Lan(Box<sns_ui_egui::LanUi>),
    Prototype(Box<sns_ui_egui::SinesiUi>),
}
struct Desktop {
    ui: Workbench,
}
impl eframe::App for Desktop {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        match &mut self.ui {
            Workbench::Lan(app) => app.show(ui),
            Workbench::Prototype(app) => app.show(ui),
        }
    }
}
fn main() -> eframe::Result {
    let launch =
        launch(std::env::args_os().skip(1)).map_err(|e| eframe::Error::AppCreation(Box::new(e)))?;
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Sinesi — Simple network simulator")
            .with_inner_size([1320.0, 880.0])
            .with_min_inner_size([1050.0, 650.0]),
        ..Default::default()
    };
    eframe::run_native(
        "Sinesi",
        options,
        Box::new(move |context| {
            context.egui_ctx.set_visuals(egui::Visuals::dark());
            Ok(Box::new(Desktop {
                ui: if launch.prototype {
                    Workbench::Prototype(Box::new(
                        sns_ui_egui::SinesiUi::new().map_err(std::io::Error::other)?,
                    ))
                } else {
                    Workbench::Lan(Box::new(
                        sns_ui_egui::LanUi::native_with_project(launch.project)
                            .map_err(std::io::Error::other)?,
                    ))
                },
            }))
        }),
    )
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn explicit_file_argument_preserves_spaces_unicode_and_option_boundary() {
        let args = |v: &[&str]| v.iter().map(OsString::from).collect::<Vec<_>>();
        assert_eq!(
            launch(args(&["école réseau.json"])).unwrap().project,
            Some(PathBuf::from("école réseau.json"))
        );
        assert_eq!(
            launch(args(&["--", "-classe.json"])).unwrap().project,
            Some(PathBuf::from("-classe.json"))
        );
        assert!(launch(args(&["a.json", "b.json"])).is_err());
        assert!(launch(args(&["--prototype-j0", "a.json"])).is_err());
        assert!(launch(args(&["--unknown"])).is_err());
    }
}
