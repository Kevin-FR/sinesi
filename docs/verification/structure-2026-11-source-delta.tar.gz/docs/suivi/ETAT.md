# État de reprise — Sinesi

## Situation courante — 8 novembre 2026

**J1 à J6 sont qualifiés localement. J7 reste ouvert.** La tranche demandée de
structure et méthode est réalisée : comparaison SolidCraft/WordCraft, frontières
contrôlées, commandes de validation communes et découpage du workbench.
FR EN ES IT PT DE et les vues Icônes/Schéma sont conservés.

| Registre de référence | État |
| --- | --- |
| [178 exigences](features.json) | **154 verified**, 1 implemented, 2 in_progress, 21 not_started |
| [50 lots Rust](../rust/taches.json) | **42 verified**, 3 in_progress, 3 not_started, 2 deferred |
| J7 | **12 exigences vérifiées sur 22**, 1 implémentée partiellement, 9 non démarrées |
| Lots en cours | RS-QUALITY-J0, RS-PROJECTS-J7, RS-REPORTING-J7 |

Les registres et leurs preuves sont l’autorité. Les résumés historiques ne ferment
pas une exigence; [leur chronologie antérieure](ETAT-HISTORIQUE-2026-11-08.md) est conservée.

## Dernière tranche : structure et travail

Voir [D-011](../rust/decisions/D-011-structure-et-workflow.md), le
[guide de développement](../rust/DEVELOPPEMENT.md), la
[carte actuelle](../rust/ARCHITECTURE.md) et le
[rapport de qualification](../verification/STRUCTURE-2026-11.md).

Le workbench est réparti par responsabilité; le prototype J0 et son contrôleur
sont isolés. Les appelants utilisent `Workbench`, sans alias de l’ancien nom.
Les 19 membres héritent des dépendances et lints partagés. Une politique exhaustive
contrôle leurs arêtes internes de production et l’isolation sans GUI. Local et CI
utilisent le même point d’entrée. Aucun nouveau paquet tiers, fork ou service n’est
ajouté; aucun format de données n’est supprimé.

Qualification locale : **226 tests du workspace plus un enfant du pont**, cinq
ignorés par défaut; Clippy sans avertissement, formatage, contrôles des couches,
709 clés × six langues, 20 SVG et quatre fontes. Les **12 captures PNG courantes**
sont comparées sans mise à jour; les **321 images historiques** restent identiques.
Un test clavier enchaînait l’édition avant acquittement du nouveau worker : son
attente est explicite, avec échec initial conservé et **20 répétitions réussies**.
Manifeste final : **582 fichiers**, `sha256:d9bb85ef98e05e3afb0a6819357b470ee9efb48923ebb76f3aeec6e05c139cf5`. Les journaux et sources scellées sont dans le rapport.

## Périmètre J7 déjà qualifié

- [Import](../verification/J7-IMPORT-EN-COURS.md) : données ZIP/XML bornées, original préservé, rapport de pertes; **F-PROJ-005 reste implemented**, pas verified.
- [Scénarios/reprise/rejeu](../verification/J7-REPRISE-EN-COURS.md) et [pannes de liaison](../verification/J7-PANNES.md) : F-SIM-007/008.
- [Duplication/alignement](../verification/J7-TOPOLOGIE.md) et [nuage](../verification/J7-PRESENTATION.md) : F-TOP-009, F-EQU-008.
- [Observation](../verification/J7-OBSERVATION.md) et [diagnostic interne](../verification/J7-TERMINAL.md) : F-OBS-006/008, F-CLI-019.
- [Session/récupération](../verification/J7-SESSION.md) : F-PROJ-003/006.
- [Notes/zones](../verification/J7-ANNOTATIONS.md) et [PNG](../verification/J7-PNG.md) : F-DOC-001/002/003.

## Prochaine action et limites

Poursuivre RS-REPORTING-J7 avec **F-DOC-004 : rapport PDF**, en réutilisant la scène
et les glyphes explicites. Extraire les opérations de document restantes vers des
actions paramétrées à mesure des besoins, selon D-011, sans second chemin métier.

Restent aussi couverture sémantique de l’import, aide/préférences/fonts/icons/layout,
priorité de configuration, options de lancement, diagnostics, exemples, packaging
et parcours réels sur trois OS. F-NFR-001/006 et RS-QUALITY-J0 restent en cours.
La suite GPU historique complète et la lisibilité globale doivent être réconciliées
avec J7. La commande graphique ciblée couvre actuellement la tranche PNG.

Aucun sélecteur natif nouvellement manipulé, aucun parcours manuel autonome,
résultat Windows/Linux ou run distant n’est revendiqué. Les sockets hôte restent
réservées au pont explicitement activé. Les archives Filius et network-kit restent
en lecture seule; ni audit recalculé, ni commit, push ou publication effectués.
