"""Architecture regressions, including routes that escaped the old root allowlist."""
import unittest
import check_layers


def fixture():
    def node(name, edges):
        return dict(id=name, deps=[dict(pkg=target, dep_kinds=[dict(kind=kind, target=condition)])
                                  for target, kind, condition in edges])
    metadata = dict(packages=[dict(id=name, name=name) for name in ['model', 'settings', 'ui', 'egui']],
                    workspace_members=['model', 'settings', 'ui'],
                    resolve=dict(nodes=[node('model', []), node('settings', [('model', None, None)]),
                                        node('ui', [('egui', None, None)]), node('egui', [])]))
    policy = dict(packages=dict(model=dict(kind='headless', dependencies=[]),
                               settings=dict(kind='headless', dependencies=['model']),
                               ui=dict(kind='ui', dependencies=[])),
                  headless_forbidden=['egui'], headless_forbidden_prefixes=['craft-'])
    return metadata, policy


class Layers(unittest.TestCase):
    def test_current_shape_and_test_only_reverse_edge_are_allowed(self):
        metadata, policy = fixture()
        metadata['resolve']['nodes'][0]['deps'].append(dict(pkg='ui', dep_kinds=[dict(kind='dev', target=None)]))
        check_layers.validate(metadata, policy)

    def test_new_member_cannot_escape_checks(self):
        metadata, policy = fixture()
        metadata['packages'].append(dict(id='new', name='new'))
        metadata['workspace_members'].append('new')
        with self.assertRaisesRegex(ValueError, 'unknown=.*new'):
            check_layers.validate(metadata, policy)

    def test_undeclared_reverse_dependency_is_rejected(self):
        metadata, policy = fixture()
        metadata['resolve']['nodes'][0]['deps'].append(dict(pkg='settings', dep_kinds=[dict(kind=None, target=None)]))
        with self.assertRaisesRegex(ValueError, 'internal dependencies differ'):
            check_layers.validate(metadata, policy)

    def test_transitive_gui_in_build_target_or_mixed_dev_edge_is_rejected(self):
        for kinds in [[dict(kind='build', target='cfg(windows)')],
                      [dict(kind=None, target='cfg(unix)')],
                      [dict(kind='dev', target=None), dict(kind=None, target=None)]]:
            with self.subTest(kinds=kinds):
                metadata, policy = fixture()
                metadata['resolve']['nodes'][0]['deps'].append(dict(pkg='egui', dep_kinds=kinds))
                with self.assertRaisesRegex(ValueError, 'model -> egui'):
                    check_layers.validate(metadata, policy)

    def test_explicit_headless_to_adapter_edge_is_still_rejected(self):
        metadata, policy = fixture()
        policy['packages']['model']['dependencies'] = ['ui']
        metadata['resolve']['nodes'][0]['deps'].append(dict(pkg='ui', dep_kinds=[dict(kind=None, target=None)]))
        with self.assertRaisesRegex(ValueError, 'model -> ui'):
            check_layers.validate(metadata, policy)


if __name__ == '__main__':
    unittest.main()
