#!/usr/bin/env python3
"""Validate every workspace member against the explicit Rust dependency policy."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]


def production_edges(node):
    # Includes normal, build and conditional edges; test-only edges are not product code.
    return [edge['pkg'] for edge in node['deps']
            if any(kind['kind'] != 'dev' for kind in edge['dep_kinds'])]


def validate(metadata, policy):
    packages = {p['id']: p for p in metadata['packages']}
    members = {ident: packages[ident] for ident in metadata['workspace_members']}
    nodes = {n['id']: n for n in metadata['resolve']['nodes']}
    rules = policy['packages']
    names = {p['name'] for p in members.values()}
    if names != set(rules):
        raise ValueError(f'Workspace policy mismatch: unknown={sorted(names-set(rules))}, '
                         f'absent={sorted(set(rules)-names)}')
    for ident, package in members.items():
        rule = rules[package['name']]
        direct = {packages[edge]['name'] for edge in production_edges(nodes[ident]) if edge in members}
        if direct != set(rule['dependencies']):
            raise ValueError(f"{package['name']}: internal dependencies differ: "
                             f"actual={sorted(direct)}, allowed={rule['dependencies']}")
        if rule['kind'] != 'headless':
            continue
        pending = [(ident, [package['name']])]
        visited = set()
        while pending:
            dependency_id, chain = pending.pop()
            if dependency_id in visited:
                continue
            visited.add(dependency_id)
            dependency = packages[dependency_id]
            name = dependency['name']
            forbidden_member = (dependency_id in members and rules[name]['kind'] != 'headless')
            if (forbidden_member or name in policy['headless_forbidden'] or
                    any(name.startswith(prefix) for prefix in policy['headless_forbidden_prefixes'])):
                raise ValueError('Forbidden headless dependency: ' + ' -> '.join(chain))
            pending.extend((edge, chain + [packages[edge]['name']])
                           for edge in production_edges(nodes[dependency_id]))


def validate_manifests(metadata):
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members']:
            continue
        path = Path(package['manifest_path'])
        manifest = tomllib.loads(path.read_text())
        if manifest.get('lints', {}).get('workspace') is not True:
            raise ValueError(f'{path}: workspace lints must be inherited')
        tables = [manifest, *manifest.get('target', {}).values()]
        for table in tables:
            for group in ['dependencies', 'dev-dependencies', 'build-dependencies']:
                for name, dependency in table.get(group, {}).items():
                    if not isinstance(dependency, dict) or dependency.get('workspace') is not True:
                        raise ValueError(f'{path}: {group}.{name} must inherit workspace dependencies')


def main():
    metadata = json.loads(subprocess.check_output(
        [os.environ.get('CARGO', 'cargo'), 'metadata', '--format-version', '1', '--locked', '--offline'], cwd=ROOT))
    policy = json.loads((ROOT / 'docs/rust/layers.json').read_text())
    validate(metadata, policy)
    validate_manifests(metadata)
    print(f"OK — {len(metadata['workspace_members'])} workspace packages: explicit production edges, "
          'headless isolation and inherited manifests checked (including target/build edges).')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as error:
        sys.exit(str(error))
