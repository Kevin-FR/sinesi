use serde_json::{Value, json};
use std::{
    path::Path,
    process::{Command, Output},
};
fn invoke(root: &Path, args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_sns-desktop"))
        .current_dir(root)
        .env_remove("SINESI_ADMIN_CONFIG")
        .env_remove("SINESI_SETTINGS_PATH")
        .env_remove("SINESI_SESSION_DIR")
        .args([
            "--config",
            "admin.json",
            "--settings",
            "profile.json",
            "--session-dir",
            "sessions",
        ])
        .args(args)
        .output()
        .unwrap()
}
fn write(path: &Path, value: Value) {
    std::fs::write(path, serde_json::to_vec(&value).unwrap()).unwrap();
}
fn contract() -> jsonschema::Validator {
    jsonschema::validator_for(
        &serde_json::from_slice::<Value>(include_bytes!(
            "../../../contracts/startup-report.schema.json"
        ))
        .unwrap(),
    )
    .unwrap()
}
#[test]
fn real_binary_resolves_layers_and_checks_the_explicit_project_without_writing_files() {
    let dir = tempfile::tempdir().unwrap();
    let root = dir.path();
    write(
        &root.join("admin.json"),
        json!({"configuration_version":1,"language":"en","display":{"scale_percent":125,"font":"noto_sans"}}),
    );
    write(
        &root.join("profile.json"),
        json!({"settings_version":1,"language":"de"}),
    );
    let input = include_bytes!("../../../fixtures/valid/services.json");
    std::fs::write(root.join("école réseau.json"), input).unwrap();
    let old_profile = std::fs::read(root.join("profile.json")).unwrap();
    let output = invoke(
        root,
        &[
            "--check-config",
            "--language",
            "pt",
            "--ui-scale",
            "180",
            "--view",
            "diagram",
            "école réseau.json",
        ],
    );
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(output.stderr.is_empty());
    let report: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert!(contract().is_valid(&report));
    let cfg = &report["configuration"];
    assert_eq!(cfg["effective"]["language"], "pt");
    assert_eq!(cfg["persistent"]["language"], "de");
    assert_eq!(cfg["effective"]["display"]["scale_percent"], 180);
    assert_eq!(cfg["persistent"]["display"]["scale_percent"], 125);
    assert_eq!(cfg["origins"]["display.font"], "administrator");
    assert_eq!(cfg["origins"]["display.representation"], "command_line");
    let source: Value = serde_json::from_slice(input).unwrap();
    assert_eq!(
        report["project"]["devices"],
        source["devices"].as_array().unwrap().len()
    );
    assert_eq!(
        report["project"]["schema_version"],
        source["schema_version"]
    );
    assert_eq!(
        report["project"]["links"],
        source["links"].as_array().unwrap().len()
    );
    assert_eq!(
        std::fs::read(root.join("école réseau.json")).unwrap(),
        input
    );
    assert_eq!(
        std::fs::read(root.join("profile.json")).unwrap(),
        old_profile
    );
    assert!(!root.join("sessions").exists());
}
#[test]
fn help_version_and_safe_fallback_work_in_all_six_languages_without_a_window() {
    let dir = tempfile::tempdir().unwrap();
    let root = dir.path();
    write(&root.join("admin.json"), json!({"configuration_version":1}));
    for language in ["fr", "en", "es", "it", "pt", "de"] {
        let output = invoke(root, &["--language", language, "--help"]);
        assert!(output.status.success());
        let help = String::from_utf8(output.stdout).unwrap();
        for option in [
            "--help",
            "--version",
            "--check-config",
            "--config",
            "--settings",
            "--workdir",
            "--language",
            "--ui-scale",
            "--view",
            "--layout",
        ] {
            assert!(help.contains(option));
        }
        let output = invoke(
            root,
            &[
                "--language",
                language,
                "--check-config",
                "--ui-scale",
                "NOT_A_NUMBER_SECRET",
            ],
        );
        assert!(output.status.success());
        let report: Value = serde_json::from_slice(&output.stdout).unwrap();
        assert!(contract().is_valid(&report));
        assert_eq!(
            report["configuration"]["effective"]["display"]["scale_percent"],
            100
        );
        assert_eq!(report["configuration"]["effective"]["language"], language);
        assert!(!String::from_utf8_lossy(&output.stderr).contains("NOT_A_NUMBER_SECRET"));
    }
    let version = invoke(root, &["--version"]);
    assert!(version.status.success());
    assert_eq!(
        String::from_utf8(version.stdout).unwrap().trim(),
        format!("Sinesi {}", env!("CARGO_PKG_VERSION"))
    );
    let unknown = invoke(root, &["--unknown-secret"]);
    assert!(!unknown.status.success());
    assert!(!String::from_utf8_lossy(&unknown.stderr).contains("unknown-secret"));
    assert!(!root.join("profile.json").exists());
    assert!(!root.join("sessions").exists());
}
#[test]
fn working_directory_and_invalid_project_are_explicit_and_preserve_the_source() {
    let dir = tempfile::tempdir().unwrap();
    let base = dir.path().join("répertoire de travail");
    std::fs::create_dir(&base).unwrap();
    write(&base.join("admin.json"), json!({"configuration_version":1}));
    let input = include_bytes!("../../../fixtures/valid/lan.json");
    std::fs::write(base.join("-classe.json"), input).unwrap();
    let good = invoke(
        dir.path(),
        &[
            "-w",
            base.to_str().unwrap(),
            "--check-config",
            "--",
            "-classe.json",
        ],
    );
    assert!(
        good.status.success(),
        "{}",
        String::from_utf8_lossy(&good.stderr)
    );
    assert!(!base.join("sessions").exists());
    let conflict = invoke(
        dir.path(),
        &[
            "-w",
            base.to_str().unwrap(),
            "--settings",
            "missing/../-classe.json",
            "--check-config",
            "--",
            "-classe.json",
        ],
    );
    assert!(conflict.status.success());
    let report: Value = serde_json::from_slice(&conflict.stdout).unwrap();
    assert!(contract().is_valid(&report));
    assert_eq!(report["configuration"]["user_writable"], false);
    assert!(
        String::from_utf8_lossy(&conflict.stderr).contains(
            sns_settings::Settings::default()
                .language
                .text("configuration.project_path_conflict")
        )
    );
    assert!(!base.join("missing").exists());

    std::fs::write(base.join("broken.json"), b"SECRET_DO_NOT_ECHO").unwrap();
    let bad = invoke(
        dir.path(),
        &[
            "-w",
            base.to_str().unwrap(),
            "--check-config",
            "broken.json",
        ],
    );
    assert!(!bad.status.success());
    assert!(!String::from_utf8_lossy(&bad.stderr).contains("SECRET_DO_NOT_ECHO"));
    assert_eq!(
        std::fs::read(base.join("broken.json")).unwrap(),
        b"SECRET_DO_NOT_ECHO"
    );
}
#[test]
#[cfg(target_os = "linux")]
fn native_non_utf8_project_and_profile_paths_are_not_lossily_converted() {
    use std::os::unix::ffi::OsStringExt;
    let dir = tempfile::tempdir().unwrap();
    let project = dir
        .path()
        .join(std::ffi::OsString::from_vec(b"classe-\xff.json".to_vec()));
    let profile = dir
        .path()
        .join(std::ffi::OsString::from_vec(b"profil-\xfe.json".to_vec()));
    std::fs::write(&project, include_bytes!("../../../fixtures/valid/lan.json")).unwrap();
    write(&profile, json!({"settings_version":1,"language":"it"}));
    let output = Command::new(env!("CARGO_BIN_EXE_sns-desktop"))
        .args([
            std::ffi::OsStr::new("--settings"),
            profile.as_os_str(),
            std::ffi::OsStr::new("--check-config"),
            project.as_os_str(),
        ])
        .env("SINESI_ADMIN_CONFIG", dir.path().join("missing-admin.json"))
        .output()
        .unwrap();
    assert!(output.status.success());
    let report: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert!(contract().is_valid(&report));
    assert_eq!(report["configuration"]["effective"]["language"], "it");
}

#[test]
#[cfg(target_os = "macos")]
fn non_utf8_path_metadata_does_not_prevent_a_startup_report_on_apfs() {
    use std::os::unix::ffi::OsStringExt;
    let dir = tempfile::tempdir().unwrap();
    let profile = dir
        .path()
        .join(std::ffi::OsString::from_vec(b"profil-\xfe.json".to_vec()));
    let project = dir.path().join("classe.json");
    std::fs::write(&project, include_bytes!("../../../fixtures/valid/lan.json")).unwrap();
    let output = Command::new(env!("CARGO_BIN_EXE_sns-desktop"))
        .args([
            std::ffi::OsStr::new("--settings"),
            profile.as_os_str(),
            std::ffi::OsStr::new("--check-config"),
            project.as_os_str(),
        ])
        .env("SINESI_ADMIN_CONFIG", dir.path().join("missing-admin.json"))
        .output()
        .unwrap();
    assert!(output.status.success());
    let report: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert!(contract().is_valid(&report));
    assert_eq!(report["project"]["devices"], 4);
    assert!(!profile.exists());
}
