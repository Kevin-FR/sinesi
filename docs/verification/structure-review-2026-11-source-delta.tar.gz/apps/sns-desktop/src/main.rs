mod launch;
use eframe::egui;
use sns_settings::{Settings, configuration::Sources};
use std::process::ExitCode;
enum Application {
    Workbench(Box<sns_ui_egui::Workbench>),
    Prototype(Box<sns_ui_egui::prototype::SinesiUi>),
}
struct Desktop {
    ui: Application,
}
impl eframe::App for Desktop {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        match &mut self.ui {
            Application::Workbench(app) => app.show(ui),
            Application::Prototype(app) => app.show(ui),
        }
    }
}
fn run() -> Result<(), String> {
    let launch = launch::parse(std::env::args_os().skip(1))
        .map_err(|code| Settings::default().language.text(code).to_owned())?;
    let cwd = std::env::current_dir().map_err(|_| {
        Settings::default()
            .language
            .text("launch.working_directory_failed")
            .to_owned()
    })?;
    let prepared = launch.prepare(
        &cwd,
        Sources::native(),
        sns_settings::default_session_directory(),
    );
    let language = prepared.configuration.effective.language;
    let initial_diagnostics = prepared.configuration.diagnostics.clone();
    for issue in &initial_diagnostics {
        eprintln!("{}", issue.localized(language));
    }
    if launch.help {
        println!("{}", launch.help_text(&prepared.configuration));
        return Ok(());
    }
    if launch.version {
        println!("Sinesi {}", sns_settings::help::PRODUCT_VERSION);
        return Ok(());
    }
    if launch.check_config {
        let app = sns_ui_egui::Workbench::with_configuration(
            prepared.configuration.clone(),
            None,
            prepared.project.clone(),
        )
        .map_err(|_| language.text("launch.project_invalid").to_owned())?;
        print_additional_diagnostics(&app, &initial_diagnostics);
        println!(
            "{}",
            serde_json::to_string_pretty(&launch::report(&prepared, &app))
                .map_err(|_| language.text("launch.report_failed").to_owned())?
        );
        return Ok(());
    }
    let display = prepared.configuration.effective.display.clone();
    let app = if launch.prototype {
        Application::Prototype(Box::new(
            sns_ui_egui::prototype::SinesiUi::new()
                .map_err(|_| language.text("launch.project_invalid").to_owned())?,
        ))
    } else {
        Application::Workbench(Box::new(
            sns_ui_egui::Workbench::with_configuration(
                prepared.configuration,
                prepared.session,
                prepared.project,
            )
            .map_err(|_| language.text("launch.project_invalid").to_owned())?,
        ))
    };
    if let Application::Workbench(app) = &app {
        print_additional_diagnostics(app, &initial_diagnostics);
    }
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Sinesi — Simple network simulator")
            .with_inner_size([display.window_width as f32, display.window_height as f32])
            .with_min_inner_size([840., 600.]),
        ..Default::default()
    };
    eframe::run_native(
        "Sinesi",
        options,
        Box::new(move |context| {
            context.egui_ctx.set_visuals(egui::Visuals::dark());
            Ok(Box::new(Desktop { ui: app }))
        }),
    )
    .map_err(|error| format!("{}: {error}", language.text("launch.window_failed")))
}
fn print_additional_diagnostics(
    app: &sns_ui_egui::Workbench,
    previous: &[sns_settings::configuration::ConfigurationDiagnostic],
) {
    if let Some(configuration) = app.startup_configuration() {
        for issue in configuration
            .diagnostics
            .iter()
            .filter(|issue| !previous.contains(issue))
        {
            eprintln!("{}", issue.localized(configuration.effective.language));
        }
    }
}
fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(message) => {
            eprintln!("{message}");
            ExitCode::FAILURE
        }
    }
}
