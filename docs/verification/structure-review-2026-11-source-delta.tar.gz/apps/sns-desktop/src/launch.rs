//! Native paths stay OsString/PathBuf; option values are validated by the shared resolver.
use serde_json::{Value, json};
use sns_settings::configuration::{
    ConfigurationDiagnostic, Overrides, ResolvedConfiguration, Source, Sources,
};
use std::{
    ffi::OsString,
    path::{Path, PathBuf},
};

#[derive(Default, Debug, PartialEq)]
pub(super) struct Launch {
    pub prototype: bool,
    pub help: bool,
    pub version: bool,
    pub check_config: bool,
    pub project: Option<PathBuf>,
    config: Option<PathBuf>,
    settings: Option<PathBuf>,
    session: Option<PathBuf>,
    working_directory: Option<PathBuf>,
    values: Vec<(&'static str, String)>,
}
pub(super) struct Prepared {
    pub configuration: ResolvedConfiguration,
    pub project: Option<PathBuf>,
    pub session: Option<PathBuf>,
}
struct OptionSpec {
    names: &'static [&'static str],
    metavar: &'static str,
    description: &'static str,
}
const OPTIONS: &[OptionSpec] = &[
    OptionSpec {
        names: &["-h", "--help"],
        metavar: "",
        description: "launch_help",
    },
    OptionSpec {
        names: &["--version"],
        metavar: "",
        description: "launch_version",
    },
    OptionSpec {
        names: &["--check-config"],
        metavar: "",
        description: "launch_check_config",
    },
    OptionSpec {
        names: &["--config"],
        metavar: "PATH",
        description: "launch_config",
    },
    OptionSpec {
        names: &["--settings"],
        metavar: "PATH",
        description: "launch_settings",
    },
    OptionSpec {
        names: &["--session-dir"],
        metavar: "PATH",
        description: "launch_session_dir",
    },
    OptionSpec {
        names: &["-w", "--workdir"],
        metavar: "PATH",
        description: "launch_workdir",
    },
    OptionSpec {
        names: &["--language"],
        metavar: "fr|en|es|it|pt|de",
        description: "launch_language",
    },
    OptionSpec {
        names: &["--ui-scale"],
        metavar: "80..200",
        description: "launch_ui_scale",
    },
    OptionSpec {
        names: &["--font"],
        metavar: "default|noto_sans",
        description: "launch_font",
    },
    OptionSpec {
        names: &["--view"],
        metavar: "icons|diagram",
        description: "launch_view",
    },
    OptionSpec {
        names: &["--layout"],
        metavar: "inspector_right|inspector_left|tabs",
        description: "launch_layout",
    },
    OptionSpec {
        names: &["--window-width"],
        metavar: "840..3840",
        description: "launch_window_width",
    },
    OptionSpec {
        names: &["--window-height"],
        metavar: "600..2160",
        description: "launch_window_height",
    },
    OptionSpec {
        names: &["--prototype-j0"],
        metavar: "",
        description: "launch_prototype",
    },
];
pub(super) fn parse(arguments: impl IntoIterator<Item = OsString>) -> Result<Launch, &'static str> {
    let mut result = Launch::default();
    let mut positional = false;
    let mut arguments = arguments.into_iter();
    let mut count = 0;
    while let Some(argument) = arguments.next() {
        count += 1;
        if count > 128 {
            return Err("launch.too_many_arguments");
        }
        if !positional && argument == "--" {
            positional = true;
            continue;
        }
        if !positional && argument.to_string_lossy().starts_with('-') {
            let Some(spec) = OPTIONS
                .iter()
                .find(|s| s.names.iter().any(|name| argument == *name))
            else {
                return Err("launch.unknown_option");
            };
            if spec.metavar.is_empty() {
                match spec.names.last().copied() {
                    Some("--help") => result.help = true,
                    Some("--version") => result.version = true,
                    Some("--check-config") => result.check_config = true,
                    Some("--prototype-j0") => result.prototype = true,
                    _ => return Err("launch.unknown_option"),
                }
                continue;
            }
            let value = arguments.next().ok_or("launch.missing_value")?;
            count += 1;
            if count > 128 {
                return Err("launch.too_many_arguments");
            }
            if value == "--"
                || OPTIONS
                    .iter()
                    .any(|s| s.names.iter().any(|name| value == *name))
            {
                return Err("launch.missing_value");
            }
            match spec.names.last().copied() {
                Some("--config") => result.config = Some(value.into()),
                Some("--settings") => result.settings = Some(value.into()),
                Some("--session-dir") => result.session = Some(value.into()),
                Some("--workdir") => result.working_directory = Some(value.into()),
                Some(key) => result
                    .values
                    .push((key, value.to_string_lossy().into_owned())),
                None => return Err("launch.unknown_option"),
            }
        } else if result.project.replace(argument.into()).is_some() {
            return Err("launch.multiple_projects");
        }
    }
    if result.prototype && (result.project.is_some() || result.check_config) {
        return Err("launch.prototype_conflict");
    }
    Ok(result)
}
impl Launch {
    pub fn prepare(
        &self,
        cwd: &Path,
        mut sources: Sources,
        default_session: Option<PathBuf>,
    ) -> Prepared {
        let mut issues = vec![];
        let base = match &self.working_directory {
            Some(path) => {
                let path = absolute(cwd, path);
                if path.is_dir() {
                    path
                } else {
                    issues.push(ConfigurationDiagnostic {
                        source: Source::CommandLine,
                        field: "working_directory".into(),
                        code: "configuration.invalid_directory",
                    });
                    cwd.to_owned()
                }
            }
            None => cwd.to_owned(),
        };
        if let Some(path) = &self.config {
            sources.administrator = Some(absolute(&base, path));
            sources.administrator_required = true;
        }
        if let Some(path) = &self.settings {
            sources.user = Some(absolute(&base, path));
        }
        let mut overrides = Overrides::default();
        for (key, value) in &self.values {
            let (name, numeric) = match *key {
                "--language" => {
                    overrides.language = Some(Value::String(value.clone()));
                    continue;
                }
                "--ui-scale" => ("scale_percent", true),
                "--font" => ("font", false),
                "--view" => ("representation", false),
                "--layout" => ("layout", false),
                "--window-width" => ("window_width", true),
                "--window-height" => ("window_height", true),
                _ => continue,
            };
            let value = if numeric {
                serde_json::from_str(value).unwrap_or_else(|_| Value::String(value.clone()))
            } else {
                Value::String(value.clone())
            };
            overrides.display.insert(name.into(), value);
        }
        sources.overrides = overrides;
        sources.administrator = sources.administrator.map(|p| absolute(&base, &p));
        sources.user = sources.user.map(|p| absolute(&base, &p));
        let mut configuration = sns_settings::configuration::resolve(sources);
        for issue in issues {
            configuration.record_diagnostic(issue.source, &issue.field, issue.code);
        }
        Prepared {
            configuration,
            project: self.project.as_ref().map(|p| absolute(&base, p)),
            session: self
                .session
                .as_ref()
                .map(|p| absolute(&base, p))
                .or(default_session.map(|p| absolute(&base, &p))),
        }
    }
    pub fn help_text(&self, configuration: &ResolvedConfiguration) -> String {
        let l = configuration.effective.language;
        let mut lines = vec![
            l.text("launch_usage").to_owned(),
            l.text("configuration_priority").to_owned(),
            String::new(),
        ];
        lines.extend(
            OPTIONS
                .iter()
                .filter(|s| !s.names.contains(&"--prototype-j0"))
                .map(|s| {
                    format!(
                        "  {} {}\n      {}",
                        s.names.join(", "),
                        s.metavar,
                        l.text(s.description)
                    )
                }),
        );
        lines.push(String::new());
        lines.push(l.text("launch_temporary_hint").into());
        lines.join("\n")
    }
}
fn absolute(base: &Path, path: &Path) -> PathBuf {
    if path.is_absolute() {
        path.to_owned()
    } else {
        base.join(path)
    }
}
pub(super) fn report(prepared: &Prepared, app: &sns_ui_egui::Workbench) -> Value {
    json!({"startup_report_version":1,"configuration":app.startup_configuration().unwrap_or(&prepared.configuration),"project":{
        "schema_version":app.project().schema_version,"devices":app.project().devices.len(),"links":app.project().links.len(),
    }})
}
#[cfg(test)]
mod tests {
    use super::*;
    fn args(v: &[&str]) -> Vec<OsString> {
        v.iter().map(OsString::from).collect()
    }
    #[test]
    fn native_paths_option_boundary_and_duplicate_values_are_explicit() {
        assert_eq!(
            parse(args(&["école réseau.json"])).unwrap().project,
            Some("école réseau.json".into())
        );
        assert_eq!(
            parse(args(&["--", "-classe.json"])).unwrap().project,
            Some("-classe.json".into())
        );
        for bad in [
            vec!["a.json", "b.json"],
            vec!["--prototype-j0", "a.json"],
            vec!["--unknown"],
            vec!["--settings"],
            vec!["--prototype-j0", "--check-config"],
        ] {
            assert!(parse(args(&bad)).is_err());
        }
        let dir = tempfile::tempdir().unwrap();
        let parsed = parse(args(&[
            "--language",
            "fr",
            "--language",
            "de",
            "-w",
            dir.path().to_str().unwrap(),
            "--settings",
            "profils/école.json",
            "--",
            "classe.json",
        ]))
        .unwrap();
        let ready = parsed.prepare(dir.path(), Sources::default(), None);
        assert_eq!(ready.configuration.effective.language.label(), "Deutsch");
        assert_eq!(
            ready.configuration.user_path,
            Some(dir.path().join("profils/école.json"))
        );
        assert_eq!(ready.project, Some(dir.path().join("classe.json")));
    }
}

#[cfg(all(test, unix))]
#[test]
fn parser_keeps_non_utf8_project_and_profile_path_bytes() {
    use std::os::unix::ffi::OsStringExt;
    let filename = OsString::from_vec(b"classe-\xff.json".to_vec());
    let profile = OsString::from_vec(b"profil-\xfe.json".to_vec());
    let parsed = parse([
        OsString::from("--settings"),
        profile.clone(),
        OsString::from("--"),
        filename.clone(),
    ])
    .unwrap();
    let ready = parsed.prepare(Path::new("/tmp"), Sources::default(), None);
    assert_eq!(ready.project, Some(PathBuf::from("/tmp").join(filename)));
    assert_eq!(
        ready.configuration.user_path,
        Some(PathBuf::from("/tmp").join(profile))
    );
}
