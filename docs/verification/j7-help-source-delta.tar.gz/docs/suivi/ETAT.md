# État de reprise — Sinesi

## Situation courante — 8 novembre 2026

**J1 à J6 sont qualifiés localement. J7 reste ouvert.** L’aide contextuelle est qualifiée après les rapports PDF; les commandes communes
et les frontières contrôlées restent le socle de travail.
FR EN ES IT PT DE et les vues Icônes/Schéma sont conservés.

| Registre de référence | État |
| --- | --- |
| [178 exigences](features.json) | **156 verified**, 1 implemented, 2 in_progress, 19 not_started |
| [50 lots Rust](../rust/taches.json) | **43 verified**, 3 in_progress, 2 not_started, 2 deferred |
| J7 | **14 exigences vérifiées sur 22**, 1 implémentée partiellement, 7 non démarrées |
| Lots en cours | RS-QUALITY-J0, RS-PROJECTS-J7, RS-PLATFORM-J7 |

Les registres et leurs preuves sont l’autorité. Les résumés historiques ne ferment
pas une exigence; [leur chronologie antérieure](ETAT-HISTORIQUE-2026-11-08.md) est conservée.

## Dernière tranche : aide contextuelle et informations

**F-CFG-002 est vérifié; RS-PLATFORM-J7 reste en cours.** Le
[profil portable](../agnostique/AIDE_J7.md),
[l’adaptateur](../rust/AIDE_J7.md) et le
[rapport de qualification](../verification/J7-AIDE.md) décrivent les guides par mode,
logiciels, dix exemples existants, versions consultables, crédits et notices.
F1 fonctionne avec une saisie active; Échap garde le brouillon intact. Le chargement
d’un exemple passe par la confirmation habituelle. Consulter l’aide ne commande pas
le réseau; une exécution déjà active peut continuer indépendamment.

Qualification : **237 tests du workspace plus un enfant**, cinq ignorés, Clippy
sans avertissement et contrôles réussis; **9 tests GPU et 66 captures courantes
comparées sans mise à jour**, dont **42 nouvelles**, et **345 anciennes images
inchangées**; **776 clés × six langues**. Le format ouvert 2 et le plus récent 9
sont montrés séparément, sans migration de fichier. Manifeste : **663 fichiers**,
`sha256:73ca4e8b9d3f973181bd9df48caa71958fa364c41ed0dae170d639332befd48e`.

Le [rapport PDF qualifié](../verification/J7-RAPPORT.md), le
[guide de développement](../rust/DEVELOPPEMENT.md) et la
[carte actuelle](../rust/ARCHITECTURE.md) restent les références de reprise.
Le workspace compte **20 membres**; aucune nouvelle dépendance tierce n’est ajoutée.

## Périmètre J7 déjà qualifié

- [Import](../verification/J7-IMPORT-EN-COURS.md) : données ZIP/XML bornées, original préservé, rapport de pertes; **F-PROJ-005 reste implemented**, pas verified.
- [Scénarios/reprise/rejeu](../verification/J7-REPRISE-EN-COURS.md) et [pannes de liaison](../verification/J7-PANNES.md) : F-SIM-007/008.
- [Duplication/alignement](../verification/J7-TOPOLOGIE.md) et [nuage](../verification/J7-PRESENTATION.md) : F-TOP-009, F-EQU-008.
- [Observation](../verification/J7-OBSERVATION.md) et [diagnostic interne](../verification/J7-TERMINAL.md) : F-OBS-006/008, F-CLI-019.
- [Session/récupération](../verification/J7-SESSION.md) : F-PROJ-003/006.
- [Notes/zones](../verification/J7-ANNOTATIONS.md) et [PNG](../verification/J7-PNG.md) et [PDF](../verification/J7-RAPPORT.md) : F-DOC-001/002/003/004.

## Prochaine action et limites

Poursuivre **RS-PLATFORM-J7** avec **F-CFG-003**, préférences d’affichage :
police agrandie lisible, choix de représentation et disposition persistants sans
changement du réseau. Le prérequis RS-PROJECTS-J1 est vérifié. Puis traiter les
priorités de configuration et les options de démarrage à partir des chemins réellement
appelés; les repères d’archive sont dans l’adaptateur d’aide. `-v` historique désigne
un verbose déclaré, pas la version; `-r` concerne le RTT, pas la vitesse d’affichage.

Restent aussi couverture sémantique de l’import, préférences/fonts/icons/layout,
priorité de configuration, options de lancement, diagnostics, exemples, packaging
et parcours réels sur trois OS. F-NFR-001/006 et RS-QUALITY-J0 restent en cours.
La suite GPU historique complète et la lisibilité globale doivent être réconciliées
avec J7. La commande graphique ciblée couvre actuellement PNG, PDF et aide.

Aucun sélecteur natif nouvellement manipulé, aucun parcours manuel autonome,
résultat Windows/Linux ou run distant n’est revendiqué. Les sockets hôte restent
réservées au pont explicitement activé. Les archives Filius et network-kit restent
en lecture seule; ni audit recalculé, ni commit, push ou publication effectués.
