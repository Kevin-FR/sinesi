use base64::{Engine as _, engine::general_purpose::STANDARD};
use sns_filius_import::import;
use std::{
    io::{Cursor, Write},
    path::Path,
};
fn archive(entries: &[(&str, &[u8])]) -> Vec<u8> {
    let mut w = zip::ZipWriter::new(Cursor::new(vec![]));
    for (name, bytes) in entries {
        w.start_file(
            *name,
            zip::write::SimpleFileOptions::default()
                .compression_method(zip::CompressionMethod::Stored),
        )
        .unwrap();
        w.write_all(bytes).unwrap();
    }
    w.finish().unwrap().into_inner()
}
#[test]
#[ignore = "requires the local read-only Filius corpus; run explicitly with --ignored"]
fn corpus_imports_as_data_preserving_every_byte_and_reports_all_losses() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../_archive/filius-master");
    let mut files = vec![];
    fn collect(p: &Path, out: &mut Vec<std::path::PathBuf>) {
        for e in std::fs::read_dir(p).unwrap() {
            let p = e.unwrap().path();
            if p.is_dir() {
                collect(&p, out);
            } else if p.extension().is_some_and(|e| e == "fls") {
                out.push(p);
            }
        }
    }
    collect(&root, &mut files);
    files.sort();
    assert_eq!(files.len(), 20);
    let mut summaries = vec![];
    for path in files {
        let bytes = std::fs::read(&path).unwrap();
        let result = import(&bytes, path.file_name().unwrap().to_str().unwrap())
            .unwrap_or_else(|e| panic!("{}: {e:?}", path.display()));
        result.project.validate().unwrap();
        validate_contracts(&result);
        let mut original_xml = zip::ZipArchive::new(Cursor::new(bytes.clone())).unwrap();
        let config = original_xml
            .file_names()
            .map(Result::unwrap)
            .find(|n| n.ends_with("/konfiguration.xml"))
            .unwrap()
            .to_string();
        let mut xml = String::new();
        std::io::Read::read_to_string(&mut original_xml.by_name(&config).unwrap(), &mut xml)
            .unwrap();
        let expected = roxmltree::Document::parse(&xml)
            .unwrap()
            .descendants()
            .filter(|n| n.attribute("class") == Some("filius.gui.netzwerksicht.GUIKnotenItem"))
            .count();
        assert_eq!(result.project.devices.len(), expected, "{}", path.display());
        if expected > 0 {
            assert!(!result.report.converted.is_empty());
        }
        assert!(!result.report.execution_performed);
        assert!(!result.report.functional_equivalence_verified);
        assert!(result.project.extensions.iter().all(|e| !e.enabled));
        let mut original = zip::ZipArchive::new(Cursor::new(bytes)).unwrap();
        for item in &result.report.preserved {
            let mut restored = vec![];
            for rid in &item.resources {
                let r = result
                    .project
                    .resources
                    .iter()
                    .find(|r| &r.id == rid)
                    .unwrap();
                restored.extend(STANDARD.decode(&r.data_base64).unwrap());
            }
            let mut entry = original.by_name(&item.name).unwrap();
            let mut data = vec![];
            std::io::Read::read_to_end(&mut entry, &mut data).unwrap();
            assert_eq!(restored, data, "{}:{}", path.display(), item.name);
        }
        let project = serde_json::to_vec(&result.project).unwrap();
        assert_eq!(
            sns_project::parse_project(&project).unwrap(),
            result.project
        );
        summaries.push(serde_json::json!({"path":path.strip_prefix(&root).unwrap().to_string_lossy(),"report":&result.report}));
    }
    if let Some(path) = std::env::var_os("SNS_RECORD_J7_IMPORT") {
        std::fs::write(path, serde_json::to_vec_pretty(&summaries).unwrap()).unwrap();
    }
}
#[test]
fn unsafe_archives_and_entity_xml_and_dangling_aliases_are_rejected() {
    for name in [
        "../outside",
        "/absolute",
        "C:/system",
        "projekt/../outside",
        "projekt//bad",
    ] {
        let bytes = archive(&[("projekt/konfiguration.xml", b"<java/>"), (name, b"x")]);
        assert!(import(&bytes, "unsafe.fls").is_err(), "{name}");
    }
    for xml in [
        "<!DOCTYPE java [<!ENTITY x SYSTEM 'file:///etc/passwd'>]><java>&x;</java>",
        "<java><object idref='missing'/></java>",
        "<java><object id='x'/><object id='x'/></java>",
    ] {
        assert!(
            import(
                &archive(&[("projekt/konfiguration.xml", xml.as_bytes())]),
                "unsafe.fls"
            )
            .is_err()
        );
    }
    assert!(import(b"not a zip", "invalid.fls").is_err());
    let bomb = archive(&[(
        "projekt/konfiguration.xml",
        &vec![b'x'; 8 * 1024 * 1024 + 1],
    )]);
    assert!(import(&bomb, "bomb.fls").is_err());
}
#[test]
fn arbitrary_embedded_code_is_preserved_and_disabled() {
    let xml=b"<java><object class='java.lang.ProcessBuilder'><string>must never execute</string></object></java>";
    let bytes = archive(&[
        ("projekt/konfiguration.xml", xml),
        ("projekt/anwendungen/Unsafe.class", b"class-data"),
        ("projekt/anwendungen/Unsafe.java", b"source-data"),
    ]);
    let r = import(&bytes, "unknown.fls").unwrap();
    assert_eq!(r.project.extensions.len(), 2);
    assert!(r.project.extensions.iter().all(|e| !e.enabled));
    assert!(
        r.report
            .unknown_classes
            .contains(&"java.lang.ProcessBuilder".into())
    );
}
#[test]
#[ignore = "requires the local read-only Filius LAN example; run explicitly with --ignored"]
fn imported_historical_lan_uses_production_arp_and_icmp() {
    use sns_model::*;
    let path = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../_archive/filius-master/beispiele/einfaches_rechnernetz_komplett.fls");
    let r = import(
        &std::fs::read(path).unwrap(),
        "einfaches_rechnernetz_komplett.fls",
    )
    .unwrap();
    let source = r
        .project
        .devices
        .iter()
        .find(|d| d.label == "Rechner 1")
        .unwrap()
        .id
        .clone();
    let mut e =
        sns_engine::Engine::from_project(r.project, 42, sns_engine::Limits::default()).unwrap();
    e.command(CommandEnvelope {
        api_version: 1,
        command_id: Id::new("imported-ping").unwrap(),
        project_id: e.project().project_id.clone(),
        run_id: e.run_id().clone(),
        expected_revision: Decimal(0),
        command: Command::Ping {
            source,
            destination: "192.168.0.12".into(),
            ttl: 64,
        },
    })
    .unwrap();
    e.run(10000, Some(3_000_000)).unwrap();
    assert!(e.trace().iter().any(|t| t.kind == "icmp.echo.reply"));
    assert!(e.trace().iter().any(|t| t.kind == "arp.request"));
    if let Some(dir) = std::env::var_os("SNS_RECORD_J7_IMPORT_DIR") {
        let dir = Path::new(&dir);
        std::fs::create_dir_all(dir).unwrap();
        std::fs::write(dir.join("j7-import-lan.jsonl"), e.canonical_trace()).unwrap();
    }
}
#[test]
fn duplicate_names_bad_crc_and_unsafe_virtual_tree_are_rejected() {
    let bytes = archive(&[
        ("projekt/konfiguration.xml", b"<java/>"),
        ("projekt/aaa", b"unchanged"),
        ("projekt/bbb", b"bad"),
    ]);
    let mut duplicate = bytes.clone();
    let pattern = b"projekt/bbb";
    for i in 0..duplicate.len() - pattern.len() {
        if &duplicate[i..i + pattern.len()] == pattern {
            duplicate[i..i + pattern.len()].copy_from_slice(b"projekt/aaa");
        }
    }
    assert!(import(&duplicate, "duplicate.fls").is_err());
    let mut corrupt = bytes;
    let i = corrupt.windows(9).position(|w| w == b"unchanged").unwrap();
    corrupt[i] ^= 1;
    assert!(import(&corrupt, "corrupt.fls").is_err());
    let xml=b"<java><object class='filius.gui.netzwerksicht.GUIKnotenItem'><void property='knoten'><object class='filius.hardware.knoten.Rechner'><void property='systemSoftware'><void property='dateisystem'><void property='arbeitsVerzeichnis'><void method='add'><object class='javax.swing.tree.DefaultMutableTreeNode'><void property='userObject'><string>..</string></void></object></void></void></void></void></object></void></object></java>";
    assert!(
        import(
            &archive(&[("projekt/konfiguration.xml", xml)]),
            "unsafe-tree.fls"
        )
        .is_err()
    );
}
#[test]
fn portable_synthetic_import_roundtrips_and_exchanges_real_simulated_frames() {
    use sns_model::*;
    let r = import(
        include_bytes!("../../../fixtures/legacy/lan.fls"),
        "lan.fls",
    )
    .unwrap();
    validate_contracts(&r);
    assert_eq!(r.report.counts.devices, 3);
    assert_eq!(r.report.counts.links, 2);
    assert!(
        r.report
            .unconverted_fields
            .iter()
            .any(|f| f.contains("unmappedTeachingNote"))
    );
    let mut e =
        sns_engine::Engine::from_project(r.project, 42, sns_engine::Limits::default()).unwrap();
    let id = |s: &str| Id::new(s).unwrap();
    e.command(CommandEnvelope {
        api_version: 1,
        command_id: id("import-ping"),
        project_id: e.project().project_id.clone(),
        run_id: e.run_id().clone(),
        expected_revision: Decimal(0),
        command: Command::Ping {
            source: id("legacy-device-0"),
            destination: "192.168.8.3".into(),
            ttl: 64,
        },
    })
    .unwrap();
    e.run(10000, Some(3_000_000)).unwrap();
    assert!(e.trace().iter().any(|t| t.kind == "icmp.echo.reply"));
}

fn validate_contracts(result: &sns_filius_import::ImportResult) {
    for (schema, value) in [
        (
            include_str!("../../../contracts/import-report.schema.json"),
            serde_json::to_value(&result.report).unwrap(),
        ),
        (
            if result.project.schema_version == 8 {
                include_str!("../../../contracts/project-presentation.schema.json")
            } else {
                include_str!("../../../contracts/project-advanced.schema.json")
            },
            serde_json::to_value(&result.project).unwrap(),
        ),
    ] {
        let schema: serde_json::Value = serde_json::from_str(schema).unwrap();
        jsonschema::options()
            .build(&schema)
            .unwrap()
            .validate(&value)
            .unwrap();
    }
}
#[test]
fn import_is_deterministic_and_mac_repairs_are_unique() {
    let bytes = include_bytes!("../../../fixtures/legacy/lan.fls");
    let a = import(bytes, "lan.fls").unwrap();
    let b = import(bytes, "lan.fls").unwrap();
    assert_eq!(a.project, b.project);
    assert_eq!(
        serde_json::to_vec(&a.report).unwrap(),
        serde_json::to_vec(&b.report).unwrap()
    );
    let xml = include_str!("../../../fixtures/legacy/lan.xml")
        .replace("02:08:00:00:00:01", "02:7f:00:00:00:02")
        .replace("02:08:00:00:00:02", "02:7f:00:00:00:02");
    let r = import(
        &archive(&[("projekt/konfiguration.xml", xml.as_bytes())]),
        "duplicate-mac.fls",
    )
    .unwrap();
    let mut macs = std::collections::BTreeSet::new();
    assert!(
        r.project
            .devices
            .iter()
            .flat_map(|d| &d.interfaces)
            .all(|i| macs.insert(&i.mac))
    );
    assert!(
        r.report
            .issues
            .iter()
            .any(|i| i.code == "import.generated_value")
    );
}

#[test]
fn cloud_flag_imports_as_presentation_data_without_changing_ports_or_wires() {
    let source = include_str!("../../../fixtures/legacy/lan.xml");
    let source=source.replace("class=\"filius.hardware.knoten.Switch\">","class=\"filius.hardware.knoten.Switch\"><void property=\"cloud\"><boolean>true</boolean></void>");
    let base = sns_filius_import::import(
        include_bytes!("../../../fixtures/legacy/lan.fls"),
        "base.fls",
    )
    .unwrap();
    let bytes = archive(&[("cloud/konfiguration.xml", source.as_bytes())]);
    let imported = sns_filius_import::import(&bytes, "cloud.fls").unwrap();
    assert_eq!(imported.project.schema_version, 8);
    let switch = imported
        .project
        .devices
        .iter()
        .find(|d| d.kind == sns_model::DeviceKind::Switch)
        .unwrap();
    assert_eq!(
        imported.project.lan[&switch.id].symbol,
        Some(sns_model::DeviceSymbol::Cloud)
    );
    let original = base
        .project
        .devices
        .iter()
        .find(|d| d.kind == sns_model::DeviceKind::Switch)
        .unwrap();
    assert_eq!(switch.interfaces.len(), original.interfaces.len());
    assert_eq!(imported.project.links.len(), base.project.links.len());
    assert!(
        imported
            .report
            .converted
            .iter()
            .any(|f| f.source.ends_with(":cloud"))
    );
    assert!(!imported.report.execution_performed);
    validate_contracts(&imported);
}
