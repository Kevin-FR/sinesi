//! Host preferences adapter. Language never changes the simulated project.
pub mod display;
pub mod help;
use serde::{Deserialize, Serialize};
use sns_i18n::Language;
use sns_model::Diagnostic;
use std::{
    io::Read,
    path::{Path, PathBuf},
};
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Settings {
    pub settings_version: u32,
    pub language: Language,
    pub display: display::DisplayPreferences,
}
impl Default for Settings {
    fn default() -> Self {
        Self {
            settings_version: 2,
            language: Language::Fr,
            display: Default::default(),
        }
    }
}
pub fn load(path: &Path) -> Result<Settings, String> {
    let file = match std::fs::File::open(path) {
        Ok(f) => f,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(Settings::default()),
        Err(e) => return Err(e.to_string()),
    };
    let mut bytes = Vec::new();
    file.take(65537)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.len() > 65536 {
        return Err(Diagnostic::new("resource.limit_exceeded", "settings").to_string());
    }
    let value: serde_json::Value = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
    let settings: Settings = match value.get("settings_version").and_then(|v| v.as_u64()) {
        Some(1) => {
            #[derive(Deserialize)]
            #[serde(deny_unknown_fields)]
            struct VersionOne {
                #[serde(rename = "settings_version")]
                _version: u32,
                language: Language,
            }
            let old: VersionOne = serde_json::from_value(value).map_err(|e| e.to_string())?;
            Settings {
                language: old.language,
                ..Default::default()
            }
        }
        Some(2) => serde_json::from_value(value).map_err(|e| e.to_string())?,
        _ => return Err(Diagnostic::new("settings.unsupported_version", "settings").to_string()),
    };
    settings.display.validate().map_err(str::to_owned)?;
    Ok(settings)
}
pub fn save(path: &Path, settings: &Settings) -> Result<(), String> {
    if settings.settings_version != 2 {
        return Err(Diagnostic::new("settings.unsupported_version", "settings").to_string());
    }
    settings.display.validate().map_err(str::to_owned)?;
    if let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    sns_project::atomic_write(
        path,
        &serde_json::to_vec_pretty(settings).map_err(|e| e.to_string())?,
    )
    .map_err(|e| e.to_string())
}
pub fn default_path() -> Option<PathBuf> {
    if let Some(path) = std::env::var_os("SINESI_SETTINGS_PATH") {
        return Some(path.into());
    }
    if cfg!(target_os = "windows") {
        return std::env::var_os("APPDATA").map(|p| PathBuf::from(p).join("Sinesi/settings.json"));
    }
    if cfg!(target_os = "macos") {
        return std::env::var_os("HOME")
            .map(|p| PathBuf::from(p).join("Library/Application Support/Sinesi/settings.json"));
    }
    std::env::var_os("XDG_CONFIG_HOME")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("HOME").map(|p| PathBuf::from(p).join(".config")))
        .map(|p| p.join("sinesi/settings.json"))
}
/// Recovery is local state, separate from preferences and user project destinations.
pub fn default_session_directory() -> Option<PathBuf> {
    if let Some(path) = std::env::var_os("SINESI_SESSION_DIR") {
        return Some(path.into());
    }
    if cfg!(target_os = "windows") {
        return std::env::var_os("LOCALAPPDATA")
            .or_else(|| std::env::var_os("APPDATA"))
            .map(|p| PathBuf::from(p).join("Sinesi/sessions"));
    }
    if cfg!(target_os = "macos") {
        return std::env::var_os("HOME")
            .map(|p| PathBuf::from(p).join("Library/Application Support/Sinesi/sessions"));
    }
    std::env::var_os("XDG_STATE_HOME")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("HOME").map(|p| PathBuf::from(p).join(".local/state")))
        .map(|p| p.join("sinesi/sessions"))
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn language_survives_restart_outside_the_project() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("preferences/settings.json");
        assert_eq!(load(&path).unwrap(), Settings::default());
        for language in Language::ALL {
            save(
                &path,
                &Settings {
                    language,
                    ..Settings::default()
                },
            )
            .unwrap();
            assert_eq!(load(&path).unwrap().language, language);
        }
    }
    #[test]
    fn malformed_and_oversized_settings_do_not_get_overwritten_on_load() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("settings.json");
        for bytes in [
            b"{\"settings_version\":99,\"language\":\"de\"}".to_vec(),
            vec![0; 65537],
            b"{\"settings_version\":1,\"language\":\"xx\"}".to_vec(),
        ] {
            std::fs::write(&path, &bytes).unwrap();
            assert!(load(&path).is_err());
            assert_eq!(std::fs::read(&path).unwrap(), bytes);
        }
    }
}
