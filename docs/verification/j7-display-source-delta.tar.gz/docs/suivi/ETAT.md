# État de reprise — Sinesi

## Situation courante — 8 novembre 2026

**J1 à J6 sont qualifiés localement. J7 reste ouvert.** Les préférences d’affichage
sont qualifiées après l’aide et les rapports PDF. FR EN ES IT PT DE et les vues
Icônes/Schéma sont conservés.

| Registre de référence | État |
| --- | --- |
| [178 exigences](features.json) | **157 verified**, 1 implemented, 2 in_progress, 18 not_started |
| [50 lots Rust](../rust/taches.json) | **43 verified**, 3 in_progress, 2 not_started, 2 deferred |
| J7 | **15 exigences vérifiées sur 22**, 1 implémentée partiellement, 6 non démarrées |
| Lots en cours | RS-QUALITY-J0, RS-PROJECTS-J7, RS-PLATFORM-J7 |

Les registres et leurs preuves sont l’autorité. Les résumés historiques ne ferment
pas une exigence; [leur chronologie antérieure](ETAT-HISTORIQUE-2026-11-08.md) est conservée.

## Dernière tranche : préférences d’affichage

**F-CFG-003 est vérifié; RS-PLATFORM-J7 reste en cours.** Le
[profil portable](../agnostique/AFFICHAGE_J7.md), l’[adaptateur](../rust/AFFICHAGE_J7.md)
et la [qualification](../verification/J7-AFFICHAGE.md) décrivent taille 80–200 %,
fonte standard/Noto Sans, représentation, panneaux, dimensions et géométrie bornée.
La version 1 du profil est lue sans réécriture; les sauvegardes écrivent la version 2.
Les écritures sont asynchrones, coalescées et attendues à la fermeture normale.
Les projets, protocoles et brouillons restent distincts des préférences.

Fichiers principaux : `sns-settings/src/display.rs`, `workbench/preferences_ui.rs`,
le contrat et ses fixtures, les raccordements canevas/panneaux/fenêtres/fermeture,
les catalogues et les recettes. Les chemins précis sont dans le registre Rust.
Le recadrage suit les dimensions appliquées; les actions d’annotation restent en
haut et le terminal revient à la ligne selon sa largeur visible.

Qualification : **247 tests workspace et un enfant**, cinq ignorés, Clippy sans
avertissement et contrôles réussis; **15 tests de la suite graphique**, **96 captures
courantes comparées sans mise à jour**, **387 anciennes images inchangées**;
**799 clés × six langues**. Dix répétitions du parcours de restauration réussissent
après remplacement de son attente fixe de 400 ms par un délai maximal de huit
secondes. Les temporisations virtuelles réseau sont conservées. Les régressions de
cadrage et de débordement du terminal sont décrites dans le rapport.

Manifeste : **766 fichiers**,
`sha256:a0dc67c2a795237294f5c51696a0502a879ff20bbe12aafa4a8e1a9388d04ea0`.
Le workspace reste à **20 membres**; aucun paquet tiers ajouté ou retiré.

## Socle et périmètre déjà qualifié

La [décision D-011](../rust/decisions/D-011-structure-et-workflow.md), le
[guide de développement](../rust/DEVELOPPEMENT.md) et la [carte actuelle](../rust/ARCHITECTURE.md)
fixent les responsabilités et les vérifications communes. Le [complément de politique](../verification/STRUCTURE-POLITIQUE-2026-11.md)
refuse une catégorie mal orthographiée avant l’analyse du graphe.

- [Import](../verification/J7-IMPORT-EN-COURS.md) : données ZIP/XML bornées, original préservé, rapport de pertes; **F-PROJ-005 reste implemented**, pas verified.
- [Scénarios/reprise/rejeu](../verification/J7-REPRISE-EN-COURS.md) et [pannes de liaison](../verification/J7-PANNES.md) : F-SIM-007/008.
- [Duplication/alignement](../verification/J7-TOPOLOGIE.md) et [nuage](../verification/J7-PRESENTATION.md) : F-TOP-009, F-EQU-008.
- [Observation](../verification/J7-OBSERVATION.md) et [diagnostic interne](../verification/J7-TERMINAL.md) : F-OBS-006/008, F-CLI-019.
- [Session/récupération](../verification/J7-SESSION.md) : F-PROJ-003/006.
- [Notes/zones](../verification/J7-ANNOTATIONS.md), [PNG](../verification/J7-PNG.md) et [PDF](../verification/J7-RAPPORT.md) : F-DOC-001/002/003/004.
- [Aide contextuelle et informations](../verification/J7-AIDE.md) : F-CFG-002; F1 et Échap préservent une saisie active.

## Prochaine action et limites

Poursuivre **RS-PLATFORM-J7** avec **F-CFG-004**, priorité CLI/profil utilisateur/
configuration administrateur et diagnostic/repli sûr. F-PROJ-001 et
RS-PROJECTS-J1 sont vérifiés. Le profil d’affichage 2 doit être conservé dans les
résolutions et sauvegardes suivantes. Puis traiter **F-CFG-005**, options de lancement,
à partir des chemins réellement appelés; les repères d’archive sont dans l’adaptateur
d’aide. `-v` historique désigne un verbose déclaré, pas la version; `-r` concerne
le RTT, pas la vitesse d’affichage.

Restent aussi couverture sémantique de l’import, diagnostics, exemples, packaging
et parcours réels sur trois OS. F-NFR-001/006 et RS-QUALITY-J0 restent en cours.
La suite GPU historique complète et l’accessibilité globale doivent être réconciliées
avec J7. La commande graphique ciblée couvre PNG, PDF, aide et préférences.
Les fenêtres d’une même catégorie partagent leur géométrie initiale; les dimensions
principales viennent du panneau et ne suivent pas automatiquement les gestes natifs.
Le zoom réseau reste distinct de la taille des widgets.

Aucun sélecteur natif nouvellement manipulé, parcours manuel autonome,
résultat Windows/Linux ou run distant n’est revendiqué. Les sockets hôte restent
réservées au pont explicitement activé. Les archives Filius et network-kit restent
en lecture seule; ni audit recalculé, ni commit, push ou publication effectués.
