//! Workbench document responsibilities.
use super::*;

impl Workbench {
    pub(super) fn replace(&mut self, action: Replacement) {
        if self.worker.pending_commands() {
            self.error = Some("state.pending_commands".into());
            return;
        }
        if self.editor.dirty() || self.desktop.dirty() {
            self.pending = Some(action);
        } else {
            self.replace_now(action);
        }
    }
    pub(super) fn replace_now(&mut self, action: Replacement) {
        let language = self.language;
        if matches!(action, Replacement::Close) {
            self.close_confirmed = true;
            return;
        }
        let result = match action {
            Replacement::RecoverSession => {
                self.load_requested_session();
                Ok(None)
            }
            Replacement::Close => unreachable!(),
            Replacement::LoadScenario
            | Replacement::RestoreCheckpoint
            | Replacement::ReplayRecording => {
                if let Some(path) = rfd::FileDialog::new()
                    .add_filter("JSON", &["json"])
                    .pick_file()
                    && let Err(e) = self.begin_runtime_file(path, action)
                {
                    self.error = Some(e);
                }
                Ok(None)
            }
            Replacement::New => {
                let mut project = Editor::empty().project().clone();
                project.name = language.text("new_network").into();
                Editor::new(project)
                    .map_err(sns_project::Error::from)
                    .map(|editor| Some((editor, None)))
            }
            Replacement::WirelessExample => sns_project::parse_project(include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../fixtures/valid/wireless.json"
            )))
            .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
            .map(|e| Some((e, None))),
            Replacement::MailExample | Replacement::P2pExample => {
                sns_project::parse_project(if matches!(action, Replacement::MailExample) {
                    include_bytes!(concat!(
                        env!("CARGO_MANIFEST_DIR"),
                        "/../../fixtures/valid/mail.json"
                    ))
                    .as_slice()
                } else {
                    include_bytes!(concat!(
                        env!("CARGO_MANIFEST_DIR"),
                        "/../../fixtures/valid/p2p.json"
                    ))
                    .as_slice()
                })
                .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                .map(|e| Some((e, None)))
            }
            Replacement::PrivateExample => sns_project::parse_project(include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../fixtures/valid/private.json"
            )))
            .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
            .map(|e| Some((e, None))),
            Replacement::ClassroomExample | Replacement::ServicesExample => {
                sns_project::parse_project(if matches!(action, Replacement::ServicesExample) {
                    include_bytes!(concat!(
                        env!("CARGO_MANIFEST_DIR"),
                        "/../../fixtures/valid/services.json"
                    ))
                    .as_slice()
                } else {
                    include_bytes!(concat!(
                        env!("CARGO_MANIFEST_DIR"),
                        "/../../fixtures/valid/classroom.json"
                    ))
                    .as_slice()
                })
                .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                .map(|e| Some((e, None)))
            }
            Replacement::RoutedExample | Replacement::RipExample => {
                sns_project::parse_project(if matches!(action, Replacement::RipExample) {
                    include_bytes!(concat!(
                        env!("CARGO_MANIFEST_DIR"),
                        "/../../fixtures/valid/rip.json"
                    ))
                    .as_slice()
                } else {
                    include_bytes!(concat!(
                        env!("CARGO_MANIFEST_DIR"),
                        "/../../fixtures/valid/routed.json"
                    ))
                    .as_slice()
                })
                .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                .map(|e| Some((e, None)))
            }
            Replacement::HostsExample => sns_project::parse_project(include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../fixtures/valid/hosts.json"
            )))
            .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
            .map(|e| Some((e, None))),
            Replacement::Example => sns_project::parse_project(include_bytes!(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../../fixtures/valid/lan.json"
            )))
            .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
            .map(|e| Some((e, None))),
            Replacement::ImportFilius => {
                if let Some(path) = rfd::FileDialog::new()
                    .add_filter("Filius", &["fls"])
                    .pick_file()
                    && let Err(e) = self.import_ui.file(path)
                {
                    self.error = Some(e.to_string());
                }
                Ok(None)
            }
            Replacement::Open => {
                if let Some(path) = rfd::FileDialog::new()
                    .add_filter(language.text("project_file"), &["json"])
                    .pick_file()
                {
                    sns_project::load_project(&path)
                        .and_then(|p| Editor::new(p).map_err(sns_project::Error::from))
                        .map(|e| Some((e, Some(path))))
                } else {
                    Ok(None)
                }
            }
        };
        match result {
            Ok(Some((editor, path))) => {
                self.session_ui.can_save = true;
                self.set_mode(Mode::Design);
                self.editor = editor;
                self.duplicate_omitted = 0;
                self.desktop = Default::default();
                self.worker
                    .restart(self.project().clone(), self.launch_wait_factor);
                self.synced_revision = 0;
                self.page = Page::Topology;
                self.event_index = None;
                self.filter.clear();
                self.path = path;
                self.selected.clear();
                self.draft = None;
                self.annotations = Default::default();
                self.fit = true;
                self.error = None;
            }
            Ok(None) => {}
            Err(e) => {
                self.journal.record(TechnicalEvent::ProjectLoadFailed);
                self.error = Some(e.to_string());
            }
        }
    }
    pub(super) fn save(&mut self, save_as: bool) -> bool {
        if self.worker.pending_commands() {
            self.error = Some("state.pending_commands".into());
            return false;
        }
        let language = self.language;
        let path = if save_as || self.path.is_none() {
            rfd::FileDialog::new()
                .add_filter(language.text("project_file"), &["json"])
                .set_file_name(language.text("project_filename"))
                .save_file()
        } else {
            self.path.clone()
        };
        let Some(path) = path else {
            return false;
        };
        match self.save_project_to(path) {
            Ok(()) => true,
            Err(e) => {
                self.error = Some(e);
                false
            }
        }
    }
    pub fn save_project_to(&mut self, path: PathBuf) -> Result<(), String> {
        if self.worker.pending_commands() {
            return Err("state.pending_commands".into());
        }
        self.document_output_allowed(&path)?;
        match sns_project::save_project(&path, self.project()) {
            Ok(()) => {
                self.path = Some(path);
                self.editor.mark_saved();
                Ok(())
            }
            Err(e) => {
                self.journal.record(TechnicalEvent::ProjectSaveFailed);
                self.error = Some(e.to_string());
                Err(e.to_string())
            }
        }
    }
}
