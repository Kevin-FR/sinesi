# J7 en cours — import, scénarios, rejeu et livraison

Le périmètre intégral reste celui de [PROJETS_J7](../agnostique/PROJETS_J7.md) et de la roadmap. Les sections suivantes décrivent les tranches réalisées : import `.fls`, scénarios/checkpoints/rejeu, pannes, duplication/alignement et présentation. L’autosauvegarde, les exports PDF/PNG et la livraison multiplateforme restent ouverts.

## Import

`sns-filius-import` prend des octets et un nom de source, puis renvoie `Project` et `ImportReport`. Le crate ne fait aucune I/O hôte. `archive.rs` borne le ZIP, ses noms et la décompression; `xml.rs` construit un arbre en lecture seule et résout les références; `convert.rs` et `mail.rs` contiennent les correspondances explicites. Les propriétés non utilisées restent dans le rapport et les octets des entrées sont conservés dans les ressources.

Le lockfile fixe `zip 9.4.1` (sans fonctionnalités par défaut, Deflate) et `roxmltree 0.20.0`, déjà présent dans le graphe de rendu. La configuration de l’analyseur refuse les DTD et borne les nœuds; le préfiltre refuse aussi les déclarations d’entités. Les décisions de noms/tailles/chemins et références restent dans SNS, indépendamment des protections de bibliothèque. Voir la [documentation ZIP](https://docs.rs/zip/9.4.1/zip/struct.ZipArchive.html) et les [options XML](https://docs.rs/roxmltree/0.20.0/roxmltree/struct.ParsingOptions.html).

`Editor::mark_unsaved` distingue une importation encore sans fichier utilisateur d’un projet enregistré. `import_ui.rs` utilise un canal borné et un fil de traitement; le résultat validé est publié d’un bloc, les erreurs conservent le projet antérieur. Le rapport affiche écarts, champs, classes et pièces dans les six langues et peut être exporté en JSON. Les vues Icônes/Schéma restent des projections.

```sh
cargo run -p sns-cli --locked --offline -- import-filius source.fls --output converted.sinesi.json --report coverage.json
cargo test -p sns-filius-import --locked --offline
SNS_RECORD_J7_IMPORT="$PWD/docs/verification/j7-import-corpus.json" SNS_RECORD_J7_IMPORT_DIR="$PWD/docs/verification" cargo test -p sns-filius-import --test import --locked --offline -- --ignored
cargo test -p sns-ui-egui --features ui-snapshots --test lan j7_background --locked --offline
```

Les deux tests ignorés par défaut nécessitent `_archive/filius-master` : corpus des 20 fichiers et ping du LAN historique. Ils échouent si l’archive manque lorsqu’on les demande explicitement. Les tests ordinaires utilisent une fixture ZIP/XML synthétique propre à Sinesi et couvrent import, références, champs inconnus, pièces inactives, corruption, chemins, entités, quotas et vrai ping simulé. Le corpus, ses sources et son runtime ne sont pas redistribués.

## Suites requises

Finaliser la couverture sémantique d’import et ses écarts. Puis réaliser état complet/checkpoint/rejeu et pannes, récupération/session, annotations et scène commune d’export, filtres structurés/parcours, duplication/alignement, préférences/aide/CLI/diagnostics, exemples et packaging. Ne pas fermer RS-PROJECTS-J7 sur la seule présence de l’importeur. La validation Windows/Linux/macOS doit être fondée sur des résultats réellement obtenus.

## Tranche moteur et fichiers d’exécution

Le [contrat portable de reprise](../agnostique/REPRISE_J7.md) décrit les formats. `sns-engine/src/recording.rs`, `checkpoint.rs`, `state.rs` et `state_value.rs` exposent `Recording`, `Checkpoint` et l’état structurel. Les états privés des protocoles, applications et du VFS implémentent `Serialize`; les entiers larges et les cartes à clés composées passent par un sérialiseur dédié. Le budget de transit ignoré par la sérialisation de trace des trames est sauvegardé séparément pour les réceptions en attente.

La restauration reconstruit l’état depuis les entrées validées, compare le hash complet, puis renouvelle la génération. Elle ne désérialise pas les structures privées depuis un arbre arbitraire. Son coût est O(historique), avec limites explicites; ce choix permet la validation d’atteignabilité dans ce profil pédagogique. Les octets estimés du journal sont bornés en mémoire et recalculés après lecture. Une exportation saturée est refusée.

`Scenario::network_actions` est activé au format 2. Le moteur conserve les actions comme `Event::NetworkCommand`, consommées transactionnellement par un état candidat; leur progression est enregistrée une seule fois. L’ancien format 1 garde sa trace de prototype inchangée. `replay_remaining` traite aussi une frontière d’événements fusionnée et remappe seulement les commandes d’une continuation explicitement validée.

`sns-project` ajoute des I/O atomiques bornées à 64 Mio pour les fichiers d’exécution, sans augmenter la limite des projets. `sns-cli/src/runtime_cli.rs` porte les exports et les sous-commandes ci-dessous. Tous les chemins sont contrôlés avant l’exécution et tous les exports sont encodés avant leur première écriture; chaque fichier est remplacé atomiquement, sans transaction commune entre plusieurs destinations.

```sh
cargo run -p sns-cli --locked --offline -- run fixtures/valid/network-scenario.json --until-us 1500 --checkpoint point.json
cargo run -p sns-cli --locked --offline -- resume point.json --until-us 10000000 --trace resumed.jsonl
cargo run -p sns-cli --locked --offline -- run fixtures/valid/network-scenario.json --until-us 10000000 --recording inputs.json
cargo run -p sns-cli --locked --offline -- replay inputs.json --trace replayed.jsonl
cargo run -p sns-cli --locked --offline -- resume point.json --continuation inputs.json --until-us 10000000
```

`runtime_ui.rs` utilise un canal borné et un fil pour lire, reconstruire ou écrire. Le worker moteur produit les captures et publie un nouvel état après validation. Les commandes ont un compteur d’acquittement distinct de leur identité; les reçus conservés et les actions futures réservent leurs noms. Le pilote du modem renouvelle sa session et évite ses anciens reçus lors d’une activation explicite après reprise. Aucun tunnel n’est ouvert par le chargement ou le rejeu.

Le [rapport de cette tranche](../verification/J7-REPRISE-EN-COURS.md) ne ferme pas le jalon : pannes par liaison, documentation/exports, session/récupération, préférences, exemples complets et livraison trois OS restent requis.

## Pannes par liaison

Le [profil portable](../agnostique/PANNES_J7.md) fixe l’algorithme et les unités. `sns-model/src/link_conditions.rs` définit `LinkConditions` et sa validation; `ConfigureLink` reste dans l’enveloppe de commande API 1. `sns-protocols/src/link_conditions.rs` porte les flux SplitMix64 séparés, leurs paramètres et les faits 9. Le plan réseau décide perte et délai sur un état candidat; le commit conserve l’atomicité et la cause de la réception.

`Network::link_conditions` est une carte vide par défaut, omise de l’état sérialisé tant qu’elle est vide. Cela maintient la compatibilité des checkpoints non configurés de la tranche précédente, vérifiée sur une fixture figée. Les liaisons configurées utilisent des `Delay::Timer` avec délai calculé; la politique historique `Delay::Link` reste inchangée pour les autres. Aucun module de sockets réelles n’est impliqué.

Le worker publie graine et configurations pour la vue. `link_conditions_ui.rs` propose une sélection de câble, des champs numériques et une application en simulation; le document de topologie n’est pas modifié. Le canvas montre le taux et colore les conditions en Icônes et Schéma. Les écritures de checkpoint utilisent le chemin déjà qualifié de `runtime_ui.rs`.

```sh
cargo run -p sns-cli --locked --offline -- run fixtures/valid/link-conditions-scenario.json --until-us 5000000 --checkpoint links-point.json
cargo run -p sns-cli --locked --offline -- resume links-point.json --until-us 50000000 --trace links-resumed.jsonl
cargo run -p sns-cli --locked --offline -- run fixtures/valid/link-conditions-scenario.json --until-us 50000000 --recording links-inputs.json --trace links-full.jsonl
cargo run -p sns-cli --locked --offline -- replay links-inputs.json --trace links-replayed.jsonl
```

## Duplication et alignement

Le [profil portable](../agnostique/EDITION_J7.md) fixe F-TOP-009. `sns-topology/src/duplication.rs` prépare un projet candidat et un rapport d’identités/créations/liens omis, sans I/O. L’allocateur réserve les identités existantes, les MAC normalisées, les noms et SSID; les références typées sont remappées explicitement. Une carte distincte conserve la correspondance des messages partagés entre boîtes copiées.

`Edit::Duplicate` et `Edit::Align` passent par la même transaction et l’historique. `Editor::apply` renvoie désormais `EditResult` : le client peut sélectionner les créations et expliquer les câbles extérieurs omis. Toute erreur de préparation restaure aussi le compteur d’identités de l’éditeur. Les alignements modifient les positions existantes en place pour éviter une modification d’ordre sans déplacement.

La borne de document de 8 Mio est déclarée dans `sns-model::MAX_PROJECT_DOCUMENT_BYTES` et réutilisée par la persistance; sa valeur ne change pas. La préparation d’une copie vérifie la taille sérialisée avant publication. Le seul changement de dépendance est un lien de test de `sns-topology` vers `sns-engine`, déjà présent dans le workspace; aucune version de paquet n’a changé.

`topology_ui.rs` porte bouton/raccourci, menu d’alignement et diagnostic IPv4 non bloquant. Les identités sélectionnées sont filtrées après annulation/rétablissement afin d’éviter des références de vue périmées. Le moteur de simulation n’est pas remplacé par une opération d’alignement; les changements de topologie restent réservés à la conception.

Les tests exécutent un ping sur le LAN copié et vérifient que ses réceptions Ethernet restent dans ce LAN. Ils couvrent aussi NAT/DHCP/routes, association radio, courrier, fichiers, noms Unicode, quotas et les huit alignements. Le parcours d’interface utilise les six langues, les deux vues, le raccourci D et l’annulation/rétablissement.

## Apparence nuage

Le [profil portable](../agnostique/PRESENTATION_J7.md) fixe F-EQU-008. `sns-model/src/presentation.rs` prépare un `Project::with_symbol` validé; `DeviceSymbol::Cloud` promeut le projet au profil 8, uniquement pour un switch. `Command::SetSymbol` est traité dans le moteur sans recréer `Network` ni `Applications`, sans consommer d’aléa ou avancer le temps. Un fait 10 accompagne la modification effective. Les reçus, révisions et limites suivent les règles habituelles.

`Edit::SetSymbol` fournit l’historique de conception. `Editor::accept_runtime` fusionne les symboles des seules identités explicitement modifiées, en conservant les valeurs de topologie locales. `presentation_ui.rs` envoie la commande en simulation et l’édition en conception. L’interface attend l’acquittement pour refléter l’état confirmé; les autres modifications du document sont verrouillées pendant cette attente. Le champ numérique de rétention SAT possède désormais un libellé accessible associé.

Les deux `cloud.svg` de `assets/network` sont copiés sans modification depuis les assets utilisateur; provenance et empreintes sont vérifiées. L’importeur convertit le booléen historique `cloud`, avec diagnostic si sa valeur est invalide. Les schémas autonomes de présentation et les schémas courants de scénario/journal/checkpoint couvrent le nouveau profil; les anciens schémas de projet restent inchangés.

```sh
cargo test -p sns-engine --test presentation --locked --offline
cargo test -p sns-filius-import --test import --locked --offline -- --ignored
cargo test -p sns-ui-egui --features ui-snapshots --test lan j7_cloud --locked --offline
```

Le [rapport de qualification](../verification/J7-PRESENTATION.md) relie les recettes aux preuves locales. Il ne ferme pas les autres lots J7.
