# État de reprise — Sinesi

## J7 ouvert — import, scénarios, rejeu et livraison

Objectif intégral : les 22 exigences et 9 lots J7 de la roadmap, en conservant les six langues et les vues Icônes/Schéma. Première tranche réalisée en code : F-PROJ-005 / RS-PROJECTS-J7, import ZIP/XML en données, rapport explicite et conservation des pièces inactives. Le lot reste en cours, notamment pour session et récupération. Les autres lots restent à réaliser et aucun critère J7 n’est déclaré qualifié.

## Socle J6 qualifié — 7 novembre 2026

J1 à J6 sont réalisés localement. J6 ajoute le courrier SMTP/POP3 avec relais MX/A, les comptes/messages/contacts persistants, le P2P avec recherche et téléchargement, les associations Wi-Fi par SSID et le modem explicite entre instances réelles. Les six langues **FR EN ES IT PT DE** et les vues **Icônes/Schéma** sont conservées.

| Registre | État |
| --- | --- |
| 178 exigences | **143 verified**, 1 implemented, 3 in_progress, 31 not_started |
| 50 lots techniques | **37 verified**, 3 in_progress, 8 not_started, 2 deferred |
| J1 | 28 exigences / 7 lots vérifiés |
| J2 | 40 exigences / 6 lots vérifiés |
| J3 | 15 exigences / 7 lots vérifiés |
| J4 | 20 exigences / 5 lots vérifiés |
| J5 | 17 exigences / 6 lots vérifiés |
| J6 | **16 exigences / 4 lots vérifiés**; R-MAIL, R-P2P et R-PONT qualifiées |
| Transversal | F-NFR-001/F-NFR-006 et RS-QUALITY-J0 restent en cours |

[features.json](features.json) et [taches.json](../rust/taches.json) sont les registres de référence. Chaque critère J6 possède une preuve reproductible avec commande, environnement, artefacts et révision. Les chemins prévus sont conservés; les fichiers réalisés figurent dans `actual_paths`. Les vues ont été régénérées sans recalculer l’audit Filius.

## Réalisation J6

Le [profil portable](../agnostique/APPLICATIONS_J6.md) définit comportements, contrats et limites. L’[adaptateur Rust](../rust/J6.md) décrit les modules; le [rapport J6](../verification/J6.md) relie les tests et captures aux exigences.

Fichiers principaux : `sns-model/src/mail.rs`, `p2p.rs`, `wireless.rs`, `modem.rs`; `sns-apps/src/mail.rs`, `p2p.rs`, `dns.rs`, `lib.rs`; `sns-protocols/src/bridge.rs`, `lib.rs`, `routing.rs`, `transport.rs`; `sns-engine/src/applications.rs`, `lib.rs`; nouveau `sns-bridge`; fenêtres `mail_ui.rs`/`p2p_ui.rs`, configuration, rendu et worker de la GUI. Trois schémas autonomes J6 et quatre fixtures complètent les tests. Le catalogue contient **545 clés × six langues**, avec **18 SVG** embarqués dont modem et point d’accès fournis par l’utilisateur.

Le projet 7 / `sns-educational-applications-v1` garde les données et réglages. Les sessions TCP, recherches et tunnels actifs restent transitoires. Les commandes restent API 1; les faits supplémentaires ont la version 8. Les données mail et les fichiers téléchargés passent par les mêmes transactions que le réseau. Les sockets système restent réservées à l’adaptateur de modem explicitement activé.

## Qualification exécutée

- `SNS_J6_ARTIFACT_DIR="$PWD/docs/verification" cargo test --workspace --locked --offline` : **155 tests du workspace**, plus **1 test enfant** dans le second processus; une mesure historique ignorée.
- `cargo test -p sns-ui-egui --features ui-snapshots --test lan --test workbench --locked --offline` : **38 tests rendus**, comparaison des **93 captures J6** sans mise à jour.
- `cargo fmt --all --check`, Clippy avec `-D warnings` et compilation `sns-desktop` : réussis.
- Contrôles des langues, assets/provenance, couches, documentation et inspection Filius : réussis.
- `docs.py render`, `docs.py check --require-reference` et vérification du manifeste : réussis.

Le [manifeste J6](../verification/j6-code-manifest.json) couvre **384 fichiers**, révision `sha256:3991dc6ed962fbd61a6259ac9c53185b19cc7b2f8e9b409453a3205283dfda28`. Les [traces](../verification/j6-artifacts.json) comprennent courrier local/interdomaines, P2P et les deux processus du pont. Le ping a traversé le tunnel réel et chaque côté a enregistré deux entrées externes. Les preuves [J1](../verification/J1.md), [J2](../verification/J2.md), [J3](../verification/J3.md), [J4](../verification/J4.md) et [J5](../verification/J5.md) restent historiques.

## Limites et reprise

Courrier textuel sans TLS/pièces jointes; contacts complets par l’API. P2P pédagogique avec quotas et sans interopérabilité historique. Wi-Fi logique sans propagation radio. Modem réel sans chiffrement/authentification, activé manuellement et fermé à l’arrêt/retour en conception. Aucun service mail ou pair Internet réel n’est contacté.

La qualification a été exécutée sur macOS arm64 avec le harnais rendu. Aucun nouveau parcours manuel en fenêtre autonome ni résultat Windows/Linux/CI distante n’est revendiqué. Les limites et recettes détaillées sont dans le rapport; la capacité globale reste à qualifier dans les exigences transversales.

**Prochaine tranche : J7**, selon la roadmap : projets partageables/récupérables, import des données historiques avec rapport, scénarios/rejeu des entrées externes, packaging et documentation de livraison. J6 enregistre les entrées du pont; il ne déclare pas encore leur rejeu réalisé. Conserver les contrats et preuves des versions précédentes.

## Tranche initiale J7 — import présent, jalon en cours

Le [profil portable J7](../agnostique/PROJETS_J7.md), l’[adaptateur en cours](../rust/J7-EN-COURS.md) et le [rapport partiel](../verification/J7-IMPORT-EN-COURS.md) décrivent précisément le périmètre. `sns-filius-import` lit les octets ZIP/XML sans extraction ni exécution, conserve les originaux et rapporte les champs non convertis. L’import est disponible dans le CLI (`import-filius`) et en arrière-plan dans la GUI. Les paramètres, comptes mail, logiciels connus, fichiers et DNS sont partiellement convertis; les pertes restantes sont explicites. Le projet précédent est conservé en cas d’erreur et le projet importé est marqué non enregistré.

Contrôles réellement exécutés : **162 tests du workspace plus un test enfant**, trois tests ignorés par défaut dont les deux recettes de corpus ensuite exécutées explicitement (**20 imports et ping historique**). Clippy sans avertissement, formatage, contrôles des couches et des **570 clés × six langues** réussis. Le parcours graphique d’import et d’échec est testé dans les six langues et les deux vues; six captures d’import ont été comparées sans mise à jour, les captures FR/DE inspectées. Les PNG J0–J6 restent historiques.

La tranche ne ferme pas J7 : couverture sémantique de l’import à approfondir, checkpoint complet/rejeu/pannes, autosauvegarde/session, annotations/styles, PNG/PDF, recherche/parcours/export structurés, duplication/alignement, préférences/aide/CLI/diagnostics, exemples et livraison/validation sur trois OS restent requis. La prochaine tranche est RS-ENGINE-J7, avec état complet des files, protocoles et applications; un simple rechargement du projet ne vaut pas reprise.

## Tranche moteur J7 ouverte

F-SIM-007/008 et RS-ENGINE-J7 sont en cours. Le format de reprise doit porter l’état complet et le journal des commandes/progressions/entrées externes, avec vérification d’intégrité et génération renouvelée. Les tables à clés composées seront représentées par des entrées structurées afin de conserver un contrat indépendant du langage. Aucun résultat de checkpoint/rejeu/panne n’est encore annoncé.

## Revalidation ciblée J6 dans le checkout J7

Le [complément de preuve](../verification/J6-REVALIDATION.md) conserve la qualification historique et ajoute une passe courante : 16 tests réseau/applications/pont plus un test enfant, 4 parcours graphiques fonctionnels et 1 contrat réussis. Les six langues et les vues Icônes/Schéma sont conservées; 575 clés et 18 SVG sont contrôlés. Les seize exigences et quatre lots J6 gardent leur état vérifié et leurs anciennes preuves.

La comparaison rendue échoue sur les quatre tests J6 : le bouton d’import J7 change la barre d’outils par rapport aux images historiques. Ces références restent intactes; cette passe n’annonce pas une suite globale verte. Les vues générées ont été régénérées. Aucun nouveau comportement de production ni critère J7 n’est déclaré terminé par cette revalidation.

## Tranche J7 — scénarios réseau, checkpoints et rejeu

F-SIM-007 est vérifié localement; RS-ENGINE-J7 reste en cours pour F-SIM-008. Le [contrat portable](../agnostique/REPRISE_J7.md), l’[adaptateur](../rust/J7-EN-COURS.md) et le [rapport de preuve](../verification/J7-REPRISE-EN-COURS.md) couvrent l’état complet, les actions réseau datées, les générations, les limites mémoire du journal et les entrées du pont rejouées hors ligne. La restauration reconstruit l’historique validé et compare l’état complet; elle a un coût proportionnel à cet historique.

Le CLI propose `run` avec scénario 2 et exports, `resume` et `replay`; la fenêtre Exécutions ouvre et exporte ces fichiers en arrière-plan. Une erreur conserve le document précédent; une reprise publie une nouvelle génération. Six langues et deux vues sont conservées. La qualification comprend 174 tests du workspace plus un test enfant, 2 recettes de référence réexécutées, Clippy sans avertissement et 12 captures nouvelles comparées sans mise à jour. Le catalogue contient 588 clés × six langues; 18 SVG restent embarqués. Les références historiques ne sont pas remplacées; la suite graphique historique complète n’est pas annoncée verte.

Le manifeste de cette tranche couvre 424 fichiers (`sha256:02f6cb9f761bb56561017fd99620884d1d4ddcc53d749a68beced8c7d6e54e1b`). Les traces et checkpoints synthétiques sont fournis. Le périmètre complet J7 reste ouvert : prochaine tranche, pannes par liaison; puis observations, édition/documentation/rapports, session et récupération, préférences/CLI/diagnostics, exemples et livraison avec preuves réelles sur les trois OS.
